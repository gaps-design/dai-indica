@echo off
setlocal EnableExtensions
cls
title Correcao Manutencao 504 V3

echo ============================================================
echo  CORRECAO MANUTENCAO 504 V3 - SEM R
echo ============================================================
echo.
where node >nul 2>nul
if errorlevel 1 (
  echo [ERRO] Node.js nao foi encontrado neste VD.
  pause
  exit /b 1
)

echo Aplicando a correcao...
node "%~dp0arquivos\instalar_correcao.js"
set "RC=%ERRORLEVEL%"

if not "%RC%"=="0" (
  echo.
  echo [ERRO] A correcao nao foi aplicada. Codigo: %RC%
  pause
  exit /b %RC%
)

echo.
echo ============================================================
echo  CORRECAO APLICADA COM SUCESSO
echo ============================================================
echo.
echo 1. Feche esta janela.
echo 2. Abra novamente o INICIAR_PORTAL_504.bat de sempre.
echo 3. No Chrome, use Ctrl+F5 na Central.
echo 4. Teste Manutencao - Atualizar.
echo.
echo Nao deve aparecer Aviso de seguranca nem [N]/[R].
echo.
pause
exit /b 0
