"use strict";
const fs = require("fs");
const path = require("path");
const cp = require("child_process");

const BASE = String.raw`N:\Packaging\Compartilhado\Retornável\Usuarios\Guilherme A\Lobby`;
const dir = path.join(BASE, "Portal manutenção", "Atualizar SAP");
const launcher = path.join(dir, "executar_manutencao_sem_r.js");
if (!fs.existsSync(launcher)) {
  console.error("[ERRO] Launcher ainda nao foi instalado:", launcher);
  process.exit(1);
}
console.log("Testando motor da Manutencao sem passar pela Central...");
const c = cp.spawn("node", [launcher], { cwd: dir, stdio: "inherit", shell: false, windowsHide: false });
c.on("error", e => { console.error(e.message); process.exit(1); });
c.on("close", code => process.exit(Number.isInteger(code) ? code : 1));
