"use strict";

const fs = require("fs");
const path = require("path");
const cp = require("child_process");

const BASE = String.raw`N:\Packaging\Compartilhado\Retornável\Usuarios\Guilherme A\Lobby`;
const CENTRAL_DIR = path.join(BASE, "Portal Indicadores", "_sistema", "Central Atualizacoes");
const CONFIG = path.join(CENTRAL_DIR, "config_central_504.json");
const MAINT_DIR = path.join(BASE, "Portal manutenção", "Atualizar SAP");
const LAUNCHER_NAME = "executar_manutencao_sem_r.js";
const SOURCE_LAUNCHER = path.join(__dirname, LAUNCHER_NAME);
const TARGET_LAUNCHER = path.join(MAINT_DIR, LAUNCHER_NAME);

function fail(msg) {
  console.error("[INSTALADOR] ERRO:", msg);
  process.exit(1);
}
function ok(msg) { console.log("[OK]", msg); }

for (const p of [CENTRAL_DIR, CONFIG, MAINT_DIR, SOURCE_LAUNCHER]) {
  if (!fs.existsSync(p)) fail(`Nao encontrado: ${p}`);
}

let cfg;
try {
  cfg = JSON.parse(fs.readFileSync(CONFIG, "utf8").replace(/^\uFEFF/, ""));
} catch (e) {
  fail(`Config da Central invalido: ${e.message}`);
}
if (!cfg.automations || typeof cfg.automations !== "object") {
  fail("config_central_504.json nao possui automations.");
}

const old = cfg.automations.manutencao || {};
const stamp = new Date().toISOString().replace(/[-:.TZ]/g, "").slice(0, 14);
const backup = path.join(CENTRAL_DIR, `config_central_504.backup_${stamp}.json`);
fs.copyFileSync(CONFIG, backup);
ok(`Backup criado: ${backup}`);

fs.copyFileSync(SOURCE_LAUNCHER, TARGET_LAUNCHER);
ok(`Launcher instalado: ${TARGET_LAUNCHER}`);

cfg.automations.manutencao = {
  ...old,
  name: old.name || "Manutencao",
  kind: "node",
  cwd: MAINT_DIR,
  command: "node",
  args: [LAUNCHER_NAME],
  watchFile: old.watchFile || path.join(BASE, "Portal manutenção", "Relatórios SAP", "ordens_status.htm")
};
delete cfg.automations.manutencao.script;

fs.writeFileSync(CONFIG, JSON.stringify(cfg, null, 2), "utf8");

const check = JSON.parse(fs.readFileSync(CONFIG, "utf8"));
const m = check.automations && check.automations.manutencao;
if (!m || m.kind !== "node" || m.command !== "node" || !Array.isArray(m.args) || m.args[0] !== LAUNCHER_NAME) {
  fail("A validacao do config apos salvar falhou.");
}
const serialized = JSON.stringify(m);
if (/-File/i.test(serialized) || /powershell\.exe/i.test(serialized)) {
  fail("A configuracao de Manutencao ainda contem execucao direta de PowerShell.");
}
ok("Config da Manutencao alterado para Node launcher.");

// Encerra apenas o processo que estiver ESCUTANDO na porta 5040.
// O usuario reabre a Central pelo INICIAR_PORTAL_504.bat habitual.
try {
  const out = cp.execFileSync("netstat", ["-ano"], { encoding: "utf8", windowsHide: true });
  const pids = new Set();
  for (const line of out.split(/\r?\n/)) {
    if (!/:5040\s/.test(line) || !/LISTENING/i.test(line)) continue;
    const parts = line.trim().split(/\s+/);
    const pid = parts[parts.length - 1];
    if (/^\d+$/.test(pid)) pids.add(pid);
  }
  for (const pid of pids) {
    try {
      cp.execFileSync("taskkill", ["/PID", pid, "/F"], { stdio: "ignore", windowsHide: true });
      ok(`Agente antigo encerrado (PID ${pid}).`);
    } catch (e) {
      console.warn(`[AVISO] Nao consegui encerrar PID ${pid}: ${e.message}`);
    }
  }
  if (!pids.size) console.log("[INFO] Nenhum agente ativo na porta 5040.");
} catch (e) {
  console.warn(`[AVISO] Nao consegui consultar a porta 5040: ${e.message}`);
}

console.log("");
console.log("CORRECAO INSTALADA.");
console.log("Agora abra novamente o INICIAR_PORTAL_504.bat e teste a Manutencao.");
process.exit(0);
