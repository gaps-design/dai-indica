(() => {
  "use strict";

  const AUTH = {
    usuario: "acesso",
    senhaHash: "1j78k6ardjv",
    storageKey: "portal504_auth_v1"
  };

  function hashCredential(value) {
    let h1 = 0xdeadbeef ^ value.length;
    let h2 = 0x41c6ce57 ^ value.length;
    for (let i = 0, ch; i < value.length; i++) {
      ch = value.charCodeAt(i);
      h1 = Math.imul(h1 ^ ch, 2654435761);
      h2 = Math.imul(h2 ^ ch, 1597334677);
    }
    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
    return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(36);
  }

  const tokenEsperado = hashCredential(`portal504|${AUTH.usuario}|${AUTH.senhaHash}|autorizado`);

  function sessaoValida() {
    try {
      const raw = localStorage.getItem(AUTH.storageKey);
      if (!raw) return false;
      const sessao = JSON.parse(raw);
      return sessao && sessao.token === tokenEsperado && Number.isFinite(sessao.expiraEm) && Date.now() < sessao.expiraEm;
    } catch (_) {
      return false;
    }
  }

  if (!sessaoValida()) {
    const retorno = encodeURIComponent(window.location.href);
    window.location.replace(`index.html?retorno=${retorno}`);
    return;
  }

  const page = document.getElementById("systemsPage");
  if (page) page.hidden = false;
  document.body.classList.remove("systems-auth-pending");

  function atualizarRelogio() {
    const el = document.getElementById("systemsClock");
    if (!el) return;
    const d = new Date();
    el.innerHTML = `<strong>${d.toLocaleTimeString("pt-BR",{hour:"2-digit",minute:"2-digit"})}</strong><br>${d.toLocaleDateString("pt-BR")}`;
  }
  atualizarRelogio();
  setInterval(atualizarRelogio, 30000);
})();
