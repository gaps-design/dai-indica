@echo off
setlocal EnableExtensions
title Atualizar SAP 504 V5.15 - UI Automation
cd /d "%~dp0"

REM ================================================================
REM LAUNCHER SEM PROMPT [N]/[R]
REM Nao executa o .PS1 da unidade N: com -File.
REM O PowerShell le o arquivo como TEXTO e executa um ScriptBlock.
REM Assim o arquivo de rede nao dispara a pergunta de confianca.
REM Tambem nao existe PAUSE/Read-Host: execucao 100%% automatica.
REM ================================================================

set "SAP504_PS1=%~dp0Atualizar_SAP_504_V5_15.ps1"

if not exist "%SAP504_PS1%" (
  echo ERRO: arquivo PowerShell nao encontrado:
  echo %SAP504_PS1%
  endlocal
  exit /b 2
)

powershell.exe -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; try { $code = Get-Content -LiteralPath $env:SAP504_PS1 -Raw -ErrorAction Stop; $sb = [ScriptBlock]::Create($code); $null = $sb.Invoke(); exit 0 } catch { Write-Host ''; Write-Host ('ERRO: ' + $_.Exception.Message) -ForegroundColor Red; exit 1 }"

set "RC=%ERRORLEVEL%"
endlocal & exit /b %RC%
