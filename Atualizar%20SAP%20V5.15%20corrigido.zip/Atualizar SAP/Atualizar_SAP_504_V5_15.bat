﻿@echo off
setlocal
title Atualizar SAP 504 V5.13 - UI Automation
cd /d "%~dp0"

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Atualizar_SAP_504_V5_15.ps1"

echo.
echo Pressione qualquer tecla para fechar...
pause >nul
endlocal
