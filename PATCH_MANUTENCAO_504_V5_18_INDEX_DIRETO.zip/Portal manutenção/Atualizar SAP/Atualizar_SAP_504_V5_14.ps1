﻿# =====================================================================
# Atualizar SAP 504 V5.18 - leitura direta do Index + sincronização automática
# Automação sem Remote Debugging / sem porta 9222
# Usa Windows UI Automation + Chrome normal
# =====================================================================

$ErrorActionPreference = "Stop"

# =========================
# CONFIGURAÇÃO
# =========================
$Base = "N:\Packaging\Compartilhado\Retornável\Usuarios\Guilherme A\Lobby\Portal manutenção"
$PortalIndex = Join-Path $Base "index_programacao_operacional.html"
$Downloads = Join-Path $Base "Downloads"
$Relatorios = Join-Path $Base "Relatórios SAP"
$GitHub = Join-Path $Base "GitHub"

$DestinoRelatorio = Join-Path $Relatorios "ordens_status.htm"
$DestinoGit = Join-Path $GitHub "ordens_status.htm"

$SapHomeUrl = "https://s4.stout.aurora.ab-inbev.com/sap/bc/ui2/flp#Shell-home"
$LayoutSAP = "/elieserpo"

$TimeoutTela = 60
$TimeoutDownloadMin = 20
$TamanhoMinimoBytes = 5KB

# =========================
# FUNÇÕES VISUAIS
# =========================
function Titulo([string]$Texto) {
    Write-Host ""
    Write-Host "====================================================================" -ForegroundColor Cyan
    Write-Host " $Texto" -ForegroundColor Cyan
    Write-Host "====================================================================" -ForegroundColor Cyan
}
function Etapa([string]$Texto) {
    Write-Host ""
    Write-Host $Texto -ForegroundColor Yellow
}
function Ok([string]$Texto) {
    Write-Host "OK: $Texto" -ForegroundColor Green
}
function Falha([string]$Texto) {
    Write-Host ""
    Write-Host "ERRO: $Texto" -ForegroundColor Red
    throw $Texto
}

# =========================
# VALIDAÇÕES
# =========================
foreach ($p in @($Base,$Downloads,$Relatorios,$GitHub)) {
    if (-not (Test-Path -LiteralPath $p)) { Falha "Pasta não encontrada: $p" }
}
if (-not (Test-Path -LiteralPath $PortalIndex)) {
    Falha "Index do VD não encontrado: $PortalIndex"
}

function Find-Chrome {
    $candidates = @(
        "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
        "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
        "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe"
    )
    foreach ($c in $candidates) {
        if ($c -and (Test-Path -LiteralPath $c)) { return $c }
    }
    return $null
}
$Chrome = Find-Chrome
if (-not $Chrome) { Falha "Google Chrome não encontrado." }

# =========================
# WINDOWS UI AUTOMATION
# =========================
Add-Type -AssemblyName UIAutomationClient
Add-Type -AssemblyName UIAutomationTypes

# V5.9: UI Automation fica limitada SOMENTE à janela ativa do Chrome.
# Isso evita varrer o desktop inteiro, acessar processos protegidos e clicar em outras abas/janelas.
Add-Type @"
using System;
using System.Runtime.InteropServices;
public static class NativeWindowSAP504 {
    [DllImport("user32.dll")]
    public static extern IntPtr GetForegroundWindow();
}
"@

$script:ScopeRoot = $null

function Set-UiaScopeToForeground {
    $h = [NativeWindowSAP504]::GetForegroundWindow()
    if ($h -eq [IntPtr]::Zero) { return $false }
    try {
        $script:ScopeRoot = [System.Windows.Automation.AutomationElement]::FromHandle($h)
        return ($null -ne $script:ScopeRoot)
    } catch {
        return $false
    }
}

function Get-Descendants {
    param([System.Windows.Automation.AutomationElement]$RootElement)
    if (-not $RootElement) { return @() }
    try {
        $cond = [System.Windows.Automation.Condition]::TrueCondition
        return $RootElement.FindAll([System.Windows.Automation.TreeScope]::Descendants, $cond)
    } catch [System.Windows.Automation.ElementNotAvailableException] {
        return @()
    } catch [System.UnauthorizedAccessException] {
        return @()
    } catch {
        return @()
    }
}

function Find-Uia {
    param(
        [string]$NameRegex,
        [string[]]$ControlTypes = @(),
        [int]$TimeoutSeconds = 30
    )

    $limit = (Get-Date).AddSeconds($TimeoutSeconds)
    while ((Get-Date) -lt $limit) {
        if (-not $script:ScopeRoot) {
            Set-UiaScopeToForeground | Out-Null
        }

        $all = Get-Descendants $script:ScopeRoot
        foreach ($e in $all) {
            try {
                $name = $e.Current.Name
                if (-not $name) { continue }
                if ($name -notmatch $NameRegex) { continue }

                if ($ControlTypes.Count -gt 0) {
                    $ct = $e.Current.ControlType.ProgrammaticName
                    $short = $ct -replace '^ControlType\.',''
                    if ($ControlTypes -notcontains $short) { continue }
                }
                return $e
            } catch {}
        }
        Start-Sleep -Milliseconds 500
    }
    return $null
}

function Invoke-Uia {
    param([System.Windows.Automation.AutomationElement]$Element)
    if (-not $Element) { return $false }

    foreach ($patternId in @(
        [System.Windows.Automation.InvokePattern]::Pattern,
        [System.Windows.Automation.SelectionItemPattern]::Pattern,
        [System.Windows.Automation.TogglePattern]::Pattern
    )) {
        try {
            $pattern = $Element.GetCurrentPattern($patternId)
            if ($pattern -is [System.Windows.Automation.InvokePattern]) {
                $pattern.Invoke()
                return $true
            }
            if ($pattern -is [System.Windows.Automation.SelectionItemPattern]) {
                $pattern.Select()
                return $true
            }
            if ($pattern -is [System.Windows.Automation.TogglePattern]) {
                if ($pattern.Current.ToggleState -ne [System.Windows.Automation.ToggleState]::On) {
                    $pattern.Toggle()
                }
                return $true
            }
        } catch {}
    }

    try {
        $Element.SetFocus()
        Add-Type -AssemblyName System.Windows.Forms
        [System.Windows.Forms.SendKeys]::SendWait("{ENTER}")
        return $true
    } catch {
        return $false
    }
}


# Clique físico real no centro do elemento.
# Necessário para ações protegidas pelo Chrome, como navigator.clipboard.writeText(),
# porque InvokePattern do UI Automation não conta como "user gesture" para o navegador.
Add-Type @"
using System;
using System.Runtime.InteropServices;
public static class NativeMouseSAP504 {
    [DllImport("user32.dll")]
    public static extern bool SetCursorPos(int X, int Y);

    [DllImport("user32.dll")]
    public static extern void mouse_event(uint dwFlags, uint dx, uint dy, uint dwData, UIntPtr dwExtraInfo);

    public const uint MOUSEEVENTF_LEFTDOWN = 0x0002;
    public const uint MOUSEEVENTF_LEFTUP   = 0x0004;
}
"@

function Click-UiaReal {
    param([System.Windows.Automation.AutomationElement]$Element)

    if (-not $Element) { return $false }

    try {
        $r = $Element.Current.BoundingRectangle
        if ($r.Width -le 1 -or $r.Height -le 1) { return $false }

        $x = [int]($r.Left + ($r.Width / 2))
        $y = [int]($r.Top  + ($r.Height / 2))

        $Element.SetFocus()
        Start-Sleep -Milliseconds 200

        [NativeMouseSAP504]::SetCursorPos($x,$y) | Out-Null
        Start-Sleep -Milliseconds 150
        [NativeMouseSAP504]::mouse_event([NativeMouseSAP504]::MOUSEEVENTF_LEFTDOWN,0,0,0,[UIntPtr]::Zero)
        Start-Sleep -Milliseconds 80
        [NativeMouseSAP504]::mouse_event([NativeMouseSAP504]::MOUSEEVENTF_LEFTUP,0,0,0,[UIntPtr]::Zero)
        return $true
    } catch {
        return $false
    }
}


function Hover-UiaReal {
    param([System.Windows.Automation.AutomationElement]$Element)
    if (-not $Element) { return $false }
    try {
        $r = $Element.Current.BoundingRectangle
        if ($r.Width -le 1 -or $r.Height -le 1) { return $false }
        $x = [int]($r.Left + ($r.Width / 2))
        $y = [int]($r.Top  + ($r.Height / 2))
        [NativeMouseSAP504]::SetCursorPos($x,$y) | Out-Null
        Start-Sleep -Milliseconds 650
        return $true
    } catch {
        return $false
    }
}

function Set-UiaValue {
    param(
        [System.Windows.Automation.AutomationElement]$Element,
        [string]$Value
    )
    if (-not $Element) { return $false }

    try {
        $vp = $Element.GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern)
        if (-not $vp.Current.IsReadOnly) {
            $vp.SetValue($Value)
            return $true
        }
    } catch {}

    try {
        $Element.SetFocus()
        Add-Type -AssemblyName System.Windows.Forms
        [System.Windows.Forms.SendKeys]::SendWait("^a")
        Set-Clipboard -Value $Value
        [System.Windows.Forms.SendKeys]::SendWait("^v")
        return $true
    } catch {
        return $false
    }
}

function Select-ComboByText {
    param(
        [System.Windows.Automation.AutomationElement]$Combo,
        [string]$TextRegex
    )
    if (-not $Combo) { return $false }

    try {
        $ep = $Combo.GetCurrentPattern([System.Windows.Automation.ExpandCollapsePattern]::Pattern)
        $ep.Expand()
    } catch {
        try { Invoke-Uia $Combo | Out-Null } catch {}
    }

    Start-Sleep -Milliseconds 500

    $item = Find-Uia -NameRegex $TextRegex -ControlTypes @("ListItem","DataItem","Text") -TimeoutSeconds 5
    if ($item) {
        return (Invoke-Uia $item)
    }

    # Fallback: digitação no combo.
    try {
        $Combo.SetFocus()
        Add-Type -AssemblyName System.Windows.Forms
        [System.Windows.Forms.SendKeys]::SendWait("^a")
        [System.Windows.Forms.SendKeys]::SendWait($TextRegex)
        [System.Windows.Forms.SendKeys]::SendWait("{ENTER}")
        return $true
    } catch {
        return $false
    }
}

# =========================
# 1-4. LER ORDENS DIRETO DO INDEX LOCAL
# =========================
# V5.18:
# Não dependemos mais da interface do Portal para abrir "Programação Geral",
# selecionar o mês e clicar em "Copiar ordens do mês selecionado".
# Esse trecho era sensível a foco da janela do Chrome/UI Automation.
#
# A fonte já está no próprio index_programacao_operacional.html:
#     const DEMO = [ ... ]
#
# Portanto, lemos a base embutida diretamente do arquivo, selecionamos o mês
# atual e colocamos as ordens no Clipboard. O resultado é o mesmo do botão do
# Portal, mas sem depender de foco, aba ativa ou acessibilidade do Chrome.

Titulo "ATUALIZAR SAP 504 V5.18 - INDEX DIRETO + UI AUTOMATION SAP"

Etapa "[1/12] Lendo a base de ordens diretamente do Index local..."
Write-Host "Index: $PortalIndex" -ForegroundColor DarkGray

try {
    $htmlPortal = Get-Content -LiteralPath $PortalIndex -Raw -Encoding UTF8
} catch {
    Falha "Não consegui ler o Index do Portal: $($_.Exception.Message)"
}

if (-not $htmlPortal -or $htmlPortal.Length -lt 1000) {
    Falha "O Index foi lido, mas o conteúdo parece vazio ou incompleto."
}
Ok "Index local carregado."

Etapa "[2/12] Extraindo a base SAP embutida do Index..."

# Tenta primeiro a âncora mais segura da versão atual.
$regexPrincipal = 'const\s+DEMO\s*=\s*(\[.*?\]);\s*function\s+criarStorageSeguro'
$matchDemo = [regex]::Match(
    $htmlPortal,
    $regexPrincipal,
    [System.Text.RegularExpressions.RegexOptions]::Singleline
)

# Fallback para futuras versões onde a função seguinte possa mudar de nome.
if (-not $matchDemo.Success) {
    $matchDemo = [regex]::Match(
        $htmlPortal,
        'const\s+DEMO\s*=\s*(\[.*?\]);',
        [System.Text.RegularExpressions.RegexOptions]::Singleline
    )
}

if (-not $matchDemo.Success -or $matchDemo.Groups.Count -lt 2) {
    Falha "Não encontrei a base embutida 'const DEMO = [...]' no Index."
}

$jsonOrdens = $matchDemo.Groups[1].Value
try {
    $baseOrdens = @($jsonOrdens | ConvertFrom-Json)
} catch {
    Falha "Encontrei a base DEMO, mas não consegui interpretar o JSON das ordens: $($_.Exception.Message)"
}

if ($baseOrdens.Count -lt 1) {
    Falha "A base embutida do Index não possui ordens."
}
Ok "$($baseOrdens.Count) ordens encontradas na base embutida."

Etapa "[3/12] Selecionando as ordens do mês atual..."
$agora = Get-Date
$mesAtual = $agora.Month
$anoAtual = $agora.Year
$mesAtualChave = "{0:D4}-{1:D2}" -f $anoAtual,$mesAtual

function Get-OrderDate504 {
    param($OrderObject)

    foreach ($candidate in @($OrderObject.date, $OrderObject.sapDate)) {
        if (-not $candidate) { continue }

        $d = [datetime]::MinValue

        if ([datetime]::TryParseExact(
            [string]$candidate,
            'dd/MM/yyyy',
            [System.Globalization.CultureInfo]::InvariantCulture,
            [System.Globalization.DateTimeStyles]::None,
            [ref]$d
        )) {
            return $d
        }

        if ([datetime]::TryParse(
            [string]$candidate,
            [System.Globalization.CultureInfo]::GetCultureInfo('pt-BR'),
            [System.Globalization.DateTimeStyles]::None,
            [ref]$d
        )) {
            return $d
        }
    }

    return $null
}

$linhasClip = @(
    $baseOrdens |
        ForEach-Object {
            $dataOrdem = Get-OrderDate504 $_
            $numero = ([string]$_.order -replace '\D','').Trim()

            if (
                $dataOrdem -and
                $dataOrdem.Year -eq $anoAtual -and
                $dataOrdem.Month -eq $mesAtual -and
                $numero
            ) {
                $numero
            }
        } |
        Where-Object { $_ -match '^\d+$' } |
        Sort-Object -Unique
)

if ($linhasClip.Count -lt 1) {
    Falha "Nenhuma ordem do mês $mesAtualChave foi encontrada na base embutida do Index."
}

Write-Host "Mês selecionado: $mesAtualChave" -ForegroundColor DarkGray
Ok "$($linhasClip.Count) ordens do mês atual selecionadas."

Etapa "[4/12] Preparando ordens no Clipboard..."
$clip = ($linhasClip -join "`r`n")

try {
    Set-Clipboard -Value $clip
} catch {
    Falha "Não consegui colocar as ordens no Clipboard: $($_.Exception.Message)"
}

# Confere que o Clipboard recebeu a lista atual.
try {
    $clipCheck = Get-Clipboard -Raw -ErrorAction Stop
    $checkLines = @(
        $clipCheck -split "\r?\n" |
        ForEach-Object { $_.Trim() } |
        Where-Object { $_ -match '^\d+$' }
    )

    if ($checkLines.Count -ne $linhasClip.Count) {
        Falha "Validação do Clipboard falhou: esperado $($linhasClip.Count), encontrado $($checkLines.Count)."
    }
} catch {
    Falha "Não consegui validar o Clipboard: $($_.Exception.Message)"
}

Ok "$($linhasClip.Count) ordens preparadas no Clipboard sem abrir o Portal."

# =========================
# 5. ABRIR SAP
# =========================
Etapa "[5/12] Abrindo SAP Aurora pela página inicial..."
Start-Process -FilePath $Chrome -ArgumentList @("--force-renderer-accessibility", "`"$SapHomeUrl`"")
Start-Sleep -Seconds 6

# Reaponta a UI Automation somente para a janela ativa do Chrome/SAP.
if (-not (Set-UiaScopeToForeground)) {
    Falha "SAP abriu, mas não consegui limitar a automação à janela do SAP."
}
Ok "Página inicial do SAP Aurora aberta e isolada para automação."

# V5.8: abre a IW38 pelo TILE real existente na Home do SAP.
# Não usa mais a rota #MaintenanceOrder-changelist, pois o launchpad da fábrica
# retornou erro de resolução do destino.
Etapa "[5.1/12] Abrindo IW38 pelo tile da página inicial do SAP..."

# Procura SOMENTE dentro da janela SAP atualmente ativa.
# Não fecha abas, não usa Ctrl+W e não percorre outras janelas/processos.
$iw38Tile = Find-Uia -NameRegex "(?i)^IW38$|IW38.*Modificar ordens|Modificar ordens.*IW38" -ControlTypes @("Button","Hyperlink","ListItem","DataItem","Text","Custom") -TimeoutSeconds 15

if (-not $iw38Tile) {
    # Fallback sem restringir tipo de controle.
    $iw38Tile = Find-Uia -NameRegex "(?i)^IW38$|IW38.*Modificar ordens|Modificar ordens.*IW38" -TimeoutSeconds 10
}

if (-not $iw38Tile) {
    Falha "Tile IW38 não encontrado na página inicial do SAP."
}

# Tenta clique físico real no tile; InvokePattern como fallback.
if (-not (Click-UiaReal $iw38Tile)) {
    if (-not (Invoke-Uia $iw38Tile)) {
        Falha "Encontrei o tile IW38, mas não consegui abri-lo."
    }
}

Start-Sleep -Seconds 2
Set-UiaScopeToForeground | Out-Null

# Aguarda a tela real da IW38.
$limitIW38 = (Get-Date).AddSeconds(40)
$iw38Loaded = $false

while ((Get-Date) -lt $limitIW38) {
    $probeConcluido = Find-Uia -NameRegex "(?i)^Conclu[ií]do$|Conclu[ií]do" -TimeoutSeconds 1
    $probeHistorico = Find-Uia -NameRegex "(?i)^Hist[oó]rico$|Hist[oó]rico" -TimeoutSeconds 1

    if ($probeConcluido -or $probeHistorico) {
        $iw38Loaded = $true
        break
    }

    Start-Sleep -Milliseconds 700
}

if (-not $iw38Loaded) {
    Falha "O tile IW38 foi clicado, mas a tela real da transação não carregou Concluído/Histórico."
}

Ok "IW38 aberta pelo tile da Home e carregada."

# =========================
# 6. CONCLUÍDO + HISTÓRICO
# =========================
Etapa "[6/12] Marcando Concluído e Histórico..."
$concluido = Find-Uia -NameRegex "(?i)^Conclu[ií]do$|Conclu[ií]do" -TimeoutSeconds 15
$historico = Find-Uia -NameRegex "(?i)^Hist[oó]rico$|Hist[oó]rico" -TimeoutSeconds 15

if (-not $concluido) { Falha "IW38 abriu, mas o controle Concluído não foi encontrado." }
if (-not $historico) { Falha "IW38 abriu, mas o controle Histórico não foi encontrado." }

# Preferência por UI Automation Toggle; clique físico como fallback.
if (-not (Invoke-Uia $concluido)) {
    if (-not (Click-UiaReal $concluido)) { Falha "Não consegui marcar Concluído." }
}
if (-not (Invoke-Uia $historico)) {
    if (-not (Click-UiaReal $historico)) { Falha "Não consegui marcar Histórico." }
}
Ok "Concluído e Histórico marcados."

# =========================
# 7. SELEÇÃO MÚLTIPLA / CLIPBOARD
# =========================
Etapa "[7/12] Colando ordens na seleção múltipla..."
$multi = Find-Uia -NameRegex "(?i)sele[cç][aã]o m[uú]ltipla.*ordem|ordem.*sele[cç][aã]o m[uú]ltipla|valores m[uú]ltiplos" -TimeoutSeconds 15

if (-not $multi) {
    # Fallback: tenta botão genérico próximo ao texto Ordem.
    $multi = Find-Uia -NameRegex "(?i)sele[cç][aã]o m[uú]ltipla|m[uú]ltiplos" -TimeoutSeconds 10
}
if (-not $multi) { Falha "Botão de seleção múltipla do campo Ordem não encontrado." }
Invoke-Uia $multi | Out-Null
Start-Sleep -Seconds 1

$upload = Find-Uia -NameRegex "(?i)clipboard|área de transfer|upload.*clip|Shift\+F12" -TimeoutSeconds 10
if ($upload) {
    Invoke-Uia $upload | Out-Null
} else {
    Add-Type -AssemblyName System.Windows.Forms
    [System.Windows.Forms.SendKeys]::SendWait("+{F12}")
}
Start-Sleep -Seconds 1

$transferir = Find-Uia -NameRegex "(?i)^Transferir$|Transferir.*F8|^F8$" -TimeoutSeconds 10
if ($transferir) {
    Invoke-Uia $transferir | Out-Null
} else {
    Add-Type -AssemblyName System.Windows.Forms
    [System.Windows.Forms.SendKeys]::SendWait("{F8}")
}
Start-Sleep -Seconds 1
Ok "Ordens transferidas."

# =========================
# 8. PERÍODO / LAYOUT / EXECUTAR
# =========================
Etapa "[8/12] Limpando Período e aplicando Layout /elieserpo..."

# Busca edits por nome acessível.
$edits = Get-Descendants $script:ScopeRoot | Where-Object {
    try { $_.Current.ControlType.ProgrammaticName -eq "ControlType.Edit" } catch { $false }
}

$periodos = @()
$layoutEdit = $null
foreach ($e in $edits) {
    try {
        $n = $e.Current.Name
        if ($n -match "(?i)per[ií]odo|data.*de|data.*at[eé]") { $periodos += $e }
        if (-not $layoutEdit -and $n -match "(?i)layout|variante") { $layoutEdit = $e }
    } catch {}
}

# Fallback: campos com valor parecido com data.
if ($periodos.Count -lt 2) {
    foreach ($e in $edits) {
        try {
            $vp = $e.GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern)
            if ($vp.Current.Value -match "^\d{1,2}[./]\d{1,2}[./]\d{2,4}$") {
                $periodos += $e
            }
        } catch {}
    }
}

$periodos | Select-Object -First 2 | ForEach-Object { Set-UiaValue $_ "" | Out-Null }

if (-not $layoutEdit) {
    # Busca edit cujo nome/ajuda contenha Layout.
    $layoutEdit = Find-Uia -NameRegex "(?i)Layout|Variante" -ControlTypes @("Edit") -TimeoutSeconds 10
}
if (-not $layoutEdit) { Falha "Campo Layout não encontrado." }
if (-not (Set-UiaValue $layoutEdit $LayoutSAP)) { Falha "Não consegui preencher Layout." }

$executar = Find-Uia -NameRegex "(?i)^Executar$|Executar.*F8" -TimeoutSeconds 10
if ($executar) {
    Invoke-Uia $executar | Out-Null
} else {
    Add-Type -AssemblyName System.Windows.Forms
    [System.Windows.Forms.SendKeys]::SendWait("{F8}")
}
# V5.15: o SAP pode manter a lista anterior visível por alguns segundos enquanto
# recalcula os status. Cinco segundos se mostraram insuficientes no fluxo automático.
# Esperamos a lista reaparecer e damos uma janela adicional para o grid estabilizar.
$limiteResultado = (Get-Date).AddSeconds(45)
$resultadoPronto = $false
while ((Get-Date) -lt $limiteResultado) {
    Set-UiaScopeToForeground | Out-Null
    $listaPronta = Find-Uia -NameRegex "(?i)Modificar ordens PM:\s*Lista ordens|Lista ordens" -TimeoutSeconds 1
    if ($listaPronta) {
        $resultadoPronto = $true
        break
    }
    Start-Sleep -Milliseconds 700
}
if (-not $resultadoPronto) { Falha "A IW38 foi executada, mas a lista de resultados não ficou pronta." }

# Janela de estabilização: evita exportar a grade antiga antes do refresh dos status.
Write-Host "Aguardando atualização dos status no grid SAP..." -ForegroundColor DarkGray
Start-Sleep -Seconds 12
Set-UiaScopeToForeground | Out-Null
Ok "IW38 executada e relatório estabilizado."

# =========================
# 9. SELECIONAR TODAS
# =========================
Etapa "[9/12] Selecionando todas as ordens do relatório..."

# V5.10: NÃO clicar mais no cabeçalho "Ordem".
# Na V5.9 esse clique podia abrir a primeira ordem da lista.
# O correto é usar o controle de seleção geral/checkbox do grid.

$selecionarTudo = Find-Uia -NameRegex "(?i)^Selecionar$|Selecionar tudo|Marcar tudo|Select all|Selecionar todas" -ControlTypes @("CheckBox","Button","Custom") -TimeoutSeconds 12

if (-not $selecionarTudo) {
    # Fallback: procura qualquer CheckBox do grid próximo ao topo da lista.
    $checks = @(Get-Descendants $script:ScopeRoot | Where-Object {
        try { $_.Current.ControlType.ProgrammaticName -eq "ControlType.CheckBox" } catch { $false }
    })
    if ($checks.Count -gt 0) {
        # Preferimos o checkbox mais alto da tela, típico "selecionar tudo" do cabeçalho.
        $selecionarTudo = $checks | Sort-Object { $_.Current.BoundingRectangle.Top } | Select-Object -First 1
    }
}

if (-not $selecionarTudo) {
    Falha "Controle Selecionar tudo não encontrado no relatório IW38."
}

# Usa Toggle/Invoke no checkbox; clique físico só como fallback.
$okSelect = $false
try {
    $tp = $selecionarTudo.GetCurrentPattern([System.Windows.Automation.TogglePattern]::Pattern)
    if ($tp.Current.ToggleState -ne [System.Windows.Automation.ToggleState]::On) {
        $tp.Toggle()
    }
    $okSelect = $true
} catch {}

if (-not $okSelect) {
    try {
        $ip = $selecionarTudo.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern)
        $ip.Invoke()
        $okSelect = $true
    } catch {}
}

if (-not $okSelect) {
    $okSelect = Click-UiaReal $selecionarTudo
}

if (-not $okSelect) {
    Falha "Encontrei Selecionar tudo, mas não consegui marcar."
}

Start-Sleep -Milliseconds 800

# Segurança: se a automação saiu da lista e abriu uma ordem, interrompe.
$ordemDetalhe = Find-Uia -NameRegex "(?i)Modificar Ordem:\s*1[ªa]\s*tela" -TimeoutSeconds 2
if ($ordemDetalhe) {
    Falha "Uma ordem foi aberta por engano. Exportação interrompida para não operar na tela errada."
}

Ok "Todas as ordens selecionadas no grid."

# =========================
# 10. MENU -> LISTA -> GRAVAR -> FILE
# =========================
Etapa "[10/12] Menu -> Lista -> Gravar -> File..."

# V5.17: exportacao reforcada para variacoes do SAP WebGUI.
# O submenu pode abrir por HOVER, clique, InvokePattern ou seta para a direita,
# dependendo da versao/renderizacao do SAP. Tentamos essas formas em sequencia,
# sem usar coordenadas fixas e sem operar fora da janela SAP ativa.

# Remove temporarios antigos antes de pedir uma nova exportacao.
Get-ChildItem -LiteralPath $Downloads -Filter "filetmp*.htm" -File -ErrorAction SilentlyContinue | ForEach-Object {
    try { Remove-Item -LiteralPath $_.FullName -Force -ErrorAction Stop } catch {}
}

# Confirma que ainda estamos na lista da IW38.
$listaIW38 = Find-Uia -NameRegex "(?i)Modificar ordens PM:\s*Lista ordens|Lista ordens" -TimeoutSeconds 5
if (-not $listaIW38) {
    Falha "Tela Lista ordens da IW38 nao confirmada antes da exportacao."
}

function Find-SapMenuItem {
    param(
        [string]$Regex,
        [int]$TimeoutSeconds = 5
    )

    $item = Find-Uia -NameRegex $Regex -ControlTypes @("MenuItem","ListItem","Button","DataItem","Custom","Text") -TimeoutSeconds $TimeoutSeconds
    if (-not $item) {
        $item = Find-Uia -NameRegex $Regex -TimeoutSeconds 2
    }
    return $item
}

function Try-OpenSapSubmenu {
    param(
        [System.Windows.Automation.AutomationElement]$Item,
        [string]$NextRegex
    )

    if (-not $Item) { return $null }

    # 1) Hover mais longo: comportamento mais comum no SAP WebGUI.
    try {
        $r = $Item.Current.BoundingRectangle
        if ($r.Width -gt 1 -and $r.Height -gt 1) {
            $x = [int]($r.Left + ($r.Width * 0.70))
            $y = [int]($r.Top + ($r.Height / 2))
            [NativeMouseSAP504]::SetCursorPos($x,$y) | Out-Null
            Start-Sleep -Milliseconds 1400
        }
    } catch {}

    $next = Find-SapMenuItem -Regex $NextRegex -TimeoutSeconds 3
    if ($next) { return $next }

    # 2) Seta para a direita com foco no item: abre submenu sem executar acao final.
    try {
        $Item.SetFocus()
        Add-Type -AssemblyName System.Windows.Forms
        [System.Windows.Forms.SendKeys]::SendWait("{RIGHT}")
        Start-Sleep -Milliseconds 900
    } catch {}

    $next = Find-SapMenuItem -Regex $NextRegex -TimeoutSeconds 3
    if ($next) { return $next }

    # 3) Clique fisico. Algumas versoes exigem clique para expandir o submenu.
    try { Click-UiaReal $Item | Out-Null } catch {}
    Start-Sleep -Milliseconds 900

    $next = Find-SapMenuItem -Regex $NextRegex -TimeoutSeconds 3
    if ($next) { return $next }

    # 4) InvokePattern/SelectionItem como ultimo fallback acessivel.
    try { Invoke-Uia $Item | Out-Null } catch {}
    Start-Sleep -Milliseconds 800
    return (Find-SapMenuItem -Regex $NextRegex -TimeoutSeconds 3)
}

function Write-SapMenuDiagnostics {
    try {
        $nomes = @()
        foreach ($e in (Get-Descendants $script:ScopeRoot)) {
            try {
                $n = [string]$e.Current.Name
                if ($n -and $n -match '(?i)menu|lista|list|gravar|salvar|save|file|arquivo|ficheiro|local') {
                    $ct = $e.Current.ControlType.ProgrammaticName -replace '^ControlType\.',''
                    $nomes += "$ct :: $n"
                }
            } catch {}
        }
        if ($nomes.Count -gt 0) {
            Write-Host "Itens de menu visiveis no momento da falha:" -ForegroundColor DarkYellow
            $nomes | Select-Object -Unique | Select-Object -First 30 | ForEach-Object { Write-Host "  $_" -ForegroundColor DarkGray }
        }
    } catch {}
}

Set-UiaScopeToForeground | Out-Null
$menu = Find-SapMenuItem -Regex "(?i)^Menu$" -TimeoutSeconds 15
if (-not $menu) { Falha "Menu do SAP nao encontrado." }

# Abre Menu.
if (-not (Click-UiaReal $menu)) {
    if (-not (Invoke-Uia $menu)) { Falha "Nao consegui abrir o Menu do SAP." }
}
Start-Sleep -Milliseconds 900

# LISTA / LIST
$listaMenu = Find-SapMenuItem -Regex "(?i)^Lista$|^List$" -TimeoutSeconds 8
if (-not $listaMenu) {
    Write-SapMenuDiagnostics
    Falha "Item Lista nao encontrado no Menu."
}

# GRAVAR / SALVAR / SAVE
$regexGravar = '(?i)^Gravar$|^Salvar$|^Save$'
$gravar = Try-OpenSapSubmenu -Item $listaMenu -NextRegex $regexGravar
if (-not $gravar) {
    # Reabre o menu uma vez e tenta Lista por clique direto.
    Set-UiaScopeToForeground | Out-Null
    $menu2 = Find-SapMenuItem -Regex "(?i)^Menu$" -TimeoutSeconds 3
    if ($menu2) { Click-UiaReal $menu2 | Out-Null; Start-Sleep -Milliseconds 700 }
    $listaMenu2 = Find-SapMenuItem -Regex "(?i)^Lista$|^List$" -TimeoutSeconds 4
    if ($listaMenu2) {
        Click-UiaReal $listaMenu2 | Out-Null
        Start-Sleep -Milliseconds 900
        $gravar = Find-SapMenuItem -Regex $regexGravar -TimeoutSeconds 5
    }
}
if (-not $gravar) {
    Write-SapMenuDiagnostics
    Falha "Submenu Gravar/Salvar nao apareceu apos Lista."
}

# FILE / ARQUIVO LOCAL. O nome varia entre SAP GUI/WebGUI e idioma.
$regexFile = '(?i)^File\s*\.{0,3}$|^Arquivo\s*\.{0,3}$|^Ficheiro\s*\.{0,3}$|Local\s+File|Arquivo\s+local|Ficheiro\s+local|Salvar.*arquivo|Gravar.*arquivo'
$file = Try-OpenSapSubmenu -Item $gravar -NextRegex $regexFile

if (-not $file) {
    # Uma tentativa final: clique no Gravar/Salvar e procura novamente com regex ampla.
    try { Click-UiaReal $gravar | Out-Null } catch {}
    Start-Sleep -Milliseconds 1100
    Set-UiaScopeToForeground | Out-Null
    $file = Find-SapMenuItem -Regex $regexFile -TimeoutSeconds 6
}

if (-not $file) {
    Write-SapMenuDiagnostics
    Falha "Opcao File/Arquivo local nao apareceu apos Gravar/Salvar."
}

if (-not (Click-UiaReal $file)) {
    if (-not (Invoke-Uia $file)) { Falha "Encontrei File/Arquivo local, mas nao consegui abrir." }
}
Start-Sleep -Seconds 1
Ok "Menu Lista -> Gravar/Salvar -> File/Arquivo local aberto corretamente."

# =========================
# 11. HTML -> AVANÇAR -> OK
# =========================
Etapa "[11/12] HTML -> Avançar -> OK..."

# V5.15: mantém a correção HTML -> Avançar e reforça espera/validação do relatório.
# IMPORTANTE: não usa TAB/ENTER às cegas, porque o foco do SAP pode cair em Cancelar.
# O script agora localiza o botão Avançar, sobe até o controle Button quando necessário,
# executa clique físico real no centro do botão e só continua se o próximo diálogo aparecer.

Set-UiaScopeToForeground | Out-Null
$html = Find-Uia -NameRegex "^HTML$" -TimeoutSeconds 10
if (-not $html) { Falha "Opção HTML não encontrada." }

# Marca HTML.
$htmlOk = $false
try {
    $tp = $html.GetCurrentPattern([System.Windows.Automation.TogglePattern]::Pattern)
    if ($tp.Current.ToggleState -ne [System.Windows.Automation.ToggleState]::On) {
        $tp.Toggle()
    }
    $htmlOk = $true
} catch {}
if (-not $htmlOk) {
    try {
        $sp = $html.GetCurrentPattern([System.Windows.Automation.SelectionItemPattern]::Pattern)
        $sp.Select()
        $htmlOk = $true
    } catch {}
}
if (-not $htmlOk) { $htmlOk = Click-UiaReal $html }
if (-not $htmlOk) { Falha "Não consegui marcar HTML." }

Start-Sleep -Milliseconds 700
Set-UiaScopeToForeground | Out-Null

# Estratégia V5.14:
# 1) tenta o botão pelo nome;
# 2) se o SAP não expuser o nome, localiza "Cancelar" e escolhe o botão imediatamente à esquerda;
# 3) último fallback: usa a geometria do próprio diálogo, clicando na região do botão Avançar.
# Nunca usa TAB/ENTER às cegas nesta tela.

function Click-XY([int]$X,[int]$Y) {
    try {
        [NativeMouseSAP504]::SetCursorPos($X,$Y) | Out-Null
        Start-Sleep -Milliseconds 180
        [NativeMouseSAP504]::mouse_event([NativeMouseSAP504]::MOUSEEVENTF_LEFTDOWN,0,0,0,[UIntPtr]::Zero)
        Start-Sleep -Milliseconds 80
        [NativeMouseSAP504]::mouse_event([NativeMouseSAP504]::MOUSEEVENTF_LEFTUP,0,0,0,[UIntPtr]::Zero)
        return $true
    } catch { return $false }
}

function Get-ButtonLeftOfCancelar {
    param([System.Windows.Automation.AutomationElement]$Root)
    if (-not $Root) { return $null }
    try {
        $all = Get-Descendants $Root
        $cancel = $null
        foreach ($e in $all) {
            try {
                if ($e.Current.Name -match '(?i)^Cancelar$') { $cancel = $e; break }
            } catch {}
        }
        if (-not $cancel) { return $null }
        $rc = $cancel.Current.BoundingRectangle
        $cy = $rc.Top + ($rc.Height/2)
        $best = $null
        $bestDx = 999999
        foreach ($e in $all) {
            try {
                if ($e -eq $cancel) { continue }
                $ct = $e.Current.ControlType.ProgrammaticName
                if ($ct -ne 'ControlType.Button') { continue }
                $r = $e.Current.BoundingRectangle
                if ($r.Width -le 5 -or $r.Height -le 5) { continue }
                $ey = $r.Top + ($r.Height/2)
                if ([Math]::Abs($ey - $cy) -gt 35) { continue }
                if ($r.Left -ge $rc.Left) { continue }
                $dx = $rc.Left - ($r.Left + $r.Width)
                if ($dx -ge -10 -and $dx -lt $bestDx) { $best = $e; $bestDx = $dx }
            } catch {}
        }
        return $best
    } catch { return $null }
}

function Get-DialogFromElement {
    param([System.Windows.Automation.AutomationElement]$Element)
    $cur = $Element
    $best = $null
    for ($i=0; $i -lt 12 -and $cur; $i++) {
        try {
            $r = $cur.Current.BoundingRectangle
            if ($r.Width -ge 260 -and $r.Width -le 900 -and $r.Height -ge 180 -and $r.Height -le 700) {
                $best = $cur
            }
            $name = $cur.Current.Name
            if ($name -match '(?i)Gravar lista em file') { return $cur }
            $cur = [System.Windows.Automation.TreeWalker]::ControlViewWalker.GetParent($cur)
        } catch { break }
    }
    return $best
}

$avancou = $false

# 1) Pelo nome, quando o Chrome/SAP expõe o botão corretamente.
$avancar = Find-Uia -NameRegex '(?i)Avan[cç]ar' -ControlTypes @('Button') -TimeoutSeconds 3
if (-not $avancar) { $avancar = Find-Uia -NameRegex '(?i)Avan[cç]ar' -TimeoutSeconds 2 }
if ($avancar) {
    $avancou = Click-UiaReal $avancar
}

# 2) Pela posição relativa ao botão Cancelar, sem risco de clicar no próprio Cancelar.
if (-not $avancou) {
    Set-UiaScopeToForeground | Out-Null
    $leftButton = Get-ButtonLeftOfCancelar $script:ScopeRoot
    if ($leftButton) {
        $avancou = Click-UiaReal $leftButton
    }
}

# 3) Geometria do diálogo. A foto/teste confirmou que Avançar fica no rodapé,
# imediatamente antes de Cancelar. Clicamos em ~72% da largura e 91% da altura.
if (-not $avancou) {
    Set-UiaScopeToForeground | Out-Null
    $dlg = Get-DialogFromElement $html
    if ($dlg) {
        try {
            $rd = $dlg.Current.BoundingRectangle
            $x = [int]($rd.Left + ($rd.Width * 0.72))
            $y = [int]($rd.Top  + ($rd.Height * 0.91))
            $avancou = Click-XY $x $y
        } catch {}
    }
}

if (-not $avancou) {
    Falha 'HTML foi marcado, mas não consegui acionar Avançar. Nenhum comando de Cancelar foi enviado.'
}

# Só considera sucesso se a próxima tela realmente abrir.
Start-Sleep -Milliseconds 1200
Set-UiaScopeToForeground | Out-Null
$dialogNome = Find-Uia -NameRegex '(?i)Inserir nome de arquivo para gravar|Nome do arquivo' -TimeoutSeconds 8

if (-not $dialogNome) {
    # Uma segunda tentativa é permitida somente se ainda estivermos no mesmo diálogo.
    Set-UiaScopeToForeground | Out-Null
    $htmlAinda = Find-Uia -NameRegex '^HTML$' -TimeoutSeconds 2
    if ($htmlAinda) {
        $leftButton2 = Get-ButtonLeftOfCancelar $script:ScopeRoot
        if ($leftButton2) {
            Click-UiaReal $leftButton2 | Out-Null
        } else {
            $dlg2 = Get-DialogFromElement $htmlAinda
            if ($dlg2) {
                try {
                    $r2 = $dlg2.Current.BoundingRectangle
                    Click-XY ([int]($r2.Left + ($r2.Width * 0.72))) ([int]($r2.Top + ($r2.Height * 0.91))) | Out-Null
                } catch {}
            }
        }
        Start-Sleep -Milliseconds 1300
        Set-UiaScopeToForeground | Out-Null
        $dialogNome = Find-Uia -NameRegex '(?i)Inserir nome de arquivo para gravar|Nome do arquivo' -TimeoutSeconds 5
    }
}

if (-not $dialogNome) {
    Falha 'HTML continua selecionado, mas a tela seguinte não abriu. O script parou sem clicar em Cancelar.'
}

Ok "Avançar acionado e diálogo de nome aberto."

# NÃO altera o nome do arquivo.
Set-UiaScopeToForeground | Out-Null
$okFinal = Find-Uia -NameRegex "^OK$" -ControlTypes @("Button") -TimeoutSeconds 10
if (-not $okFinal) {
    $okFinal = Find-Uia -NameRegex "^OK$" -TimeoutSeconds 5
}
if (-not $okFinal) { Falha "Diálogo de nome abriu, mas o botão OK final não foi encontrado." }

# Também usa clique físico no OK final; Enter fica apenas como fallback.
$confirmou = Click-UiaReal $okFinal
if (-not $confirmou) {
    try {
        $ip = $okFinal.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern)
        $ip.Invoke()
        $confirmou = $true
    } catch {}
}
if (-not $confirmou) { Falha "Não consegui confirmar o OK final." }

Ok "Download HTML solicitado sem alterar o nome."

# =========================
# 12. DOWNLOAD + GIT
# =========================
Etapa "[12/12] Aguardando HTML, renomeando e enviando ao GitHub..."

$InicioDownload = Get-Date
$Limite = (Get-Date).AddMinutes($TimeoutDownloadMin)
$Arquivo = $null
$UltimoTam = -1
$Estavel = 0

while ((Get-Date) -lt $Limite) {
    $cand = Get-ChildItem -LiteralPath $Downloads -Filter "filetmp*.htm" -File -ErrorAction SilentlyContinue |
        Where-Object { $_.LastWriteTime -ge $InicioDownload.AddSeconds(-20) } |
        Sort-Object LastWriteTime -Descending |
        Select-Object -First 1

    if ($cand) {
        if ($cand.Length -eq $UltimoTam -and $cand.Length -gt 0) { $Estavel++ }
        else { $Estavel = 0; $UltimoTam = $cand.Length }

        if ($Estavel -ge 2) { $Arquivo = $cand; break }
    }
    Start-Sleep -Seconds 2
}

if (-not $Arquivo) { Falha "filetmp*.htm não apareceu em $Downloads." }
if ($Arquivo.Length -lt $TamanhoMinimoBytes) {
    Falha "HTML baixado é pequeno demais: $($Arquivo.Length) bytes."
}

# V5.15: valida o conteúdo antes de substituir o relatório oficial.
# O arquivo precisa conter as ordens enviadas à IW38; tamanho >5 KB sozinho não garante isso.
try {
    $htmlConteudo = Get-Content -LiteralPath $Arquivo.FullName -Raw -ErrorAction Stop
} catch {
    Falha "Não consegui ler o HTML baixado para validar o conteúdo."
}

$ordensEsperadas = @($linhasClip | ForEach-Object { $_.Trim() } | Where-Object { $_ -match '^\d+$' } | Select-Object -Unique)
$ordensEncontradas = 0
$ordensAusentes = New-Object System.Collections.Generic.List[string]
foreach ($ordemEsperada in $ordensEsperadas) {
    if ($htmlConteudo -match [regex]::Escape($ordemEsperada)) {
        $ordensEncontradas++
    } else {
        $ordensAusentes.Add($ordemEsperada)
    }
}

$percentualCobertura = if ($ordensEsperadas.Count -gt 0) { [math]::Round(($ordensEncontradas * 100.0) / $ordensEsperadas.Count, 1) } else { 0 }
Write-Host "Validação do relatório: $ordensEncontradas/$($ordensEsperadas.Count) ordens encontradas ($percentualCobertura%)." -ForegroundColor DarkGray

# Tolerância pequena para diferenças legítimas do SAP, mas bloqueia relatório incompleto/errado.
if ($ordensEsperadas.Count -gt 0 -and $percentualCobertura -lt 95) {
    $amostra = ($ordensAusentes | Select-Object -First 8) -join ', '
    Falha "Relatório SAP incompleto: cobertura de $percentualCobertura%. Ordens ausentes (amostra): $amostra. O arquivo antigo foi preservado."
}

# CONF é o token usado pelo portal para reconhecer execução. Registramos a quantidade
# para tornar o teste visível no terminal e impedir publicação de um HTML sem a coluna/status.
$confMatches = [regex]::Matches($htmlConteudo, '(?i)(^|[^A-Z])CONF([^A-Z]|$)')
$QtdConfNova = $confMatches.Count
Write-Host "Tokens CONF encontrados no novo relatório: $QtdConfNova" -ForegroundColor Cyan
if ($QtdConfNova -eq 0) {
    Falha "O novo HTML não contém nenhum token CONF. Atualização bloqueada para proteger o portal."
}

# Compara com o relatório oficial anterior. Uma queda grande costuma indicar exportação
# antes de o SAP terminar o refresh. Não bloqueia pequenas variações legítimas.
if (Test-Path -LiteralPath $DestinoRelatorio) {
    try {
        $htmlAnterior = Get-Content -LiteralPath $DestinoRelatorio -Raw -ErrorAction Stop
        $QtdConfAnterior = [regex]::Matches($htmlAnterior, '(?i)(^|[^A-Z])CONF([^A-Z]|$)').Count
        Write-Host "Tokens CONF no relatório anterior: $QtdConfAnterior" -ForegroundColor DarkGray
        if ($QtdConfAnterior -ge 5 -and $QtdConfNova -lt [math]::Floor($QtdConfAnterior * 0.80)) {
            Falha "Proteção ativada: CONF caiu de $QtdConfAnterior para $QtdConfNova. O relatório antigo foi preservado; rode novamente após o SAP estabilizar."
        }
    } catch {
        if ($_.Exception.Message -like 'Proteção ativada:*') { throw }
        Write-Host "Aviso: não foi possível comparar CONF com o relatório anterior." -ForegroundColor Yellow
    }
}

if (Test-Path -LiteralPath $DestinoRelatorio) {
    Remove-Item -LiteralPath $DestinoRelatorio -Force
}
Move-Item -LiteralPath $Arquivo.FullName -Destination $DestinoRelatorio -Force
Ok "Relatório salvo como ordens_status.htm."

# Atualiza também a base embutida do Index local do VD.
# Isso elimina o problema em que ordens_status.htm era renovado, mas o Index continuava
# exibindo os status antigos até uma importação manual. A rotina Node preserva programação
# (data programada, responsável, célula etc.) e altera somente campos vindos do SAP.
$AtualizadorIndex = Join-Path (Join-Path $Base "Atualizar SAP") "atualizar_index_local.js"
if (Test-Path -LiteralPath $AtualizadorIndex) {
    try {
        & node $AtualizadorIndex --index $PortalIndex --report $DestinoRelatorio
        if ($LASTEXITCODE -eq 0) {
            Ok "Index local sincronizado automaticamente com o novo relatório SAP."
        } else {
            Write-Host "Aviso: relatório SAP foi atualizado, mas a sincronização do Index local retornou código $LASTEXITCODE." -ForegroundColor Yellow
        }
    } catch {
        Write-Host "Aviso: relatório SAP foi atualizado, mas não foi possível sincronizar o Index local: $($_.Exception.Message)" -ForegroundColor Yellow
    }
} else {
    Write-Host "Aviso: atualizar_index_local.js não encontrado. O relatório foi preservado normalmente." -ForegroundColor Yellow
}

# Git.exe conhecido no VD.
$GitExe = @(
    "$env:LOCALAPPDATA\Programs\Git\cmd\git.exe",
    "$env:ProgramFiles\Git\cmd\git.exe",
    "${env:ProgramFiles(x86)}\Git\cmd\git.exe"
) | Where-Object { $_ -and (Test-Path -LiteralPath $_) } | Select-Object -First 1

if (-not $GitExe) { Falha "git.exe não encontrado." }

Set-Location -LiteralPath $GitHub

& $GitExe config --global user.name "Gaps Designe"
& $GitExe config --global user.email "guilhermegaps91@gmail.com"
& $GitExe config --global --add safe.directory "$GitHub" 2>$null | Out-Null

& $GitExe fetch origin main
if ($LASTEXITCODE -ne 0) { Falha "git fetch falhou. O relatório e o Index local já foram atualizados; falta apenas sincronizar o servidor." }

# A correção V5.16 inclui uma alteração única no index.html e no workflow para que
# o servidor passe a consumir ordens_status.htm automaticamente. Se esses arquivos
# ainda estiverem modificados localmente, guarda-os durante o pull e reaplica depois.
$InfraStashed = $false
$InfraStatus = & $GitExe status --porcelain -- "index.html" ".github/workflows/deploy-portal.yml"
if ($InfraStatus) {
    & $GitExe stash push -m "portal504-v516-infra" -- "index.html" ".github/workflows/deploy-portal.yml" | Out-Null
    if ($LASTEXITCODE -ne 0) { Falha "Não consegui proteger as correções locais de index/workflow antes do pull." }
    $InfraStashed = $true
}

& $GitExe pull --rebase origin main
if ($LASTEXITCODE -ne 0) {
    if ($InfraStashed) { & $GitExe stash pop | Out-Null }
    Falha "git pull --rebase falhou."
}

if ($InfraStashed) {
    & $GitExe stash pop
    if ($LASTEXITCODE -ne 0) { Falha "Conflito ao reaplicar a correção V5.16 de index/workflow." }
}

Copy-Item -LiteralPath $DestinoRelatorio -Destination $DestinoGit -Force

& $GitExe add -- "ordens_status.htm" "index.html" ".github/workflows/deploy-portal.yml"
if ($LASTEXITCODE -ne 0) { Falha "git add falhou." }

& $GitExe diff --cached --quiet
if ($LASTEXITCODE -eq 0) {
    Ok "Arquivo não mudou; GitHub já estava atualizado."
} else {
    $DataCommit = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    & $GitExe commit -m "Atualiza status das ordens SAP - $DataCommit"
    if ($LASTEXITCODE -ne 0) { Falha "git commit falhou." }

    & $GitExe push origin main
    if ($LASTEXITCODE -ne 0) { Falha "git push falhou." }

    Ok "Push concluído em origin/main."
}

Titulo "V5.16 CONCLUÍDA - PORTAL + SAP + INDEX + GITHUB"
Write-Host "GitHub Actions assumirá o deploy." -ForegroundColor Green
