@echo off
setlocal EnableExtensions
cls
title Teste Manutencao 504 V3
where node >nul 2>nul
if errorlevel 1 (
  echo [ERRO] Node.js nao foi encontrado.
  pause
  exit /b 1
)
node "%~dp0arquivos\testar_manutencao.js"
set "RC=%ERRORLEVEL%"
echo.
echo Codigo de saida: %RC%
pause
exit /b %RC%
