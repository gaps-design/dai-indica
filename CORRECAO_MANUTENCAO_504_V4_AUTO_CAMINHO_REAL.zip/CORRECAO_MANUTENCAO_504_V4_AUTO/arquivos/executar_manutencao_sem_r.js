"use strict";

const fs = require("fs");
const path = require("path");
const cp = require("child_process");

const SCRIPT_NAME = "Atualizar_SAP_504_V5_14.ps1";
const scriptPath = path.join(__dirname, SCRIPT_NAME);

function fail(msg) {
  console.error("[MANUTENCAO] ERRO:", msg);
  process.exit(1);
}

if (!fs.existsSync(scriptPath)) {
  fail(`Script nao encontrado: ${scriptPath}`);
}

let psCode;
try {
  psCode = fs.readFileSync(scriptPath, "utf8").replace(/^\uFEFF/, "");
} catch (e) {
  fail(`Nao consegui ler o PS1: ${e.message}`);
}

// O arquivo PS1 da unidade N: e apenas LIDO pelo Node.
// O PowerShell recebe o CONTEUDO em memoria por -EncodedCommand.
// Assim o Windows nao tenta executar o arquivo de rede por -File.
const safeDir = __dirname.replace(/'/g, "''");
const bootstrap = [
  "$ErrorActionPreference = 'Stop'",
  `Set-Location -LiteralPath '${safeDir}'`,
  psCode
].join("\r\n");

const encoded = Buffer.from(bootstrap, "utf16le").toString("base64");
const args = [
  "-NoLogo",
  "-NoProfile",
  "-NonInteractive",
  "-ExecutionPolicy", "Bypass",
  "-EncodedCommand", encoded
];

console.log("============================================================");
console.log(" MANUTENCAO 504 - EXECUCAO SEM R");
console.log(" PowerShell em memoria / EncodedCommand");
console.log(" Nao usa -File para o PS1 da unidade N:");
console.log("============================================================");

const child = cp.spawn("powershell.exe", args, {
  cwd: __dirname,
  stdio: "inherit",
  windowsHide: false,
  shell: false,
  env: { ...process.env, PORTAL504_CENTRAL: "1", PORTAL504_MAINT_SEM_R: "1" }
});

child.on("error", err => fail(`Nao consegui iniciar o PowerShell: ${err.message}`));
child.on("close", code => process.exit(Number.isInteger(code) ? code : 1));
