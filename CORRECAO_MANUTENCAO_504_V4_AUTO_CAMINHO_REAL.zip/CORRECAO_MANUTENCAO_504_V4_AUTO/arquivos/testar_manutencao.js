"use strict";
const fs = require("fs");
const path = require("path");
const cp = require("child_process");

const ROOT = String.raw`N:\Packaging\Compartilhado\Retornável\Usuarios\Guilherme A`;
const candidates = [
  path.join(ROOT, "Lobby", "Portal manutenção", "Atualizar SAP"),
  path.join(ROOT, "Portal manutenção", "Atualizar SAP")
];
let dir = candidates.find(d => fs.existsSync(path.join(d, "executar_manutencao_sem_r.js")));
if (!dir) {
  console.error("[ERRO] Launcher nao encontrado. Execute primeiro APLICAR_CORRECAO_MANUTENCAO_V4.bat");
  candidates.forEach(x => console.error(" -", x));
  process.exit(1);
}
const launcher = path.join(dir, "executar_manutencao_sem_r.js");
console.log("Testando motor da Manutencao sem passar pela Central...");
console.log("Diretorio:", dir);
const c = cp.spawn("node", [launcher], { cwd: dir, stdio: "inherit", shell: false, windowsHide: false });
c.on("error", e => { console.error(e.message); process.exit(1); });
c.on("close", code => process.exit(Number.isInteger(code) ? code : 1));
