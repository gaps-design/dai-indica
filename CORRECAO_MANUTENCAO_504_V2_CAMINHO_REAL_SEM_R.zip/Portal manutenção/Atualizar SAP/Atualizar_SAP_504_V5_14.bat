@echo off
setlocal EnableExtensions
title Atualizar SAP 504 V5.14 - Compatibilidade Central / Motor V5.15
cd /d "%~dp0"

REM ================================================================
REM COMPATIBILIDADE COM A CENTRAL 504
REM A Central procura o nome V5_14, mas este arquivo executa o
REM mesmo motor corrigido da V5.15, sem prompt [N]/[R].
REM O .PS1 e lido como texto e executado em memoria, evitando
REM executar diretamente um script da unidade N: com -File.
REM ================================================================

set "SAP504_PS1=%~dp0Atualizar_SAP_504_V5_14.ps1"

if not exist "%SAP504_PS1%" (
  echo ERRO: arquivo PowerShell nao encontrado:
  echo %SAP504_PS1%
  endlocal
  exit /b 2
)

powershell.exe -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; try { $code = Get-Content -LiteralPath $env:SAP504_PS1 -Raw -ErrorAction Stop; $sb = [ScriptBlock]::Create($code); $null = $sb.Invoke(); exit 0 } catch { Write-Host ''; Write-Host ('ERRO: ' + $_.Exception.Message) -ForegroundColor Red; exit 1 }"

set "RC=%ERRORLEVEL%"
endlocal & exit /b %RC%
