(function () {
  const config = {
    url: window.PG_SUPABASE_URL || "https://fldfgdzunwnihykzsxuf.supabase.co",
    key: window.PG_SUPABASE_KEY || "sb_publishable_uAniI69xGBmWaEkMQahVNw_07pNibYz"
  };

  window.PG_SUPABASE_URL = config.url;
  window.PG_SUPABASE_KEY = config.key;

  const configurado = Boolean(
    window.supabase &&
    config.url &&
    config.key &&
    config.key !== "COLE_AQUI_SUA_PUBLISHABLE_KEY"
  );

  window.PG_SUPABASE_CONFIGURADO = configurado;
  window.pgSupabase = configurado
    ? window.supabase.createClient(config.url, config.key, {
        auth: { persistSession: false, autoRefreshToken: false }
      })
    : null;

  if (!configurado) {
    console.warn("Supabase não configurado. Dados operacionais não serão carregados nem salvos.");
  }
})();
