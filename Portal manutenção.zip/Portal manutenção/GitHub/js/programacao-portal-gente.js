(function (root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  else root.ProgramacaoPortalGente = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  const STATUS_BH_INVALIDOS = new Set([
    "pendente",
    "aguardando_aprovacao",
    "solicitado",
    "recusado",
    "reprovado",
    "cancelado",
    "cancelada",
    "invalidado",
    "invalido",
    "excluido",
    "teste",
    "rollback"
  ]);

  const PADROES_ESCALA = {
    "5x2 - 6x1": [5, 2, 6, 1],
    "6x1 - 5x3": [6, 1, 5, 3],
    "5x1 - 6x3": [5, 1, 6, 3],
    "6x3 - 5x1": [6, 3, 5, 1]
  };

  function texto(valor) {
    return String(valor ?? "").trim();
  }

  function normalizar(valor) {
    return texto(valor)
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .toUpperCase()
      .replace(/[^A-Z0-9]+/g, " ")
      .trim();
  }

  function dataISO(valor) {
    if (valor instanceof Date && !Number.isNaN(valor.valueOf())) {
      const ano = valor.getFullYear();
      const mes = String(valor.getMonth() + 1).padStart(2, "0");
      const dia = String(valor.getDate()).padStart(2, "0");
      return `${ano}-${mes}-${dia}`;
    }
    const entrada = texto(valor).slice(0, 10);
    if (/^\d{4}-\d{2}-\d{2}$/.test(entrada)) return entrada;
    const br = entrada.match(/^(\d{1,2})[/.\-](\d{1,2})[/.\-](\d{4})$/);
    if (br) return `${br[3]}-${br[2].padStart(2, "0")}-${br[1].padStart(2, "0")}`;
    return "";
  }

  function idRegistro(item = {}) {
    return item.funcionario_id ?? item.funcionarioId ?? item.operadorId ?? item.employee_id ?? item.id_funcionario
      ?? item.dados?.funcionario_id ?? item.dados?.funcionarioId ?? item.dados?.operadorId ?? null;
  }

  function idsIguais(a, b) {
    return texto(a) !== "" && texto(a) === texto(b);
  }

  function inicioRegistro(item = {}) {
    return dataISO(item.inicio ?? item.dataInicio ?? item.data_inicio ?? item.data_referencia ?? item.data
      ?? item.dados?.inicio ?? item.dados?.dataInicio ?? item.dados?.data_inicio ?? item.dados?.data);
  }

  function fimRegistro(item = {}) {
    return dataISO(item.fim ?? item.dataFim ?? item.data_fim ?? item.data_referencia ?? item.data
      ?? item.dados?.fim ?? item.dados?.dataFim ?? item.dados?.data_fim ?? item.dados?.data) || inicioRegistro(item);
  }

  function dataNoIntervalo(data, inicio, fim) {
    const alvo = dataISO(data);
    const de = dataISO(inicio);
    const ate = dataISO(fim) || de;
    return Boolean(alvo && de && alvo >= de && alvo <= ate);
  }

  function registroCancelado(item = {}) {
    const status = normalizar(item.status ?? item.statusAtual ?? item.status_atual);
    return ["CANCELADO", "CANCELADA", "RECUSADO", "REPROVADO", "EXCLUIDO", "INVALIDADO"].includes(status)
      || item.cancelado === true
      || item.excluido === true;
  }

  function listaMaquinas(valor) {
    if (!Array.isArray(valor)) return [];
    return valor
      .map(item => typeof item === "string" ? item : item?.nome ?? item?.maquina ?? item?.equipamento)
      .map(texto)
      .filter(Boolean);
  }

  function chaveMaquina(valor) {
    const nome = normalizar(valor);
    if (!nome || nome.includes("NAO IDENTIFICADO") || nome === "A DEFINIR") return "";
    if (nome === "LGF" || nome.includes("LAVADORA GARRAF")) return "LAVADORA";
    if (nome.includes("TRANSP UIP") || nome.includes("ENCHEDORA")) return "ENCHEDORA";
    if (nome.includes("INSPETOR") || nome.startsWith("INSP ") || nome.includes("INSP GARRAF")) return "INSPETOR ELETRONICO";
    if (nome.includes("DESPALET")) return "DESPALETIZADORA";
    if (nome.includes("DESENCAIX")) return "DESENCAIXOTADORA";
    if (nome.includes("ENCAIX")) return "ENCAIXOTADORA";
    if (nome.includes("PASTEUR")) return "PASTEURIZADOR";
    if (nome.includes("ROTUL")) return "ROTULADORA";
    if (nome.includes("PALET") && (nome.includes("02") || nome.includes("CARTAO"))) return "PALETIZADORA 02";
    if (nome.includes("PALET")) return "PALETIZADORA RET";
    if (nome.includes("EMPACOT")) return "EMPACOTADORA";
    if (nome.includes("ENVOLV")) return "ENVOLVEDORA";
    if (nome.includes("CINTAD")) return "CINTADORA";
    return nome.replace(/\b0?\d\b/g, "").replace(/\s+/g, " ").trim();
  }

  function maquinaCompativel(operador, maquina) {
    const alvo = chaveMaquina(maquina);
    if (!alvo) return true;
    return (operador.machines || operador.maquinas || []).some(item => chaveMaquina(item) === alvo);
  }

  function turnoTexto(valor, turnoId) {
    const informado = texto(valor);
    const numero = Number(turnoId) || Number((informado.match(/[123]/) || [])[0]);
    return numero ? `${numero}º Turno` : informado || "A definir";
  }

  function turnoIdDo(valor, turnoId) {
    return Number(turnoId) || Number((texto(valor).match(/[123]/) || [])[0]) || null;
  }

  function numeroCelula(valor) {
    return Number((texto(valor).match(/[123]/) || [])[0]) || 0;
  }

  function grupoOperacional(celula, maquinas) {
    const numero = numeroCelula(celula);
    if (numero === 1 && maquinas.some(item => chaveMaquina(item) === "LAVADORA")) return "LGF";
    if (numero === 1) return "Frente";
    if (numero === 2) return "Meio";
    if (numero === 3) return "Fundo";
    const chaves = maquinas.map(chaveMaquina);
    if (chaves.includes("LAVADORA")) return "LGF";
    if (chaves.some(item => ["ENCHEDORA", "INSPETOR ELETRONICO"].includes(item))) return "Frente";
    if (chaves.some(item => ["PASTEURIZADOR", "ROTULADORA"].includes(item))) return "Meio";
    if (chaves.some(item => ["DESPALETIZADORA", "ENCAIXOTADORA", "DESENCAIXOTADORA", "EMPACOTADORA", "PALETIZADORA RET", "PALETIZADORA 02"].includes(item))) return "Fundo";
    return "A definir";
  }

  function funcionarioOperacional(item = {}) {
    const valor = item.operacional ?? item.pertence_qlp ?? item.pertenceQlp ?? item.dados?.operacional;
    if (valor !== undefined && valor !== null && valor !== "") return valor === true || texto(valor).toLowerCase() === "true";
    return normalizar(item.tipo_acesso ?? item.tipoAcesso ?? "operador") === "OPERADOR";
  }

  function funcionarioAtivo(item = {}) {
    const status = normalizar(item.statusAtual ?? item.status_atual ?? item.status);
    return item.ativo !== false
      && item.dados?.ativo !== false
      && item.excluido !== true
      && item.dados?.excluido !== true
      && status !== "INATIVO";
  }

  function criarBase(base = {}, complemento = {}) {
    const matrizPorOperador = new Map();
    (base.matrizHabilidades || base.matriz_habilidades || []).forEach(item => {
      const id = idRegistro(item);
      const maquinas = listaMaquinas(item.maquinas ?? item.dados?.maquinas);
      if (id !== null) matrizPorOperador.set(texto(id), maquinas);
    });

    const origem = Array.isArray(base.funcionarios) && base.funcionarios.length
      ? base.funcionarios
      : (base.operadores || []);
    const vistos = new Set();
    const operadores = origem.filter(item => {
      const id = texto(item.id ?? item.funcionario_id);
      if (!id || vistos.has(id) || !funcionarioOperacional(item) || !funcionarioAtivo(item)) return false;
      vistos.add(id);
      return true;
    }).map(item => {
      const id = item.id ?? item.funcionario_id;
      const maquinas = [...new Set([
        texto(item.maquinaPrincipal ?? item.maquina_principal),
        ...listaMaquinas(item.maquinasApto),
        ...listaMaquinas(item.maquinasAptas),
        ...(matrizPorOperador.get(texto(id)) || [])
      ].filter(Boolean))];
      const turnoId = turnoIdDo(item.turno, item.turno_id ?? item.turnoId);
      return {
        id,
        name: texto(item.nomeCompleto ?? item.nome).toUpperCase(),
        shift: turnoTexto(item.turno, turnoId),
        shiftId: turnoId,
        cell: numeroCelula(item.celula),
        cellLabel: texto(item.celula),
        group: grupoOperacional(item.celula, maquinas),
        machines: maquinas,
        primaryMachine: texto(item.maquinaPrincipal ?? item.maquina_principal),
        active: funcionarioAtivo(item),
        operational: funcionarioOperacional(item),
        status: texto(item.statusAtual ?? item.status_atual ?? "Ativo") || "Ativo",
        schedule: texto(item.escalaFuncionario ?? item.escala_funcionario),
        scheduleStart: dataISO(item.dataInicioEscala ?? item.data_inicio_escala),
        vacationStart: dataISO(item.feriasInicio ?? item.ferias_inicio),
        vacationEnd: dataISO(item.feriasFim ?? item.ferias_fim),
        leaveStart: dataISO(item.atestadoInicio ?? item.atestado_inicio),
        leaveEnd: dataISO(item.atestadoFim ?? item.atestado_fim),
        raw: item
      };
    });

    return {
      operators: operadores,
      operatorById: new Map(operadores.map(item => [texto(item.id), item])),
      vacations: base.ferias || [],
      leaves: base.atestados || base.afastamentos || [],
      bh: base.lancamentosBH || base.bh_lancamentos || [],
      scheduleEntries: base.escalaMensal || base.escala || [],
      temporaryShifts: complemento.turnosTemporarios || complemento.turnos_temporarios || [],
      loadedAt: new Date().toISOString()
    };
  }

  function registroDoOperador(item, operadorId) {
    return idsIguais(idRegistro(item), operadorId);
  }

  function buscarNoPeriodo(lista, operadorId, data) {
    return (lista || []).find(item => registroDoOperador(item, operadorId)
      && !registroCancelado(item)
      && dataNoIntervalo(data, inicioRegistro(item), fimRegistro(item)));
  }

  function bhConfirmado(item = {}) {
    const tipo = normalizar(item.tipo ?? item.dados?.tipo ?? item.tipo_registro ?? "BH");
    const status = normalizar(item.status ?? item.statusAtual ?? item.status_atual ?? item.dados?.status ?? "confirmado").toLowerCase().replace(/\s+/g, "_");
    const origem = normalizar(item.origem ?? item.dados?.origem);
    return tipo === "BH"
      && !STATUS_BH_INVALIDOS.has(status)
      && !origem.includes("TESTE")
      && !origem.includes("DIAGNOSTICO")
      && item.invalidado !== true
      && item.cancelado !== true
      && item.excluido !== true;
  }

  function buscarBH(base, operadorId, data) {
    return (base.bh || []).find(item => registroDoOperador(item, operadorId)
      && bhConfirmado(item)
      && dataNoIntervalo(data, inicioRegistro(item), fimRegistro(item)));
  }

  function turnoEfetivo(operador, data, base) {
    const temporario = (base.temporaryShifts || []).find(item => registroDoOperador(item, operador.id)
      && item.ativo !== false
      && dataNoIntervalo(data, inicioRegistro(item), fimRegistro(item)));
    if (!temporario) return operador.shift;
    return turnoTexto(
      temporario.turnoTemporario ?? temporario.turno_temporario ?? temporario.turno,
      temporario.turno_id ?? temporario.turnoId
    );
  }

  function statusEscalaSalvo(base, operadorId, data) {
    const item = (base.scheduleEntries || []).find(registro => registroDoOperador(registro, operadorId)
      && dataISO(registro.data ?? registro.data_referencia) === dataISO(data));
    return normalizar(item?.status ?? item?.dados?.status);
  }

  function diaDeTrabalho(operador, data) {
    const padrao = PADROES_ESCALA[operador.schedule];
    const alvo = dataISO(data);
    if (!padrao || !alvo || !operador.scheduleStart) return true;
    const marco = new Date(`${operador.scheduleStart}T12:00:00`);
    const atual = new Date(`${alvo}T12:00:00`);
    const diferenca = Math.floor((atual - marco) / 86400000);
    const ciclo = padrao.reduce((total, valor) => total + valor, 0);
    const posicao = ((diferenca % ciclo) + ciclo) % ciclo;
    return posicao < padrao[0] || (posicao >= padrao[0] + padrao[1] && posicao < padrao[0] + padrao[1] + padrao[2]);
  }

  function disponibilidade(operadorOuId, data, base) {
    const operador = typeof operadorOuId === "object"
      ? operadorOuId
      : base.operatorById.get(texto(operadorOuId));
    if (!operador || !operador.active || !operador.operational) {
      return { available: false, code: "inativo", label: "Inativo", source: "funcionarios" };
    }

    if (["ATESTADO", "AFASTADO"].includes(normalizar(operador.status))) {
      return { available: false, code: "afastado", label: "Afastado", source: "funcionarios" };
    }

    const afastamentoCadastro = dataNoIntervalo(data, operador.leaveStart, operador.leaveEnd);
    if (afastamentoCadastro || buscarNoPeriodo(base.leaves, operador.id, data)) {
      return { available: false, code: "afastado", label: "Afastado", source: "atestados" };
    }

    const feriasCadastro = dataNoIntervalo(data, operador.vacationStart, operador.vacationEnd);
    if (feriasCadastro || buscarNoPeriodo(base.vacations, operador.id, data)) {
      return { available: false, code: "ferias", label: "Férias", source: "ferias" };
    }

    if (buscarBH(base, operador.id, data)) {
      return { available: false, code: "bh", label: "BH", source: "bh_lancamentos" };
    }

    const escala = statusEscalaSalvo(base, operador.id, data);
    if (["ATESTADO", "AFASTADO"].includes(escala)) return { available: false, code: "afastado", label: "Afastado", source: "escala" };
    if (["FERIAS", "FERIAS PROGRAMADAS"].includes(escala)) return { available: false, code: "ferias", label: "Férias", source: "escala" };
    if (escala === "BH") return { available: false, code: "bh", label: "BH", source: "escala" };
    if (["F", "FOLGA"].includes(escala) || (!escala && !diaDeTrabalho(operador, data))) {
      return { available: false, code: "folga", label: "Folga", source: "escala" };
    }

    return { available: true, code: "disponivel", label: "Disponível", source: "funcionarios" };
  }

  function operadoresElegiveis(criterios = {}, base) {
    const data = dataISO(criterios.date ?? criterios.data);
    const turno = turnoTexto(criterios.shift ?? criterios.turno, criterios.shiftId ?? criterios.turno_id);
    const filtrarTurno = turno !== "A definir";
    const celula = numeroCelula(criterios.cell ?? criterios.celula);
    const nome = normalizar(criterios.operator ?? criterios.operador);
    const elegiveis = [];
    const indisponiveis = [];

    (base.operators || []).forEach(operador => {
      const status = disponibilidade(operador, data, base);
      let motivo = status;
      if (status.available && filtrarTurno && turnoEfetivo(operador, data, base) !== turno) {
        motivo = { available: false, code: "outro_turno", label: `Outro turno (${turnoEfetivo(operador, data, base)})`, source: "turno" };
      } else if (status.available && celula && operador.cell !== celula) {
        motivo = { available: false, code: "outra_celula", label: `Outra célula (${operador.cellLabel || "não informada"})`, source: "funcionarios" };
      } else if (status.available && criterios.machine && !maquinaCompativel(operador, criterios.machine)) {
        motivo = { available: false, code: "sem_aptidao", label: "Sem aptidão para a máquina", source: "matriz_habilidades" };
      } else if (status.available && nome && !normalizar(operador.name).includes(nome)) {
        motivo = { available: false, code: "outro_operador", label: "Fora do filtro de operador", source: "filtro" };
      }

      const item = { ...operador, availability: motivo, effectiveShift: turnoEfetivo(operador, data, base) };
      if (motivo.available) elegiveis.push(item);
      else indisponiveis.push(item);
    });

    const ordenar = (a, b) => a.name.localeCompare(b.name, "pt-BR");
    return { eligible: elegiveis.sort(ordenar), unavailable: indisponiveis.sort(ordenar) };
  }

  function operadorPorNome(base, nome) {
    const procurado = normalizar(nome);
    return (base.operators || []).find(item => normalizar(item.name) === procurado) || null;
  }

  function preservarResponsavelHistorico(ordem = {}) {
    return Boolean(texto(ordem.owner ?? ordem.responsavel ?? ordem.executante)
      && /(^|\s)CONF(\s|$)/i.test(texto(ordem.sap ?? ordem.status_sistema)));
  }

  function vincularResponsavel(ordem = {}, base = {}) {
    const idInformado = texto(ordem.ownerId ?? ordem.operator_id ?? ordem.operador_id);
    const nomeInformado = [ordem.owner, ordem.responsavel, ordem.executante, ordem.ownerSnapshot]
      .map(texto)
      .find(Boolean) || "";
    const porId = idInformado ? base.operatorById?.get(idInformado) : null;
    const porNome = porId || operadorPorNome(base, nomeInformado);

    if (porNome) {
      return {
        classification: "funcionario_real",
        operator: porNome,
        operatorId: porNome.id,
        name: porNome.name
      };
    }
    if (!idInformado && !nomeInformado) {
      return { classification: "sem_responsavel", operator: null, operatorId: null, name: "" };
    }
    if (preservarResponsavelHistorico({ ...ordem, owner: nomeInformado })) {
      return {
        classification: "historico_nao_vinculado",
        operator: null,
        operatorId: null,
        name: nomeInformado
      };
    }
    return {
      classification: "registro_sem_correspondencia",
      operator: null,
      operatorId: null,
      name: ""
    };
  }

  function nomeResponsavelExibicao(ordem = {}, base = {}) {
    const vinculo = vincularResponsavel(ordem, base);
    return vinculo.classification === "funcionario_real"
      || vinculo.classification === "historico_nao_vinculado"
      ? vinculo.name
      : "";
  }

  return {
    STATUS_BH_INVALIDOS,
    criarBase,
    dataISO,
    dataNoIntervalo,
    disponibilidade,
    getOperatorAvailability: disponibilidade,
    operadoresElegiveis,
    getEligibleOperators: operadoresElegiveis,
    turnoEfetivo,
    getEffectiveShift: turnoEfetivo,
    maquinaCompativel,
    chaveMaquina,
    operadorPorNome,
    preservarResponsavelHistorico,
    vincularResponsavel,
    nomeResponsavelExibicao,
    normalizar
  };
});
