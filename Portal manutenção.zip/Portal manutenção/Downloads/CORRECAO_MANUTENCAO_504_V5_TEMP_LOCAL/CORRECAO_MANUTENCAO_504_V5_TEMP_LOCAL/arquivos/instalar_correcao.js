"use strict";

const fs = require("fs");
const path = require("path");
const cp = require("child_process");

const ROOT = String.raw`N:\Packaging\Compartilhado\Retornável\Usuarios\Guilherme A`;

const CENTRAL_CANDIDATES = [
  path.join(ROOT, "Portal Indicadores", "_sistema", "Central Atualizacoes"),
  path.join(ROOT, "Lobby", "Portal Indicadores", "_sistema", "Central Atualizacoes")
];
const MAINT_CANDIDATES = [
  path.join(ROOT, "Lobby", "Portal manutenção", "Atualizar SAP"),
  path.join(ROOT, "Portal manutenção", "Atualizar SAP")
];

const LAUNCHER_NAME = "executar_manutencao_sem_r.js";
const SOURCE_LAUNCHER = path.join(__dirname, LAUNCHER_NAME);

function fail(msg) { console.error("[INSTALADOR] ERRO:", msg); process.exit(1); }
function ok(msg) { console.log("[OK]", msg); }
function findDir(candidates, requiredFile) {
  for (const dir of candidates) {
    if (!fs.existsSync(dir)) continue;
    if (!requiredFile || fs.existsSync(path.join(dir, requiredFile))) return dir;
  }
  return null;
}

if (!fs.existsSync(SOURCE_LAUNCHER)) fail(`Launcher-fonte nao encontrado: ${SOURCE_LAUNCHER}`);

const CENTRAL_DIR = findDir(CENTRAL_CANDIDATES, "config_central_504.json");
if (!CENTRAL_DIR) {
  console.error("[INSTALADOR] Procurei a Central nestes caminhos:");
  CENTRAL_CANDIDATES.forEach(x => console.error(" -", x));
  fail("Nao encontrei config_central_504.json.");
}
const CONFIG = path.join(CENTRAL_DIR, "config_central_504.json");

const MAINT_DIR = findDir(MAINT_CANDIDATES, "Atualizar_SAP_504_V5_14.ps1");
if (!MAINT_DIR) {
  console.error("[INSTALADOR] Procurei a Manutencao nestes caminhos:");
  MAINT_CANDIDATES.forEach(x => console.error(" -", x));
  fail("Nao encontrei Atualizar_SAP_504_V5_14.ps1.");
}

const TARGET_LAUNCHER = path.join(MAINT_DIR, LAUNCHER_NAME);
ok(`Central encontrada: ${CENTRAL_DIR}`);
ok(`Manutencao encontrada: ${MAINT_DIR}`);

let cfg;
try { cfg = JSON.parse(fs.readFileSync(CONFIG, "utf8").replace(/^\uFEFF/, "")); }
catch (e) { fail(`Config da Central invalido: ${e.message}`); }
if (!cfg.automations || typeof cfg.automations !== "object") fail("Config nao possui automations.");

const old = cfg.automations.manutencao || {};
const stamp = new Date().toISOString().replace(/[-:.TZ]/g, "").slice(0,14);
const backup = path.join(CENTRAL_DIR, `config_central_504.backup_manut_v5_${stamp}.json`);
fs.copyFileSync(CONFIG, backup);
ok(`Backup da Central criado: ${backup}`);

if (fs.existsSync(TARGET_LAUNCHER)) {
  fs.copyFileSync(TARGET_LAUNCHER, TARGET_LAUNCHER + `.backup_${stamp}.js`);
}
fs.copyFileSync(SOURCE_LAUNCHER, TARGET_LAUNCHER);
ok(`Launcher V5 instalado: ${TARGET_LAUNCHER}`);

const watchFile = old.watchFile || path.join(path.dirname(MAINT_DIR), "Relatórios SAP", "ordens_status.htm");
cfg.automations.manutencao = {
  ...old,
  name: old.name || "Manutenção",
  kind: "node",
  cwd: MAINT_DIR,
  command: "node",
  args: [LAUNCHER_NAME],
  watchFile
};
delete cfg.automations.manutencao.script;
fs.writeFileSync(CONFIG, JSON.stringify(cfg, null, 2), "utf8");

const check = JSON.parse(fs.readFileSync(CONFIG, "utf8"));
const m = check.automations && check.automations.manutencao;
if (!m || m.kind !== "node" || m.command !== "node" || !Array.isArray(m.args) || m.args[0] !== LAUNCHER_NAME) {
  fail("Validacao do config falhou.");
}
ok("Central configurada para chamar o launcher Node da Manutencao.");

// Encerra somente o agente da Central na porta 5040 para forcar releitura do config.
try {
  const out = cp.execFileSync("netstat", ["-ano"], { encoding: "utf8", windowsHide: true });
  const pids = new Set();
  for (const line of out.split(/\r?\n/)) {
    if (!/:5040\s/.test(line) || !/LISTENING/i.test(line)) continue;
    const parts = line.trim().split(/\s+/);
    const pid = parts[parts.length - 1];
    if (/^\d+$/.test(pid)) pids.add(pid);
  }
  for (const pid of pids) {
    try {
      cp.execFileSync("taskkill", ["/PID", pid, "/F"], { stdio:"ignore", windowsHide:true });
      ok(`Agente antigo encerrado (PID ${pid}).`);
    } catch (e) { console.warn(`[AVISO] Nao consegui encerrar PID ${pid}: ${e.message}`); }
  }
  if (!pids.size) console.log("[INFO] Nenhum agente ativo na porta 5040.");
} catch (e) { console.warn(`[AVISO] Nao consegui consultar porta 5040: ${e.message}`); }

console.log("");
console.log("CORRECAO V5 INSTALADA.");
console.log("Esta versao elimina os dois problemas:");
console.log(" - aviso [N]/[R] por executar PS1 da rede;");
console.log(" - ENAMETOOLONG por EncodedCommand grande demais.");
console.log("");
console.log("Agora abra o INICIAR_PORTAL_504.bat e teste Manutencao.");
