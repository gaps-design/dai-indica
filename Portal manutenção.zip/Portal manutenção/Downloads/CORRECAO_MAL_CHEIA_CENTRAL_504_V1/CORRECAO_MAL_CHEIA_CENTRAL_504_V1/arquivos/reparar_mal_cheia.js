"use strict";

const fs = require("fs");
const path = require("path");
const cp = require("child_process");

const ROOT = String.raw`N:\Packaging\Compartilhado\Retornável\Usuarios\Guilherme A`;

const CENTRAL_CANDIDATES = [
  path.join(ROOT, "Portal Indicadores", "_sistema", "Central Atualizacoes"),
  path.join(ROOT, "Lobby", "Portal Indicadores", "_sistema", "Central Atualizacoes")
];

const PORTAL_CANDIDATES = [
  path.join(ROOT, "Lobby", "Portal Qualidade", "Portal mal cheia"),
  path.join(ROOT, "Lobby", "Portal Qualidade", "Portal Mal Cheia"),
  path.join(ROOT, "Portal Qualidade", "Portal mal cheia"),
  path.join(ROOT, "Portal Qualidade", "Portal Mal Cheia")
];

function norm(s) {
  return String(s || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
}
function exists(p) { try { return fs.existsSync(p); } catch (_) { return false; } }
function ok(msg) { console.log("[OK]", msg); }
function info(msg) { console.log("[INFO]", msg); }
function warn(msg) { console.warn("[AVISO]", msg); }
function fail(msg) { console.error("[ERRO]", msg); process.exit(1); }

function findDir(candidates, required) {
  for (const d of candidates) {
    if (!exists(d)) continue;
    if (!required || exists(path.join(d, required))) return d;
  }
  return null;
}

function findNamedFile(root, fileName, maxDepth = 4, depth = 0) {
  if (!root || depth > maxDepth) return null;
  let entries;
  try { entries = fs.readdirSync(root, { withFileTypes: true }); } catch (_) { return null; }
  for (const e of entries) {
    if (e.isFile() && e.name.toLowerCase() === fileName.toLowerCase()) return path.join(root, e.name);
  }
  const skip = new Set(["node_modules", ".git", "backup_automacao", "logs", "downloads"]);
  for (const e of entries) {
    if (!e.isDirectory() || skip.has(e.name.toLowerCase())) continue;
    const found = findNamedFile(path.join(root, e.name), fileName, maxDepth, depth + 1);
    if (found) return found;
  }
  return null;
}

const centralDir = findDir(CENTRAL_CANDIDATES, "config_central_504.json");
if (!centralDir) {
  CENTRAL_CANDIDATES.forEach(x => console.error(" -", x));
  fail("Central 504 nao encontrada.");
}
const configPath = path.join(centralDir, "config_central_504.json");
ok(`Central encontrada: ${centralDir}`);

const portalDir = PORTAL_CANDIDATES.find(exists) || null;
if (!portalDir) {
  PORTAL_CANDIDATES.forEach(x => console.error(" -", x));
  fail("Portal Mal Cheia nao encontrado.");
}
ok(`Portal Mal Cheia encontrado: ${portalDir}`);

const scriptPath = findNamedFile(portalDir, "automacao_mal_cheia.js", 4, 0);
if (!scriptPath) {
  fail(`automacao_mal_cheia.js nao foi encontrada dentro de: ${portalDir}`);
}
const updateDir = path.dirname(scriptPath);
ok(`Automacao encontrada: ${scriptPath}`);

const ps1Path = path.join(updateDir, "extrair_mal_cheia_excel.ps1");
if (!exists(ps1Path)) fail(`Extrator nao encontrado ao lado da automacao: ${ps1Path}`);
ok(`Extrator encontrado: ${ps1Path}`);

const watchFile = path.join(portalDir, "js", "dados_diario.js");
if (!exists(watchFile)) fail(`Base do Portal Mal Cheia nao encontrada: ${watchFile}`);
ok(`Base do portal encontrada: ${watchFile}`);

const localExcel = path.join(updateDir, "Controle de mal cheias Guilherme.xlsx");
const officialExcel = String.raw`N:\Packaging\Compartilhado\Retornável\Linha 504\Trabalho de IV's\Controle de mal cheias Guilherme.xlsx`;
if (exists(localExcel)) ok(`Excel da automacao encontrado: ${localExcel}`);
else if (exists(officialExcel)) {
  warn("O Excel nao esta ao lado da automacao, mas a fonte oficial foi localizada.");
  warn(`Fonte oficial: ${officialExcel}`);
  warn("Nao vou copiar nem sobrescrever o Excel automaticamente nesta correcao.");
} else {
  fail("Controle de mal cheias Guilherme.xlsx nao foi localizado nem na automacao nem no caminho oficial conhecido.");
}

let cfg;
try {
  cfg = JSON.parse(fs.readFileSync(configPath, "utf8").replace(/^\uFEFF/, ""));
} catch (e) {
  fail(`config_central_504.json invalido: ${e.message}`);
}
if (!cfg.automations || typeof cfg.automations !== "object") fail("Config nao possui automations.");

const entries = Object.entries(cfg.automations);
let pair = entries.find(([key, value]) => {
  const t = `${norm(key)} ${norm(value && value.name)}`;
  return t.includes("mal") && t.includes("cheia");
});

if (!pair) {
  console.error("Automacoes atuais:");
  for (const [k, v] of entries) console.error(` - ${k}: ${(v && v.name) || "sem nome"}`);
  fail("A Central nao possui uma entrada identificavel de Mal Cheia. Nao vou inventar uma chave e arriscar quebrar a interface.");
}

const [key, old] = pair;
ok(`Entrada da Central identificada: ${key} (${old.name || "Mal Cheia"})`);

const stamp = new Date().toISOString().replace(/[-:.TZ]/g, "").slice(0, 14);
const backup = path.join(centralDir, `config_central_504.backup_malcheia_${stamp}.json`);
fs.copyFileSync(configPath, backup);
ok(`Backup criado: ${backup}`);

cfg.automations[key] = {
  ...old,
  name: old.name || "Mal Cheia",
  kind: "node",
  cwd: updateDir,
  command: "node",
  args: ["automacao_mal_cheia.js"],
  watchFile
};
delete cfg.automations[key].script;

fs.writeFileSync(configPath, JSON.stringify(cfg, null, 2), "utf8");

const check = JSON.parse(fs.readFileSync(configPath, "utf8"));
const mc = check.automations[key];
if (!mc || mc.kind !== "node" || mc.command !== "node" || !Array.isArray(mc.args) || mc.args[0] !== "automacao_mal_cheia.js") {
  fail("Validacao do config salvo falhou.");
}
if (!exists(mc.cwd) || !exists(path.join(mc.cwd, mc.args[0])) || !exists(mc.watchFile)) {
  fail("Config foi salvo, mas um dos caminhos ainda nao existe.");
}
ok("Mal Cheia ficou apontando para a automacao real e a base real do portal.");

// Reinicia apenas o agente local da Central (porta 5040).
try {
  const out = cp.execFileSync("netstat", ["-ano"], { encoding: "utf8", windowsHide: true });
  const pids = new Set();
  for (const line of out.split(/\r?\n/)) {
    if (!/:5040\s/.test(line) || !/LISTENING/i.test(line)) continue;
    const parts = line.trim().split(/\s+/);
    const pid = parts[parts.length - 1];
    if (/^\d+$/.test(pid)) pids.add(pid);
  }
  for (const pid of pids) {
    try {
      cp.execFileSync("taskkill", ["/PID", pid, "/F"], { stdio: "ignore", windowsHide: true });
      ok(`Agente antigo encerrado (PID ${pid}).`);
    } catch (e) {
      warn(`Nao consegui encerrar PID ${pid}: ${e.message}`);
    }
  }
  if (!pids.size) info("Nenhum agente ativo na porta 5040.");
} catch (e) {
  warn(`Nao consegui consultar a porta 5040: ${e.message}`);
}

console.log("");
console.log("============================================================");
console.log(" MAL CHEIA RESTAURADA NA CENTRAL");
console.log("============================================================");
console.log(`Chave: ${key}`);
console.log(`CWD: ${updateDir}`);
console.log(`Script: ${path.basename(scriptPath)}`);
console.log(`Watch: ${watchFile}`);
console.log("");
console.log("Agora abra novamente o INICIAR_PORTAL_504.bat, use Ctrl+F5 na Central e confirme 5/5.");
