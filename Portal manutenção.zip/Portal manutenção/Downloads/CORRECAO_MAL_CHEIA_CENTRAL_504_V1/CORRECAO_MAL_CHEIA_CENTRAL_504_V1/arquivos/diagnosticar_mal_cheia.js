"use strict";
const fs=require("fs"),path=require("path");
const ROOT=String.raw`N:\Packaging\Compartilhado\Retornável\Usuarios\Guilherme A`;
const central=[path.join(ROOT,"Portal Indicadores","_sistema","Central Atualizacoes"),path.join(ROOT,"Lobby","Portal Indicadores","_sistema","Central Atualizacoes")].find(d=>fs.existsSync(path.join(d,"config_central_504.json")));
if(!central){console.error("Central nao encontrada.");process.exit(1)}
const cfg=JSON.parse(fs.readFileSync(path.join(central,"config_central_504.json"),"utf8").replace(/^\uFEFF/,""));
console.log("Central:",central);
for(const [k,a] of Object.entries(cfg.automations||{})){
 const script=a.kind==="node"&&a.args&&a.args[0]?path.join(a.cwd,a.args[0]):a.cwd;
 console.log(`\n[${k}] ${a.name||""}`);
 console.log(" kind:",a.kind);
 console.log(" cwd:",a.cwd,"=>",fs.existsSync(a.cwd)?"OK":"NAO EXISTE");
 if(a.kind==="node") console.log(" script:",script,"=>",fs.existsSync(script)?"OK":"NAO EXISTE");
 console.log(" watch:",a.watchFile,"=>",a.watchFile&&fs.existsSync(a.watchFile)?"OK":"NAO EXISTE");
}
