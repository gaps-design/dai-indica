@echo off
setlocal EnableExtensions
cls
title Diagnostico Mal Cheia Central 504
where node >nul 2>nul
if errorlevel 1 (
  echo [ERRO] Node.js nao foi encontrado.
  pause
  exit /b 1
)
node "%~dp0arquivos\diagnosticar_mal_cheia.js"
echo.
pause
