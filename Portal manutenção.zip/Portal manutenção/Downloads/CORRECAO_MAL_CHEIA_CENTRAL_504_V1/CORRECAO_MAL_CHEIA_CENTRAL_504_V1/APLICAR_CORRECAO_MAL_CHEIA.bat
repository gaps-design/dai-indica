@echo off
setlocal EnableExtensions
cls
title Restaurar Mal Cheia na Central 504
echo ============================================================
echo  RESTAURAR MAL CHEIA NA CENTRAL 504
echo ============================================================
echo.
where node >nul 2>nul
if errorlevel 1 (
  echo [ERRO] Node.js nao foi encontrado neste VD.
  pause
  exit /b 1
)
echo Corrigindo somente a entrada da Mal Cheia...
node "%~dp0arquivos\reparar_mal_cheia.js"
set "RC=%ERRORLEVEL%"
echo.
if not "%RC%"=="0" (
  echo [ERRO] A correcao nao foi concluida. Codigo: %RC%
  echo Execute DIAGNOSTICAR_MAL_CHEIA.bat e fotografe a tela se precisar.
  pause
  exit /b %RC%
)
echo [OK] Correcao concluida.
echo 1. Feche esta janela.
echo 2. Abra novamente INICIAR_PORTAL_504.bat.
echo 3. Use Ctrl+F5 na Central.
echo 4. O painel deve voltar para 5/5.
echo.
pause
exit /b 0
