"use strict";

const fs = require("fs");
const path = require("path");
const os = require("os");
const cp = require("child_process");

const SCRIPT_NAME = "Atualizar_SAP_504_V5_14.ps1";
const UPDATER_NAME = "atualizar_index_local.js";

const sourcePs1 = path.join(__dirname, SCRIPT_NAME);
const sourceUpdater = path.join(__dirname, UPDATER_NAME);

function fail(msg) {
  console.error("[MANUTENCAO] ERRO:", msg);
  process.exit(1);
}

if (!fs.existsSync(sourcePs1)) {
  fail(`Script nao encontrado: ${sourcePs1}`);
}
if (!fs.existsSync(sourceUpdater)) {
  fail(`Atualizador do Index nao encontrado: ${sourceUpdater}`);
}

let psCode;
let updaterCode;
try {
  psCode = fs.readFileSync(sourcePs1, "utf8").replace(/^\uFEFF/, "");
  updaterCode = fs.readFileSync(sourceUpdater, "utf8").replace(/^\uFEFF/, "");
} catch (e) {
  fail(`Nao consegui ler os arquivos da Manutencao: ${e.message}`);
}

// O PS1 original fica na unidade N:. Para evitar o aviso [N]/[R],
// executamos uma copia temporaria LOCAL.
//
// IMPORTANTE V5.21:
// o PowerShell usa $PSScriptRoot para localizar atualizar_index_local.js.
// Portanto, o JS auxiliar também precisa ser copiado para a MESMA pasta
// temporaria do PS1. Antes apenas o PS1 era copiado e a etapa 12.1 falhava.
let tempDir;
let localPs1;
let localUpdater;

try {
  tempDir = fs.mkdtempSync(path.join(os.tmpdir(), "portal504_manutencao_"));
  localPs1 = path.join(tempDir, "Atualizar_SAP_504_V5_14_LOCAL.ps1");
  localUpdater = path.join(tempDir, UPDATER_NAME);

  // BOM UTF-8 para Windows PowerShell 5.1 preservar acentos.
  fs.writeFileSync(localPs1, "\uFEFF" + psCode, "utf8");
  fs.writeFileSync(localUpdater, updaterCode, "utf8");
} catch (e) {
  fail(`Nao consegui criar a copia local temporaria: ${e.message}`);
}

function cleanup() {
  try {
    if (tempDir && fs.existsSync(tempDir)) {
      fs.rmSync(tempDir, { recursive: true, force: true });
    }
  } catch (_) {}
}

console.log("============================================================");
console.log(" MANUTENCAO 504 - EXECUCAO SEM R - V5.21");
console.log(" Modo: copia local temporaria do PowerShell + atualizador Index");
console.log(" Nao executa PS1 diretamente da unidade N:");
console.log(" Nao usa EncodedCommand (evita ENAMETOOLONG)");
console.log("============================================================");
console.log("Fonte PS1:", sourcePs1);
console.log("Fonte atualizador:", sourceUpdater);
console.log("Copia local PS1:", localPs1);
console.log("Copia local atualizador:", localUpdater);

const args = [
  "-NoLogo",
  "-NoProfile",
  "-NonInteractive",
  "-ExecutionPolicy", "Bypass",
  "-File", localPs1
];

const child = cp.spawn("powershell.exe", args, {
  cwd: __dirname,
  stdio: "inherit",
  windowsHide: false,
  shell: false,
  env: {
    ...process.env,
    PORTAL504_CENTRAL: "1",
    PORTAL504_MAINT_SEM_R: "1",
    PORTAL504_PS1_LOCAL_TEMP: "1"
  }
});

child.on("error", err => {
  cleanup();
  fail(`Nao consegui iniciar o PowerShell: ${err.message}`);
});

child.on("close", code => {
  cleanup();
  process.exit(Number.isInteger(code) ? code : 1);
});

process.on("SIGINT", () => {
  cleanup();
  process.exit(130);
});
process.on("SIGTERM", () => {
  cleanup();
  process.exit(143);
});
