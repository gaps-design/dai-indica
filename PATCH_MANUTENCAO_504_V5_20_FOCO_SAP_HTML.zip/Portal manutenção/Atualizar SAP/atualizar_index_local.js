"use strict";

const fs = require("fs");
const path = require("path");

function fail(msg) {
  console.error("[INDEX-SAP] ERRO:", msg);
  process.exit(1);
}
function norm(value) {
  return String(value ?? "")
    .replace(/\u00a0/g, " ")
    .trim()
    .toUpperCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/\s+/g, " ");
}
function decodeEntities(value) {
  return String(value ?? "")
    .replace(/&nbsp;/gi, " ")
    .replace(/&#x([0-9a-f]+);/gi, (_, h) => String.fromCodePoint(parseInt(h, 16)))
    .replace(/&#(\d+);/g, (_, d) => String.fromCodePoint(parseInt(d, 10)))
    .replace(/&amp;/gi, "&")
    .replace(/&lt;/gi, "<")
    .replace(/&gt;/gi, ">")
    .replace(/&quot;/gi, '"')
    .replace(/&#39;/gi, "'");
}
function cellText(html) {
  return decodeEntities(
    String(html)
      .replace(/<script\b[\s\S]*?<\/script>/gi, "")
      .replace(/<style\b[\s\S]*?<\/style>/gi, "")
      .replace(/<br\s*\/?\s*>/gi, " ")
      .replace(/<[^>]+>/g, " ")
  ).replace(/\s+/g, " ").trim();
}
function normalizeSapDate(s) {
  s = String(s || "").trim();
  const m = s.match(/^(\d{1,2})[.\/-](\d{1,2})[.\/-](\d{4})$/);
  if (!m) return s;
  return `${String(m[1]).padStart(2, "0")}/${String(m[2]).padStart(2, "0")}/${m[3]}`;
}
function parseSapHtml(html) {
  const rows = [];
  const trRe = /<tr\b[^>]*>([\s\S]*?)<\/tr>/gi;
  let tr;
  while ((tr = trRe.exec(html))) {
    const cells = [];
    const tdRe = /<(?:td|th)\b[^>]*>([\s\S]*?)<\/(?:td|th)>/gi;
    let td;
    while ((td = tdRe.exec(tr[1]))) cells.push(cellText(td[1]));
    if (cells.length) rows.push(cells);
  }
  if (!rows.length) throw new Error("Nenhuma tabela encontrada no relatório SAP.");

  const aliases = {
    order: ["ORDEM", "N°ORDEM", "Nº ORDEM"],
    orderType: ["TP.", "TIPO DE ORDEM", "TIPO ORDEM"],
    date: ["INÍCIOBASE", "INICIOBASE", "DATA-BASE INÍC.", "DATA-BASE INIC"],
    desc: ["TEXTO BREVE", "TXTDESC.OPER.", "DESCRIÇÃO OPERACIONAL"],
    loc: ["LOCAL DE INSTALAÇÃO", "LOC.INSTALAÇÃO", "LOC.INSTALACAO"],
    workCenter: ["CENTRABPR.", "CENTRO DE TRABALHO", "CENTROTRAB", "CEN TRAB PR"],
    type: ["TAM", "TIP.ATIV.MANUT.", "TP.ATVD"],
    userStatus: ["STATUSUSUÁR.", "STATUS USUÁRIO", "STATUS USUARIO", "STATUSUÁR.", "STATUSUAR.", "STATUSUSUAR.", "STATUsuár."],
    sap: ["STATUS DO SISTEMA", "STATUS SISTEMA"]
  };
  const exactIndex = (headers, names) => {
    const hh = headers.map(norm);
    for (const n of names) {
      const i = hh.indexOf(norm(n));
      if (i >= 0) return i;
    }
    return -1;
  };
  const looseIndex = (headers, names) => {
    const exact = exactIndex(headers, names);
    if (exact >= 0) return exact;
    const hh = headers.map(norm);
    for (const n of names) {
      const a = norm(n);
      const i = hh.findIndex(h => h.includes(a));
      if (i >= 0) return i;
    }
    return -1;
  };

  let best = null;
  let bestScore = -1;
  rows.slice(0, 60).forEach((row, ri) => {
    let score = 0;
    for (const k of ["order", "date", "desc", "loc", "type"]) {
      if (looseIndex(row, aliases[k]) >= 0) score++;
    }
    if (exactIndex(row, aliases.sap) >= 0) score += 2;
    if (score > bestScore) {
      bestScore = score;
      best = { ri, headers: row };
    }
  });
  if (!best) throw new Error("Cabeçalho SAP não encontrado.");

  const h = best.headers;
  const idx = {
    order: looseIndex(h, aliases.order),
    orderType: looseIndex(h, aliases.orderType),
    date: looseIndex(h, aliases.date),
    desc: looseIndex(h, aliases.desc),
    loc: looseIndex(h, aliases.loc),
    workCenter: looseIndex(h, aliases.workCenter),
    type: looseIndex(h, aliases.type),
    userStatus: looseIndex(h, aliases.userStatus),
    sap: exactIndex(h, aliases.sap)
  };
  if (idx.order < 0) throw new Error("Coluna Ordem não encontrada.");
  if (idx.sap < 0) {
    throw new Error("Coluna exata 'Status do sistema' não encontrada. Atualização bloqueada para não confundir com StatUsuár.");
  }

  const out = [];
  for (const row of rows.slice(best.ri + 1)) {
    const col = k => idx[k] >= 0 && idx[k] < row.length ? String(row[idx[k]] || "").trim() : "";
    const order = col("order").replace(/\D/g, "");
    if (!/^\d{6,}$/.test(order)) continue;
    out.push({
      order,
      orderType: col("orderType"),
      date: normalizeSapDate(col("date")),
      desc: col("desc"),
      loc: col("loc"),
      workCenter: col("workCenter"),
      type: col("type"),
      userStatus: col("userStatus"),
      sap: col("sap")
    });
  }
  const seen = new Set();
  for (const row of out) {
    if (seen.has(row.order)) throw new Error(`Ordem duplicada no relatório: ${row.order}`);
    seen.add(row.order);
  }
  if (!out.length) throw new Error("Nenhuma ordem válida encontrada no relatório.");
  return out;
}

function extractArray(text, marker) {
  const markerPos = text.indexOf(marker);
  if (markerPos < 0) throw new Error(`Marcador não encontrado no Index: ${marker}`);
  const start = text.indexOf("[", markerPos);
  if (start < 0) throw new Error("Início da base DEMO não encontrado.");
  let depth = 0, inString = false, escaped = false;
  for (let i = start; i < text.length; i++) {
    const ch = text[i];
    if (inString) {
      if (escaped) escaped = false;
      else if (ch === "\\") escaped = true;
      else if (ch === '"') inString = false;
    } else {
      if (ch === '"') inString = true;
      else if (ch === "[") depth++;
      else if (ch === "]") {
        depth--;
        if (depth === 0) return { start, end: i + 1, json: text.slice(start, i + 1) };
      }
    }
  }
  throw new Error("Fim da base DEMO não encontrado.");
}
function isConfirmed(value) {
  return /(^|\s)CONF(\s|$)/i.test(String(value || "").trim());
}
function versionStamp() {
  const d = new Date();
  const p = n => String(n).padStart(2, "0");
  return `AUTO_SAP_${d.getFullYear()}${p(d.getMonth()+1)}${p(d.getDate())}${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}`;
}
function safeFileStamp() {
  const d = new Date();
  const p = n => String(n).padStart(2, "0");
  return `${d.getFullYear()}${p(d.getMonth()+1)}${p(d.getDate())}_${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}`;
}

function main() {
  const args = process.argv.slice(2);
  const get = name => {
    const i = args.indexOf(name);
    return i >= 0 ? args[i + 1] : null;
  };
  const indexPath = path.resolve(get("--index") || path.join(__dirname, "..", "index_programacao_operacional.html"));
  const reportPath = path.resolve(get("--report") || path.join(__dirname, "..", "Relatórios SAP", "ordens_status.htm"));

  if (!fs.existsSync(indexPath)) fail(`Index não encontrado: ${indexPath}`);
  if (!fs.existsSync(reportPath)) fail(`Relatório SAP não encontrado: ${reportPath}`);

  let text = fs.readFileSync(indexPath, "utf8").replace(/^\uFEFF/, "");
  const rows = parseSapHtml(fs.readFileSync(reportPath, "utf8"));
  const block = extractArray(text, "const DEMO =");
  const orders = JSON.parse(block.json);
  if (!Array.isArray(orders)) throw new Error("Base DEMO inválida no Index.");

  const map = new Map();
  for (const order of orders) {
    const id = String(order?.order || "").trim();
    if (!id) continue;
    if (map.has(id)) throw new Error(`Index contém ordem duplicada: ${id}`);
    map.set(id, order);
  }

  const beforeTotal = orders.length;
  const beforeConf = orders.filter(o => isConfirmed(o.sap)).length;
  let updated = 0;
  let unchanged = 0;
  const missingInIndex = [];
  const stamp = new Date().toISOString();

  for (const row of rows) {
    const current = map.get(row.order);
    if (!current) {
      // O relatório automático foi gerado a partir das ordens do próprio Index.
      // Portanto uma ordem ausente é anomalia; não inventamos equipamento/célula/programação.
      missingInIndex.push(row.order);
      continue;
    }

    const before = JSON.stringify({
      orderType: current.orderType ?? "",
      desc: current.desc ?? "",
      loc: current.loc ?? "",
      workCenter: current.workCenter ?? "",
      type: current.type ?? "",
      userStatus: current.userStatus ?? "",
      sap: current.sap ?? "",
      sapDate: current.sapDate ?? ""
    });

    // Mesmas regras do módulo SapStatusMerge do portal:
    // apenas campos mestres/status SAP podem mudar.
    current.orderType = row.orderType ?? "";
    current.desc = row.desc ?? "";
    current.loc = row.loc ?? "";
    current.workCenter = row.workCenter ?? "";
    current.type = row.type ?? "";
    current.userStatus = row.userStatus ?? "";
    current.sap = row.sap ?? "";
    if (row.date) current.sapDate = row.date; // NÃO altera current.date (programação)
    current.importedAt = stamp;
    if (!isConfirmed(JSON.parse(before).sap) && isConfirmed(current.sap)) current.completedAt = stamp;

    const after = JSON.stringify({
      orderType: current.orderType ?? "",
      desc: current.desc ?? "",
      loc: current.loc ?? "",
      workCenter: current.workCenter ?? "",
      type: current.type ?? "",
      userStatus: current.userStatus ?? "",
      sap: current.sap ?? "",
      sapDate: current.sapDate ?? ""
    });
    if (before === after) unchanged++;
    else updated++;
  }

  if (missingInIndex.length) {
    throw new Error(`Relatório contém ${missingInIndex.length} ordem(ns) que não existem no Index: ${missingInIndex.slice(0, 10).join(", ")}. Index não foi alterado.`);
  }

  const afterTotal = orders.length;
  if (afterTotal !== beforeTotal) throw new Error(`Proteção: total de ordens mudaria de ${beforeTotal} para ${afterTotal}.`);
  const uniqueAfter = new Set(orders.map(o => String(o?.order || "").trim()).filter(Boolean)).size;
  if (uniqueAfter !== afterTotal) throw new Error("Proteção: atualização criaria/confirmaria duplicidade no Index.");

  const afterConf = orders.filter(o => isConfirmed(o.sap)).length;
  if (beforeConf >= 5 && afterConf < Math.floor(beforeConf * 0.20)) {
    throw new Error(`Proteção de CONF: queda anormal de ${beforeConf} para ${afterConf}. Index não foi salvo.`);
  }

  const version = versionStamp();
  let nextText = text.slice(0, block.start) + JSON.stringify(orders) + text.slice(block.end);
  if (/const EMBEDDED_BASE_VERSION = "[^"]*";/.test(nextText)) {
    nextText = nextText.replace(/const EMBEDDED_BASE_VERSION = "[^"]*";/, `const EMBEDDED_BASE_VERSION = "${version}";`);
  } else {
    throw new Error("Constante EMBEDDED_BASE_VERSION não encontrada. Index não foi salvo.");
  }

  // Validação pós-substituição antes de tocar no arquivo de produção.
  const verifyBlock = extractArray(nextText, "const DEMO =");
  const verifyOrders = JSON.parse(verifyBlock.json);
  if (!Array.isArray(verifyOrders) || verifyOrders.length !== beforeTotal) {
    throw new Error("Validação do novo Index falhou. Arquivo de produção foi preservado.");
  }

  const backupDir = path.join(path.dirname(indexPath), "backup_index_automatico");
  fs.mkdirSync(backupDir, { recursive: true });
  const backup = path.join(backupDir, `index_programacao_operacional_${safeFileStamp()}.html`);
  fs.copyFileSync(indexPath, backup);

  // Escrita atômica: grava temporário no MESMO diretório e só então substitui o Index.
  const tempPath = indexPath + `.tmp_${process.pid}_${Date.now()}`;
  fs.writeFileSync(tempPath, "\uFEFF" + nextText, "utf8");
  const saved = fs.readFileSync(tempPath, "utf8").replace(/^\uFEFF/, "");
  const savedBlock = extractArray(saved, "const DEMO =");
  const savedOrders = JSON.parse(savedBlock.json);
  if (!Array.isArray(savedOrders) || savedOrders.length !== beforeTotal) {
    try { fs.unlinkSync(tempPath); } catch (_) {}
    throw new Error("Arquivo temporário do novo Index falhou na validação. Produção preservada.");
  }
  fs.renameSync(tempPath, indexPath);

  console.log(`[INDEX-SAP] Relatório lido: ${rows.length} ordens`);
  console.log(`[INDEX-SAP] Index preservado: ${beforeTotal} ordens`);
  console.log(`[INDEX-SAP] Campos SAP alterados: ${updated} | sem mudança: ${unchanged}`);
  console.log(`[INDEX-SAP] CONF no Index: ${beforeConf} -> ${afterConf}`);
  console.log(`[INDEX-SAP] Programação/Responsáveis/Células: preservados`);
  console.log(`[INDEX-SAP] Versão: ${version}`);
  console.log(`[INDEX-SAP] Backup: ${backup}`);
  console.log(`[INDEX-SAP] Index salvo corretamente: ${indexPath}`);
}

try {
  main();
} catch (e) {
  fail(e && e.stack ? e.stack : e);
}
