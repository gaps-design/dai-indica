﻿# =====================================================================
# Atualizar SAP 504 V5.19 - FLUXO V5.14 RESTAURADO + SALVA INDEX
# Automação sem Remote Debugging / sem porta 9222
# Usa Windows UI Automation + Chrome normal
# =====================================================================

$ErrorActionPreference = "Stop"

# =========================
# CONFIGURAÇÃO
# =========================
$Base = "N:\Packaging\Compartilhado\Retornável\Usuarios\Guilherme A\Lobby\Portal manutenção"
$PortalIndex = Join-Path $Base "index_programacao_operacional.html"
$Downloads = Join-Path $Base "Downloads"
$Relatorios = Join-Path $Base "Relatórios SAP"
$GitHub = Join-Path $Base "GitHub"

$DestinoRelatorio = Join-Path $Relatorios "ordens_status.htm"
$DestinoGit = Join-Path $GitHub "ordens_status.htm"

$SapHomeUrl = "https://s4.stout.aurora.ab-inbev.com/sap/bc/ui2/flp#Shell-home"
$LayoutSAP = "/elieserpo"

$TimeoutTela = 60
$TimeoutDownloadMin = 20
$TamanhoMinimoBytes = 5KB

# =========================
# FUNÇÕES VISUAIS
# =========================
function Titulo([string]$Texto) {
    Write-Host ""
    Write-Host "====================================================================" -ForegroundColor Cyan
    Write-Host " $Texto" -ForegroundColor Cyan
    Write-Host "====================================================================" -ForegroundColor Cyan
}
function Etapa([string]$Texto) {
    Write-Host ""
    Write-Host $Texto -ForegroundColor Yellow
}
function Ok([string]$Texto) {
    Write-Host "OK: $Texto" -ForegroundColor Green
}
function Falha([string]$Texto) {
    Write-Host ""
    Write-Host "ERRO: $Texto" -ForegroundColor Red
    throw $Texto
}

# =========================
# VALIDAÇÕES
# =========================
foreach ($p in @($Base,$Downloads,$Relatorios,$GitHub)) {
    if (-not (Test-Path -LiteralPath $p)) { Falha "Pasta não encontrada: $p" }
}
if (-not (Test-Path -LiteralPath $PortalIndex)) {
    Falha "Index do VD não encontrado: $PortalIndex"
}

function Find-Chrome {
    $candidates = @(
        "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
        "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
        "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe"
    )
    foreach ($c in $candidates) {
        if ($c -and (Test-Path -LiteralPath $c)) { return $c }
    }
    return $null
}
$Chrome = Find-Chrome
if (-not $Chrome) { Falha "Google Chrome não encontrado." }

# =========================
# WINDOWS UI AUTOMATION
# =========================
Add-Type -AssemblyName UIAutomationClient
Add-Type -AssemblyName UIAutomationTypes

# V5.9: UI Automation fica limitada SOMENTE à janela ativa do Chrome.
# Isso evita varrer o desktop inteiro, acessar processos protegidos e clicar em outras abas/janelas.
Add-Type @"
using System;
using System.Runtime.InteropServices;
public static class NativeWindowSAP504 {
    [DllImport("user32.dll")]
    public static extern IntPtr GetForegroundWindow();
}
"@

$script:ScopeRoot = $null

function Set-UiaScopeToForeground {
    $h = [NativeWindowSAP504]::GetForegroundWindow()
    if ($h -eq [IntPtr]::Zero) { return $false }
    try {
        $script:ScopeRoot = [System.Windows.Automation.AutomationElement]::FromHandle($h)
        return ($null -ne $script:ScopeRoot)
    } catch {
        return $false
    }
}

function Get-Descendants {
    param([System.Windows.Automation.AutomationElement]$RootElement)
    if (-not $RootElement) { return @() }
    try {
        $cond = [System.Windows.Automation.Condition]::TrueCondition
        return $RootElement.FindAll([System.Windows.Automation.TreeScope]::Descendants, $cond)
    } catch [System.Windows.Automation.ElementNotAvailableException] {
        return @()
    } catch [System.UnauthorizedAccessException] {
        return @()
    } catch {
        return @()
    }
}

function Find-Uia {
    param(
        [string]$NameRegex,
        [string[]]$ControlTypes = @(),
        [int]$TimeoutSeconds = 30
    )

    $limit = (Get-Date).AddSeconds($TimeoutSeconds)
    while ((Get-Date) -lt $limit) {
        if (-not $script:ScopeRoot) {
            Set-UiaScopeToForeground | Out-Null
        }

        $all = Get-Descendants $script:ScopeRoot
        foreach ($e in $all) {
            try {
                $name = $e.Current.Name
                if (-not $name) { continue }
                if ($name -notmatch $NameRegex) { continue }

                if ($ControlTypes.Count -gt 0) {
                    $ct = $e.Current.ControlType.ProgrammaticName
                    $short = $ct -replace '^ControlType\.',''
                    if ($ControlTypes -notcontains $short) { continue }
                }
                return $e
            } catch {}
        }
        Start-Sleep -Milliseconds 500
    }
    return $null
}

function Invoke-Uia {
    param([System.Windows.Automation.AutomationElement]$Element)
    if (-not $Element) { return $false }

    foreach ($patternId in @(
        [System.Windows.Automation.InvokePattern]::Pattern,
        [System.Windows.Automation.SelectionItemPattern]::Pattern,
        [System.Windows.Automation.TogglePattern]::Pattern
    )) {
        try {
            $pattern = $Element.GetCurrentPattern($patternId)
            if ($pattern -is [System.Windows.Automation.InvokePattern]) {
                $pattern.Invoke()
                return $true
            }
            if ($pattern -is [System.Windows.Automation.SelectionItemPattern]) {
                $pattern.Select()
                return $true
            }
            if ($pattern -is [System.Windows.Automation.TogglePattern]) {
                if ($pattern.Current.ToggleState -ne [System.Windows.Automation.ToggleState]::On) {
                    $pattern.Toggle()
                }
                return $true
            }
        } catch {}
    }

    try {
        $Element.SetFocus()
        Add-Type -AssemblyName System.Windows.Forms
        [System.Windows.Forms.SendKeys]::SendWait("{ENTER}")
        return $true
    } catch {
        return $false
    }
}


# Clique físico real no centro do elemento.
# Necessário para ações protegidas pelo Chrome, como navigator.clipboard.writeText(),
# porque InvokePattern do UI Automation não conta como "user gesture" para o navegador.
Add-Type @"
using System;
using System.Runtime.InteropServices;
public static class NativeMouseSAP504 {
    [DllImport("user32.dll")]
    public static extern bool SetCursorPos(int X, int Y);

    [DllImport("user32.dll")]
    public static extern void mouse_event(uint dwFlags, uint dx, uint dy, uint dwData, UIntPtr dwExtraInfo);

    public const uint MOUSEEVENTF_LEFTDOWN = 0x0002;
    public const uint MOUSEEVENTF_LEFTUP   = 0x0004;
}
"@

function Click-UiaReal {
    param([System.Windows.Automation.AutomationElement]$Element)

    if (-not $Element) { return $false }

    try {
        $r = $Element.Current.BoundingRectangle
        if ($r.Width -le 1 -or $r.Height -le 1) { return $false }

        $x = [int]($r.Left + ($r.Width / 2))
        $y = [int]($r.Top  + ($r.Height / 2))

        $Element.SetFocus()
        Start-Sleep -Milliseconds 200

        [NativeMouseSAP504]::SetCursorPos($x,$y) | Out-Null
        Start-Sleep -Milliseconds 150
        [NativeMouseSAP504]::mouse_event([NativeMouseSAP504]::MOUSEEVENTF_LEFTDOWN,0,0,0,[UIntPtr]::Zero)
        Start-Sleep -Milliseconds 80
        [NativeMouseSAP504]::mouse_event([NativeMouseSAP504]::MOUSEEVENTF_LEFTUP,0,0,0,[UIntPtr]::Zero)
        return $true
    } catch {
        return $false
    }
}


function Hover-UiaReal {
    param([System.Windows.Automation.AutomationElement]$Element)
    if (-not $Element) { return $false }
    try {
        $r = $Element.Current.BoundingRectangle
        if ($r.Width -le 1 -or $r.Height -le 1) { return $false }
        $x = [int]($r.Left + ($r.Width / 2))
        $y = [int]($r.Top  + ($r.Height / 2))
        [NativeMouseSAP504]::SetCursorPos($x,$y) | Out-Null
        Start-Sleep -Milliseconds 650
        return $true
    } catch {
        return $false
    }
}

function Set-UiaValue {
    param(
        [System.Windows.Automation.AutomationElement]$Element,
        [string]$Value
    )
    if (-not $Element) { return $false }

    try {
        $vp = $Element.GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern)
        if (-not $vp.Current.IsReadOnly) {
            $vp.SetValue($Value)
            return $true
        }
    } catch {}

    try {
        $Element.SetFocus()
        Add-Type -AssemblyName System.Windows.Forms
        [System.Windows.Forms.SendKeys]::SendWait("^a")
        Set-Clipboard -Value $Value
        [System.Windows.Forms.SendKeys]::SendWait("^v")
        return $true
    } catch {
        return $false
    }
}

function Select-ComboByText {
    param(
        [System.Windows.Automation.AutomationElement]$Combo,
        [string]$TextRegex
    )
    if (-not $Combo) { return $false }

    try {
        $ep = $Combo.GetCurrentPattern([System.Windows.Automation.ExpandCollapsePattern]::Pattern)
        $ep.Expand()
    } catch {
        try { Invoke-Uia $Combo | Out-Null } catch {}
    }

    Start-Sleep -Milliseconds 500

    $item = Find-Uia -NameRegex $TextRegex -ControlTypes @("ListItem","DataItem","Text") -TimeoutSeconds 5
    if ($item) {
        return (Invoke-Uia $item)
    }

    # Fallback: digitação no combo.
    try {
        $Combo.SetFocus()
        Add-Type -AssemblyName System.Windows.Forms
        [System.Windows.Forms.SendKeys]::SendWait("^a")
        [System.Windows.Forms.SendKeys]::SendWait($TextRegex)
        [System.Windows.Forms.SendKeys]::SendWait("{ENTER}")
        return $true
    } catch {
        return $false
    }
}

# =========================
# 1. ABRIR PORTAL DO VD
# =========================
Titulo "ATUALIZAR SAP 504 V5.3 - UI AUTOMATION"

Etapa "[1/12] Abrindo Index do Portal Manutenção do VD..."
Write-Host "Index: $PortalIndex" -ForegroundColor DarkGray

# Chrome normal, sem CDP. Força acessibilidade para expor os controles à UI Automation.
$portalArgs = @(
    "--force-renderer-accessibility",
    "`"$PortalIndex`""
)
Start-Process -FilePath $Chrome -ArgumentList $portalArgs
Start-Sleep -Seconds 4
if (-not (Set-UiaScopeToForeground)) {
    Falha "Não consegui limitar a automação à janela do Portal no Chrome."
}
Ok "Portal solicitado ao Chrome e janela protegida para automação."

# =========================
# 2. PROGRAMACAO GERAL
# =========================
Etapa "[2/12] Abrindo Programação Geral..."
$prog = Find-Uia -NameRegex "^Programação Geral$|^Programacao Geral$" -TimeoutSeconds $TimeoutTela
if (-not $prog) { Falha "Não encontrei o botão/aba Programação Geral no Portal." }
if (-not (Invoke-Uia $prog)) { Falha "Não consegui abrir Programação Geral." }
Start-Sleep -Seconds 1
Ok "Programação Geral aberta."

# =========================
# 3. MÊS ATUAL
# =========================
Etapa "[3/12] Selecionando os filtros corretos da Programação Geral..."
$mesAtualIso = Get-Date -Format "yyyy-MM"
$mesAtualPt = (Get-Culture).DateTimeFormat.GetMonthName((Get-Date).Month)
$anoAtual = (Get-Date).Year

# IMPORTANTE V5.5:
# Não usamos mais os primeiros ComboBox da página.
# Primeiro localizamos o botão VERDE "Copiar ordens do mês selecionado".
# Depois pegamos somente os combos da mesma faixa visual da tabela, abaixo/ao lado dele.
$copiarAnchor = Find-Uia -NameRegex "(?i)Copiar ordens do mês selecionado|Copiar ordens do mes selecionado" -TimeoutSeconds 20
if (-not $copiarAnchor) { Falha "Botão Copiar ordens do mês selecionado não encontrado para ancorar os filtros." }

$br = $copiarAnchor.Current.BoundingRectangle
$allCombos = Get-Descendants $script:ScopeRoot | Where-Object {
    try { $_.Current.ControlType.ProgrammaticName -eq "ControlType.ComboBox" } catch { $false }
}

# A faixa correta fica logo abaixo do botão verde e na mesma região horizontal.
$combosFaixa = @(
    $allCombos | Where-Object {
        try {
            $r = $_.Current.BoundingRectangle
            $sameBand = ($r.Top -ge ($br.Bottom - 25)) -and ($r.Top -le ($br.Bottom + 120))
            $nearX = ($r.Left -ge ($br.Left - 650)) -and ($r.Left -le ($br.Right + 350))
            $sameBand -and $nearX
        } catch { $false }
    } | Sort-Object { $_.Current.BoundingRectangle.Left }
)

if ($combosFaixa.Count -lt 2) {
    Falha "Não encontrei os filtros de mês/semana na faixa correta abaixo do botão verde."
}

# Pela disposição da tela do Portal:
# ... [Mês] [Semana] [Turno] [Célula]
# Usamos o primeiro e o segundo combo dessa faixa.
$comboMes = $combosFaixa[0]
$comboSemana = $combosFaixa[1]

Write-Host "Filtro mês    : $($comboMes.Current.Name)" -ForegroundColor DarkGray
Write-Host "Filtro semana : $($comboSemana.Current.Name)" -ForegroundColor DarkGray

# Seleciona o mês atual no filtro da TABELA.
$okMes = Select-ComboByText $comboMes ("(?i)" + [regex]::Escape($mesAtualPt) + ".*" + $anoAtual)
if (-not $okMes) {
    $okMes = Select-ComboByText $comboMes ([regex]::Escape($mesAtualIso))
}
if (-not $okMes) { Falha "Não consegui selecionar o mês atual no filtro correto da tabela." }

# Semana: o fluxo precisa considerar TODAS as semanas.
# Normalmente a primeira opção é "Todas as semanas".
$okSem = Select-ComboByText $comboSemana "(?i)^Todas as semanas$|^Todas$|All"
if (-not $okSem) {
    try {
        $comboSemana.SetFocus()
        Add-Type -AssemblyName System.Windows.Forms
        [System.Windows.Forms.SendKeys]::SendWait("{HOME}{ENTER}")
        $okSem = $true
    } catch {}
}
if (-not $okSem) { Falha "Não consegui deixar todas as semanas selecionadas." }

Ok "Filtro correto: mês atual + todas as semanas."

# =========================
# 4. COPIAR ORDENS
# =========================
Etapa "[4/12] Copiando ordens do mês selecionado..."
$copiar = $copiarAnchor
if (-not $copiar) { Falha "Botão Copiar ordens do mês selecionado não encontrado." }

# Limpa o Clipboard para termos certeza de que o conteúdo recebido é novo.
try { Set-Clipboard -Value "" } catch {}

# V5.4: clique FÍSICO real. O Portal usa navigator.clipboard.writeText().
# O Chrome exige gesto real do usuário; InvokePattern do UI Automation pode clicar
# visualmente, mas não concede permissão ao Clipboard.
if (-not (Click-UiaReal $copiar)) {
    Falha "Não consegui executar clique físico em Copiar ordens."
}

# O Portal mostra um alert após copiar. Aguarda o Clipboard primeiro, para não
# interromper a Promise antes de ela terminar.
$clip = $null
$limiteClip = (Get-Date).AddSeconds(12)
while ((Get-Date) -lt $limiteClip) {
    try {
        $tmp = Get-Clipboard -Raw -ErrorAction SilentlyContinue
        if ($tmp -and $tmp.Trim().Length -ge 3) {
            $clip = $tmp.Trim()
            break
        }
    } catch {}
    Start-Sleep -Milliseconds 500
}

# Fecha o alert "X ordens ... copiadas" somente depois da tentativa de cópia.
$okPortal = Find-Uia -NameRegex "^OK$|^Ok$" -ControlTypes @("Button") -TimeoutSeconds 4
if ($okPortal) {
    Click-UiaReal $okPortal | Out-Null
    Start-Sleep -Milliseconds 300
}

# Se o Chrome mostrou uma permissão de Clipboard, tenta permitir e repete o clique.
if (-not $clip) {
    $permitir = Find-Uia -NameRegex "(?i)Permitir|Allow" -ControlTypes @("Button") -TimeoutSeconds 2
    if ($permitir) {
        Click-UiaReal $permitir | Out-Null
        Start-Sleep -Milliseconds 500
        Click-UiaReal $copiar | Out-Null

        $limiteClip2 = (Get-Date).AddSeconds(8)
        while ((Get-Date) -lt $limiteClip2) {
            try {
                $tmp = Get-Clipboard -Raw -ErrorAction SilentlyContinue
                if ($tmp -and $tmp.Trim().Length -ge 3) {
                    $clip = $tmp.Trim()
                    break
                }
            } catch {}
            Start-Sleep -Milliseconds 500
        }

        $okPortal2 = Find-Uia -NameRegex "^OK$|^Ok$" -ControlTypes @("Button") -TimeoutSeconds 3
        if ($okPortal2) { Click-UiaReal $okPortal2 | Out-Null }
    }
}

if (-not $clip) {
    Falha "Clipboard continuou vazio. O clique no botão ocorreu, mas o Chrome não liberou a cópia."
}

# Validação simples: as ordens devem ser linhas numéricas.
$linhasClip = @($clip -split "\r?\n" | Where-Object { $_.Trim() -match "^\d+$" })
if ($linhasClip.Count -lt 1) {
    Falha "Clipboard recebeu conteúdo, mas não parece ser a lista de ordens SAP."
}

Ok "$($linhasClip.Count) ordens copiadas para o Clipboard."

# =========================
# 5. ABRIR SAP
# =========================
Etapa "[5/12] Abrindo SAP Aurora pela página inicial..."
Start-Process -FilePath $Chrome -ArgumentList @("--force-renderer-accessibility", "`"$SapHomeUrl`"")
Start-Sleep -Seconds 6

# Reaponta a UI Automation somente para a janela ativa do Chrome/SAP.
if (-not (Set-UiaScopeToForeground)) {
    Falha "SAP abriu, mas não consegui limitar a automação à janela do SAP."
}
Ok "Página inicial do SAP Aurora aberta e isolada para automação."

# V5.8: abre a IW38 pelo TILE real existente na Home do SAP.
# Não usa mais a rota #MaintenanceOrder-changelist, pois o launchpad da fábrica
# retornou erro de resolução do destino.
Etapa "[5.1/12] Abrindo IW38 pelo tile da página inicial do SAP..."

# Procura SOMENTE dentro da janela SAP atualmente ativa.
# Não fecha abas, não usa Ctrl+W e não percorre outras janelas/processos.
$iw38Tile = Find-Uia -NameRegex "(?i)^IW38$|IW38.*Modificar ordens|Modificar ordens.*IW38" -ControlTypes @("Button","Hyperlink","ListItem","DataItem","Text","Custom") -TimeoutSeconds 15

if (-not $iw38Tile) {
    # Fallback sem restringir tipo de controle.
    $iw38Tile = Find-Uia -NameRegex "(?i)^IW38$|IW38.*Modificar ordens|Modificar ordens.*IW38" -TimeoutSeconds 10
}

if (-not $iw38Tile) {
    Falha "Tile IW38 não encontrado na página inicial do SAP."
}

# Tenta clique físico real no tile; InvokePattern como fallback.
if (-not (Click-UiaReal $iw38Tile)) {
    if (-not (Invoke-Uia $iw38Tile)) {
        Falha "Encontrei o tile IW38, mas não consegui abri-lo."
    }
}

Start-Sleep -Seconds 2
Set-UiaScopeToForeground | Out-Null

# Aguarda a tela real da IW38.
$limitIW38 = (Get-Date).AddSeconds(40)
$iw38Loaded = $false

while ((Get-Date) -lt $limitIW38) {
    $probeConcluido = Find-Uia -NameRegex "(?i)^Conclu[ií]do$|Conclu[ií]do" -TimeoutSeconds 1
    $probeHistorico = Find-Uia -NameRegex "(?i)^Hist[oó]rico$|Hist[oó]rico" -TimeoutSeconds 1

    if ($probeConcluido -or $probeHistorico) {
        $iw38Loaded = $true
        break
    }

    Start-Sleep -Milliseconds 700
}

if (-not $iw38Loaded) {
    Falha "O tile IW38 foi clicado, mas a tela real da transação não carregou Concluído/Histórico."
}

Ok "IW38 aberta pelo tile da Home e carregada."

# =========================
# 6. CONCLUÍDO + HISTÓRICO
# =========================
Etapa "[6/12] Marcando Concluído e Histórico..."
$concluido = Find-Uia -NameRegex "(?i)^Conclu[ií]do$|Conclu[ií]do" -TimeoutSeconds 15
$historico = Find-Uia -NameRegex "(?i)^Hist[oó]rico$|Hist[oó]rico" -TimeoutSeconds 15

if (-not $concluido) { Falha "IW38 abriu, mas o controle Concluído não foi encontrado." }
if (-not $historico) { Falha "IW38 abriu, mas o controle Histórico não foi encontrado." }

# Preferência por UI Automation Toggle; clique físico como fallback.
if (-not (Invoke-Uia $concluido)) {
    if (-not (Click-UiaReal $concluido)) { Falha "Não consegui marcar Concluído." }
}
if (-not (Invoke-Uia $historico)) {
    if (-not (Click-UiaReal $historico)) { Falha "Não consegui marcar Histórico." }
}
Ok "Concluído e Histórico marcados."

# =========================
# 7. SELEÇÃO MÚLTIPLA / CLIPBOARD
# =========================
Etapa "[7/12] Colando ordens na seleção múltipla..."
$multi = Find-Uia -NameRegex "(?i)sele[cç][aã]o m[uú]ltipla.*ordem|ordem.*sele[cç][aã]o m[uú]ltipla|valores m[uú]ltiplos" -TimeoutSeconds 15

if (-not $multi) {
    # Fallback: tenta botão genérico próximo ao texto Ordem.
    $multi = Find-Uia -NameRegex "(?i)sele[cç][aã]o m[uú]ltipla|m[uú]ltiplos" -TimeoutSeconds 10
}
if (-not $multi) { Falha "Botão de seleção múltipla do campo Ordem não encontrado." }
Invoke-Uia $multi | Out-Null
Start-Sleep -Seconds 1

$upload = Find-Uia -NameRegex "(?i)clipboard|área de transfer|upload.*clip|Shift\+F12" -TimeoutSeconds 10
if ($upload) {
    Invoke-Uia $upload | Out-Null
} else {
    Add-Type -AssemblyName System.Windows.Forms
    [System.Windows.Forms.SendKeys]::SendWait("+{F12}")
}
Start-Sleep -Seconds 1

$transferir = Find-Uia -NameRegex "(?i)^Transferir$|Transferir.*F8|^F8$" -TimeoutSeconds 10
if ($transferir) {
    Invoke-Uia $transferir | Out-Null
} else {
    Add-Type -AssemblyName System.Windows.Forms
    [System.Windows.Forms.SendKeys]::SendWait("{F8}")
}
Start-Sleep -Seconds 1
Ok "Ordens transferidas."

# =========================
# 8. PERÍODO / LAYOUT / EXECUTAR
# =========================
Etapa "[8/12] Limpando Período e aplicando Layout /elieserpo..."

# Busca edits por nome acessível.
$edits = Get-Descendants $script:ScopeRoot | Where-Object {
    try { $_.Current.ControlType.ProgrammaticName -eq "ControlType.Edit" } catch { $false }
}

$periodos = @()
$layoutEdit = $null
foreach ($e in $edits) {
    try {
        $n = $e.Current.Name
        if ($n -match "(?i)per[ií]odo|data.*de|data.*at[eé]") { $periodos += $e }
        if (-not $layoutEdit -and $n -match "(?i)layout|variante") { $layoutEdit = $e }
    } catch {}
}

# Fallback: campos com valor parecido com data.
if ($periodos.Count -lt 2) {
    foreach ($e in $edits) {
        try {
            $vp = $e.GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern)
            if ($vp.Current.Value -match "^\d{1,2}[./]\d{1,2}[./]\d{2,4}$") {
                $periodos += $e
            }
        } catch {}
    }
}

$periodos | Select-Object -First 2 | ForEach-Object { Set-UiaValue $_ "" | Out-Null }

if (-not $layoutEdit) {
    # Busca edit cujo nome/ajuda contenha Layout.
    $layoutEdit = Find-Uia -NameRegex "(?i)Layout|Variante" -ControlTypes @("Edit") -TimeoutSeconds 10
}
if (-not $layoutEdit) { Falha "Campo Layout não encontrado." }
if (-not (Set-UiaValue $layoutEdit $LayoutSAP)) { Falha "Não consegui preencher Layout." }

$executar = Find-Uia -NameRegex "(?i)^Executar$|Executar.*F8" -TimeoutSeconds 10
if ($executar) {
    Invoke-Uia $executar | Out-Null
} else {
    Add-Type -AssemblyName System.Windows.Forms
    [System.Windows.Forms.SendKeys]::SendWait("{F8}")
}
Start-Sleep -Seconds 5
Ok "IW38 executada."

# =========================
# 9. SELECIONAR TODAS
# =========================
Etapa "[9/12] Selecionando todas as ordens do relatório..."

# V5.10: NÃO clicar mais no cabeçalho "Ordem".
# Na V5.9 esse clique podia abrir a primeira ordem da lista.
# O correto é usar o controle de seleção geral/checkbox do grid.

$selecionarTudo = Find-Uia -NameRegex "(?i)^Selecionar$|Selecionar tudo|Marcar tudo|Select all|Selecionar todas" -ControlTypes @("CheckBox","Button","Custom") -TimeoutSeconds 12

if (-not $selecionarTudo) {
    # Fallback: procura qualquer CheckBox do grid próximo ao topo da lista.
    $checks = @(Get-Descendants $script:ScopeRoot | Where-Object {
        try { $_.Current.ControlType.ProgrammaticName -eq "ControlType.CheckBox" } catch { $false }
    })
    if ($checks.Count -gt 0) {
        # Preferimos o checkbox mais alto da tela, típico "selecionar tudo" do cabeçalho.
        $selecionarTudo = $checks | Sort-Object { $_.Current.BoundingRectangle.Top } | Select-Object -First 1
    }
}

if (-not $selecionarTudo) {
    Falha "Controle Selecionar tudo não encontrado no relatório IW38."
}

# Usa Toggle/Invoke no checkbox; clique físico só como fallback.
$okSelect = $false
try {
    $tp = $selecionarTudo.GetCurrentPattern([System.Windows.Automation.TogglePattern]::Pattern)
    if ($tp.Current.ToggleState -ne [System.Windows.Automation.ToggleState]::On) {
        $tp.Toggle()
    }
    $okSelect = $true
} catch {}

if (-not $okSelect) {
    try {
        $ip = $selecionarTudo.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern)
        $ip.Invoke()
        $okSelect = $true
    } catch {}
}

if (-not $okSelect) {
    $okSelect = Click-UiaReal $selecionarTudo
}

if (-not $okSelect) {
    Falha "Encontrei Selecionar tudo, mas não consegui marcar."
}

Start-Sleep -Milliseconds 800

# Segurança: se a automação saiu da lista e abriu uma ordem, interrompe.
$ordemDetalhe = Find-Uia -NameRegex "(?i)Modificar Ordem:\s*1[ªa]\s*tela" -TimeoutSeconds 2
if ($ordemDetalhe) {
    Falha "Uma ordem foi aberta por engano. Exportação interrompida para não operar na tela errada."
}

Ok "Todas as ordens selecionadas no grid."

# =========================
# 10. MENU -> LISTA -> GRAVAR -> FILE
# =========================
Etapa "[10/12] Menu -> Lista -> Gravar -> File..."

# Confirma que ainda estamos na lista da IW38.
$listaIW38 = Find-Uia -NameRegex "(?i)Modificar ordens PM:\s*Lista ordens|Lista ordens" -TimeoutSeconds 5
if (-not $listaIW38) {
    Falha "Tela Lista ordens da IW38 não confirmada antes da exportação."
}

$menu = Find-Uia -NameRegex "^Menu$" -TimeoutSeconds 15
if (-not $menu) { Falha "Menu do SAP não encontrado." }

# Clique físico no Menu.
if (-not (Click-UiaReal $menu)) {
    if (-not (Invoke-Uia $menu)) { Falha "Não consegui abrir o Menu do SAP." }
}
Start-Sleep -Milliseconds 700

# No SAP GUI HTML, Lista e Gravar abrem submenu por HOVER, não por clique.
$lista = Find-Uia -NameRegex "^Lista$" -TimeoutSeconds 10
if (-not $lista) { Falha "Item Lista não encontrado no Menu." }
if (-not (Hover-UiaReal $lista)) { Falha "Não consegui posicionar o mouse sobre Lista." }
Start-Sleep -Milliseconds 700

$gravar = Find-Uia -NameRegex "^Gravar$" -TimeoutSeconds 10
if (-not $gravar) { Falha "Submenu Gravar não apareceu após Lista." }
if (-not (Hover-UiaReal $gravar)) { Falha "Não consegui posicionar o mouse sobre Gravar." }
Start-Sleep -Milliseconds 700

$file = Find-Uia -NameRegex "(?i)^File\.*$|^File$" -TimeoutSeconds 10
if (-not $file) { Falha "Item File... não apareceu após Gravar." }

if (-not (Click-UiaReal $file)) {
    if (-not (Invoke-Uia $file)) { Falha "Não consegui abrir File..." }
}
Start-Sleep -Seconds 1
Ok "Menu Lista -> Gravar -> File aberto corretamente."

# =========================
# 11. HTML -> AVANÇAR -> OK
# =========================
Etapa "[11/12] HTML -> Avançar -> OK..."

# V5.14: correção do passo HTML -> Avançar usando geometria segura do diálogo.
# IMPORTANTE: não usa TAB/ENTER às cegas, porque o foco do SAP pode cair em Cancelar.
# O script agora localiza o botão Avançar, sobe até o controle Button quando necessário,
# executa clique físico real no centro do botão e só continua se o próximo diálogo aparecer.

Set-UiaScopeToForeground | Out-Null
$html = Find-Uia -NameRegex "^HTML$" -TimeoutSeconds 10
if (-not $html) { Falha "Opção HTML não encontrada." }

# Marca HTML.
$htmlOk = $false
try {
    $tp = $html.GetCurrentPattern([System.Windows.Automation.TogglePattern]::Pattern)
    if ($tp.Current.ToggleState -ne [System.Windows.Automation.ToggleState]::On) {
        $tp.Toggle()
    }
    $htmlOk = $true
} catch {}
if (-not $htmlOk) {
    try {
        $sp = $html.GetCurrentPattern([System.Windows.Automation.SelectionItemPattern]::Pattern)
        $sp.Select()
        $htmlOk = $true
    } catch {}
}
if (-not $htmlOk) { $htmlOk = Click-UiaReal $html }
if (-not $htmlOk) { Falha "Não consegui marcar HTML." }

Start-Sleep -Milliseconds 700
Set-UiaScopeToForeground | Out-Null

# Estratégia V5.14:
# 1) tenta o botão pelo nome;
# 2) se o SAP não expuser o nome, localiza "Cancelar" e escolhe o botão imediatamente à esquerda;
# 3) último fallback: usa a geometria do próprio diálogo, clicando na região do botão Avançar.
# Nunca usa TAB/ENTER às cegas nesta tela.

function Click-XY([int]$X,[int]$Y) {
    try {
        [NativeMouseSAP504]::SetCursorPos($X,$Y) | Out-Null
        Start-Sleep -Milliseconds 180
        [NativeMouseSAP504]::mouse_event([NativeMouseSAP504]::MOUSEEVENTF_LEFTDOWN,0,0,0,[UIntPtr]::Zero)
        Start-Sleep -Milliseconds 80
        [NativeMouseSAP504]::mouse_event([NativeMouseSAP504]::MOUSEEVENTF_LEFTUP,0,0,0,[UIntPtr]::Zero)
        return $true
    } catch { return $false }
}

function Get-ButtonLeftOfCancelar {
    param([System.Windows.Automation.AutomationElement]$Root)
    if (-not $Root) { return $null }
    try {
        $all = Get-Descendants $Root
        $cancel = $null
        foreach ($e in $all) {
            try {
                if ($e.Current.Name -match '(?i)^Cancelar$') { $cancel = $e; break }
            } catch {}
        }
        if (-not $cancel) { return $null }
        $rc = $cancel.Current.BoundingRectangle
        $cy = $rc.Top + ($rc.Height/2)
        $best = $null
        $bestDx = 999999
        foreach ($e in $all) {
            try {
                if ($e -eq $cancel) { continue }
                $ct = $e.Current.ControlType.ProgrammaticName
                if ($ct -ne 'ControlType.Button') { continue }
                $r = $e.Current.BoundingRectangle
                if ($r.Width -le 5 -or $r.Height -le 5) { continue }
                $ey = $r.Top + ($r.Height/2)
                if ([Math]::Abs($ey - $cy) -gt 35) { continue }
                if ($r.Left -ge $rc.Left) { continue }
                $dx = $rc.Left - ($r.Left + $r.Width)
                if ($dx -ge -10 -and $dx -lt $bestDx) { $best = $e; $bestDx = $dx }
            } catch {}
        }
        return $best
    } catch { return $null }
}

function Get-DialogFromElement {
    param([System.Windows.Automation.AutomationElement]$Element)
    $cur = $Element
    $best = $null
    for ($i=0; $i -lt 12 -and $cur; $i++) {
        try {
            $r = $cur.Current.BoundingRectangle
            if ($r.Width -ge 260 -and $r.Width -le 900 -and $r.Height -ge 180 -and $r.Height -le 700) {
                $best = $cur
            }
            $name = $cur.Current.Name
            if ($name -match '(?i)Gravar lista em file') { return $cur }
            $cur = [System.Windows.Automation.TreeWalker]::ControlViewWalker.GetParent($cur)
        } catch { break }
    }
    return $best
}

$avancou = $false

# 1) Pelo nome, quando o Chrome/SAP expõe o botão corretamente.
$avancar = Find-Uia -NameRegex '(?i)Avan[cç]ar' -ControlTypes @('Button') -TimeoutSeconds 3
if (-not $avancar) { $avancar = Find-Uia -NameRegex '(?i)Avan[cç]ar' -TimeoutSeconds 2 }
if ($avancar) {
    $avancou = Click-UiaReal $avancar
}

# 2) Pela posição relativa ao botão Cancelar, sem risco de clicar no próprio Cancelar.
if (-not $avancou) {
    Set-UiaScopeToForeground | Out-Null
    $leftButton = Get-ButtonLeftOfCancelar $script:ScopeRoot
    if ($leftButton) {
        $avancou = Click-UiaReal $leftButton
    }
}

# 3) Geometria do diálogo. A foto/teste confirmou que Avançar fica no rodapé,
# imediatamente antes de Cancelar. Clicamos em ~72% da largura e 91% da altura.
if (-not $avancou) {
    Set-UiaScopeToForeground | Out-Null
    $dlg = Get-DialogFromElement $html
    if ($dlg) {
        try {
            $rd = $dlg.Current.BoundingRectangle
            $x = [int]($rd.Left + ($rd.Width * 0.72))
            $y = [int]($rd.Top  + ($rd.Height * 0.91))
            $avancou = Click-XY $x $y
        } catch {}
    }
}

if (-not $avancou) {
    Falha 'HTML foi marcado, mas não consegui acionar Avançar. Nenhum comando de Cancelar foi enviado.'
}

# Só considera sucesso se a próxima tela realmente abrir.
Start-Sleep -Milliseconds 1200
Set-UiaScopeToForeground | Out-Null
$dialogNome = Find-Uia -NameRegex '(?i)Inserir nome de arquivo para gravar|Nome do arquivo' -TimeoutSeconds 8

if (-not $dialogNome) {
    # Uma segunda tentativa é permitida somente se ainda estivermos no mesmo diálogo.
    Set-UiaScopeToForeground | Out-Null
    $htmlAinda = Find-Uia -NameRegex '^HTML$' -TimeoutSeconds 2
    if ($htmlAinda) {
        $leftButton2 = Get-ButtonLeftOfCancelar $script:ScopeRoot
        if ($leftButton2) {
            Click-UiaReal $leftButton2 | Out-Null
        } else {
            $dlg2 = Get-DialogFromElement $htmlAinda
            if ($dlg2) {
                try {
                    $r2 = $dlg2.Current.BoundingRectangle
                    Click-XY ([int]($r2.Left + ($r2.Width * 0.72))) ([int]($r2.Top + ($r2.Height * 0.91))) | Out-Null
                } catch {}
            }
        }
        Start-Sleep -Milliseconds 1300
        Set-UiaScopeToForeground | Out-Null
        $dialogNome = Find-Uia -NameRegex '(?i)Inserir nome de arquivo para gravar|Nome do arquivo' -TimeoutSeconds 5
    }
}

if (-not $dialogNome) {
    Falha 'HTML continua selecionado, mas a tela seguinte não abriu. O script parou sem clicar em Cancelar.'
}

Ok "Avançar acionado e diálogo de nome aberto."

# NÃO altera o nome do arquivo.
Set-UiaScopeToForeground | Out-Null
$okFinal = Find-Uia -NameRegex "^OK$" -ControlTypes @("Button") -TimeoutSeconds 10
if (-not $okFinal) {
    $okFinal = Find-Uia -NameRegex "^OK$" -TimeoutSeconds 5
}
if (-not $okFinal) { Falha "Diálogo de nome abriu, mas o botão OK final não foi encontrado." }

# Também usa clique físico no OK final; Enter fica apenas como fallback.
$confirmou = Click-UiaReal $okFinal
if (-not $confirmou) {
    try {
        $ip = $okFinal.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern)
        $ip.Invoke()
        $confirmou = $true
    } catch {}
}
if (-not $confirmou) { Falha "Não consegui confirmar o OK final." }

Ok "Download HTML solicitado sem alterar o nome."

# =========================
# 12. DOWNLOAD + GIT
# =========================
Etapa "[12/12] Aguardando HTML, renomeando e enviando ao GitHub..."

$InicioDownload = Get-Date
$Limite = (Get-Date).AddMinutes($TimeoutDownloadMin)
$Arquivo = $null
$UltimoTam = -1
$Estavel = 0

while ((Get-Date) -lt $Limite) {
    $cand = Get-ChildItem -LiteralPath $Downloads -Filter "filetmp*.htm" -File -ErrorAction SilentlyContinue |
        Where-Object { $_.LastWriteTime -ge $InicioDownload.AddSeconds(-20) } |
        Sort-Object LastWriteTime -Descending |
        Select-Object -First 1

    if ($cand) {
        if ($cand.Length -eq $UltimoTam -and $cand.Length -gt 0) { $Estavel++ }
        else { $Estavel = 0; $UltimoTam = $cand.Length }

        if ($Estavel -ge 2) { $Arquivo = $cand; break }
    }
    Start-Sleep -Seconds 2
}

if (-not $Arquivo) { Falha "filetmp*.htm não apareceu em $Downloads." }
if ($Arquivo.Length -lt $TamanhoMinimoBytes) {
    Falha "HTML baixado é pequeno demais: $($Arquivo.Length) bytes."
}

if (Test-Path -LiteralPath $DestinoRelatorio) {
    Remove-Item -LiteralPath $DestinoRelatorio -Force
}
Move-Item -LiteralPath $Arquivo.FullName -Destination $DestinoRelatorio -Force
Ok "Relatório salvo como ordens_status.htm."

# =========================
# V5.19 - SALVAR INDEX LOCAL
# =========================
# IMPORTANTE: daqui para cima, o fluxo SAP é exatamente o V5.14 que já funcionava.
# Esta etapa apenas aplica os status do novo ordens_status.htm à base embutida do
# Index local, preservando programação, responsáveis, células e demais dados locais.
Etapa "[12.1/12] Salvando os novos status SAP no Index local..."
$NodeExe = (Get-Command node.exe -ErrorAction SilentlyContinue).Source
if (-not $NodeExe) { $NodeExe = (Get-Command node -ErrorAction SilentlyContinue).Source }
if (-not $NodeExe) { Falha "Node.js não encontrado para salvar o Index atualizado." }
$AtualizadorIndex = Join-Path $PSScriptRoot "atualizar_index_local.js"
if (-not (Test-Path -LiteralPath $AtualizadorIndex)) { Falha "Atualizador do Index não encontrado: $AtualizadorIndex" }

& $NodeExe $AtualizadorIndex --index $PortalIndex --report $DestinoRelatorio
if ($LASTEXITCODE -ne 0) { Falha "O relatório SAP foi salvo, mas o Index não pôde ser atualizado. O backup do Index foi preservado." }
Ok "Index local atualizado e salvo com os novos status SAP."

# Git.exe conhecido no VD.
$GitExe = @(
    "$env:LOCALAPPDATA\Programs\Git\cmd\git.exe",
    "$env:ProgramFiles\Git\cmd\git.exe",
    "${env:ProgramFiles(x86)}\Git\cmd\git.exe"
) | Where-Object { $_ -and (Test-Path -LiteralPath $_) } | Select-Object -First 1

if (-not $GitExe) { Falha "git.exe não encontrado." }

Set-Location -LiteralPath $GitHub

& $GitExe config --global user.name "Gaps Designe"
& $GitExe config --global user.email "guilhermegaps91@gmail.com"
& $GitExe config --global --add safe.directory "$GitHub" 2>$null | Out-Null

& $GitExe fetch origin main
if ($LASTEXITCODE -ne 0) { Falha "git fetch falhou." }

& $GitExe pull --rebase origin main
if ($LASTEXITCODE -ne 0) { Falha "git pull --rebase falhou." }

Copy-Item -LiteralPath $DestinoRelatorio -Destination $DestinoGit -Force

& $GitExe add -- "ordens_status.htm"
if ($LASTEXITCODE -ne 0) { Falha "git add falhou." }

& $GitExe diff --cached --quiet
if ($LASTEXITCODE -eq 0) {
    Ok "Arquivo não mudou; GitHub já estava atualizado."
} else {
    $DataCommit = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    & $GitExe commit -m "Atualiza status das ordens SAP - $DataCommit"
    if ($LASTEXITCODE -ne 0) { Falha "git commit falhou." }

    & $GitExe push origin main
    if ($LASTEXITCODE -ne 0) { Falha "git push falhou." }

    Ok "Push concluído em origin/main."
}

Titulo "V5.19 CONCLUÍDA - FLUXO V5.14 + INDEX SALVO + GITHUB"
Write-Host "GitHub Actions assumirá o deploy." -ForegroundColor Green
