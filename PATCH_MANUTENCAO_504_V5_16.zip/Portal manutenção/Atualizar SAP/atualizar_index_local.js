"use strict";

const fs = require("fs");
const path = require("path");

function fail(msg){
  console.error("[INDEX-SAP] ERRO:", msg);
  process.exit(1);
}
function norm(value){
  return String(value ?? "").replace(/\u00a0/g," ").trim().toUpperCase()
    .normalize("NFD").replace(/[\u0300-\u036f]/g,"").replace(/\s+/g," ");
}
function decodeEntities(value){
  return String(value ?? "")
    .replace(/&nbsp;/gi," ")
    .replace(/&#x([0-9a-f]+);/gi,(_,h)=>String.fromCodePoint(parseInt(h,16)))
    .replace(/&#(\d+);/g,(_,d)=>String.fromCodePoint(parseInt(d,10)))
    .replace(/&amp;/gi,"&").replace(/&lt;/gi,"<").replace(/&gt;/gi,">")
    .replace(/&quot;/gi,'"').replace(/&#39;/gi,"'");
}
function cellText(html){
  return decodeEntities(String(html).replace(/<script\b[\s\S]*?<\/script>/gi,"")
    .replace(/<style\b[\s\S]*?<\/style>/gi,"")
    .replace(/<br\s*\/?\s*>/gi," ").replace(/<[^>]+>/g," "))
    .replace(/\s+/g," ").trim();
}
function parseSapHtml(html){
  const rows=[];
  const trRe=/<tr\b[^>]*>([\s\S]*?)<\/tr>/gi;
  let tr;
  while((tr=trRe.exec(html))){
    const cells=[];
    const tdRe=/<(?:td|th)\b[^>]*>([\s\S]*?)<\/(?:td|th)>/gi;
    let td;
    while((td=tdRe.exec(tr[1]))) cells.push(cellText(td[1]));
    if(cells.length) rows.push(cells);
  }
  if(!rows.length) throw new Error("Nenhuma tabela encontrada no relatório SAP.");

  const aliases={
    order:["ORDEM","N°ORDEM","Nº ORDEM"],
    orderType:["TP.","TIPO DE ORDEM","TIPO ORDEM"],
    date:["INÍCIOBASE","INICIOBASE","DATA-BASE INÍC.","DATA-BASE INIC"],
    desc:["TEXTO BREVE","TXTDESC.OPER.","DESCRIÇÃO OPERACIONAL"],
    loc:["LOCAL DE INSTALAÇÃO","LOC.INSTALAÇÃO","LOC.INSTALACAO"],
    workCenter:["CENTRABPR.","CENTRO DE TRABALHO","CEN TRAB PR","CENTRABPR"],
    type:["TAM","TIP.ATIV.MANUT.","TP.ATVD"],
    userStatus:["STATUSUSUÁR.","STATUS USUÁRIO","STATUS USUARIO","STATUSUÁR.","STATUSUAR.","STATUSUSUAR.","STATUSUAR","STATUSUSUAR","STATUSUSUÁRIO","STATUSUSUARIO","STATUS USUÁR.","STATUS USUAR.","STATUsuár."],
    sap:["STATUS DO SISTEMA","STATUS SISTEMA"]
  };
  const exactIndex=(headers,names)=>{
    const hh=headers.map(norm); for(const n of names){const i=hh.indexOf(norm(n)); if(i>=0)return i;} return -1;
  };
  const looseIndex=(headers,names)=>{
    const exact=exactIndex(headers,names); if(exact>=0)return exact;
    const hh=headers.map(norm); for(const n of names){const a=norm(n); const i=hh.findIndex(h=>h.includes(a)); if(i>=0)return i;} return -1;
  };
  let best=null,bestScore=-1;
  rows.slice(0,60).forEach((row,ri)=>{
    let score=0;
    for(const k of ["order","date","desc","loc","type"]) if(looseIndex(row,aliases[k])>=0)score++;
    if(exactIndex(row,aliases.sap)>=0)score+=2;
    if(score>bestScore){bestScore=score;best={ri,headers:row};}
  });
  if(!best) throw new Error("Cabeçalho SAP não encontrado.");
  const h=best.headers;
  const idx={
    order:looseIndex(h,aliases.order), orderType:looseIndex(h,aliases.orderType), date:looseIndex(h,aliases.date),
    desc:looseIndex(h,aliases.desc), loc:looseIndex(h,aliases.loc), workCenter:looseIndex(h,aliases.workCenter),
    type:looseIndex(h,aliases.type), userStatus:looseIndex(h,aliases.userStatus), sap:exactIndex(h,aliases.sap)
  };
  if(idx.order<0) throw new Error("Coluna Ordem não encontrada.");
  if(idx.sap<0) throw new Error("Coluna exata 'Status do sistema' não encontrada. A atualização foi bloqueada para não confundir com StatUsuár.");

  const out=[];
  for(const row of rows.slice(best.ri+1)){
    const col=k=>idx[k]>=0 && idx[k]<row.length ? String(row[idx[k]]||"").trim() : "";
    const order=col("order").replace(/\D/g,"");
    if(!/^\d{6,}$/.test(order)) continue;
    out.push({order,orderType:col("orderType"),date:col("date"),desc:col("desc"),loc:col("loc"),workCenter:col("workCenter"),type:col("type"),userStatus:col("userStatus"),sap:col("sap")});
  }
  const seen=new Set();
  for(const r of out){ if(seen.has(r.order)) throw new Error(`Ordem duplicada no relatório: ${r.order}`); seen.add(r.order); }
  if(!out.length) throw new Error("Nenhuma ordem válida encontrada no relatório.");
  return out;
}

function extractArray(text,marker){
  const m=text.indexOf(marker); if(m<0) throw new Error(`Marcador não encontrado: ${marker}`);
  const start=text.indexOf("[",m); if(start<0) throw new Error("Início da base embutida não encontrado.");
  let depth=0,inString=false,escaped=false;
  for(let i=start;i<text.length;i++){
    const ch=text[i];
    if(inString){
      if(escaped) escaped=false; else if(ch==="\\") escaped=true; else if(ch==='"') inString=false;
    }else{
      if(ch==='"') inString=true;
      else if(ch==='[') depth++;
      else if(ch===']'){ depth--; if(depth===0)return {start,end:i+1,json:text.slice(start,i+1)}; }
    }
  }
  throw new Error("Fim da base embutida não encontrado.");
}
function isConfirmed(s){ return /(^|\s)CONF(\s|$)/i.test(String(s||"").trim()); }
function nowVersion(){
  const d=new Date(),p=n=>String(n).padStart(2,"0");
  return `AUTO_SAP_${d.getFullYear()}${p(d.getMonth()+1)}${p(d.getDate())}${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}`;
}
function main(){
  const args=process.argv.slice(2);
  const get=name=>{const i=args.indexOf(name); return i>=0?args[i+1]:null;};
  const indexPath=path.resolve(get("--index")||path.join(__dirname,"..","index_programacao_operacional.html"));
  const reportPath=path.resolve(get("--report")||path.join(__dirname,"..","Relatórios SAP","ordens_status.htm"));
  if(!fs.existsSync(indexPath)) fail(`Index não encontrado: ${indexPath}`);
  if(!fs.existsSync(reportPath)) fail(`Relatório não encontrado: ${reportPath}`);

  let text=fs.readFileSync(indexPath,"utf8").replace(/^\uFEFF/,"");
  const rows=parseSapHtml(fs.readFileSync(reportPath,"utf8"));
  const block=extractArray(text,"const DEMO =");
  const orders=JSON.parse(block.json);
  if(!Array.isArray(orders)) throw new Error("Base DEMO inválida.");
  const map=new Map(orders.map(o=>[String(o.order||"").trim(),o]));
  const beforeConf=orders.filter(o=>isConfirmed(o.sap)).length;
  let updated=0,created=0,newConf=0;
  const stamp=new Date().toISOString();

  for(const row of rows){
    const current=map.get(row.order);
    if(current){
      const was=isConfirmed(current.sap);
      for(const f of ["orderType","desc","loc","workCenter","type","userStatus","sap"]) current[f]=row[f]??"";
      if(row.date) current.sapDate=row.date; // preserva a data programada em current.date
      current.importedAt=stamp;
      if(!was && isConfirmed(current.sap)){ current.completedAt=stamp; newConf++; }
      updated++;
    }else{
      const fresh={
        order:row.order,orderType:row.orderType,date:row.date,sapDate:row.date,desc:row.desc,loc:row.loc,workCenter:row.workCenter,
        type:row.type,userStatus:row.userStatus,sap:row.sap,equipment:"NÃO IDENTIFICADO",group:"A definir",cell:0,
        owner:"",ownerId:null,ownerSnapshot:"",assignmentSource:"sap",programShift:"",importedAt:stamp,firstSeenAt:stamp,
        completedAt:isConfirmed(row.sap)?stamp:""
      };
      orders.push(fresh); map.set(row.order,fresh); created++;
    }
  }
  const afterConf=orders.filter(o=>isConfirmed(o.sap)).length;
  const newJson=JSON.stringify(orders);
  text=text.slice(0,block.start)+newJson+text.slice(block.end);
  const version=nowVersion();
  if(/const EMBEDDED_BASE_VERSION = "[^"]*";/.test(text)){
    text=text.replace(/const EMBEDDED_BASE_VERSION = "[^"]*";/,`const EMBEDDED_BASE_VERSION = "${version}";`);
  }
  const backupDir=path.join(path.dirname(indexPath),"backup_index_automatico");
  fs.mkdirSync(backupDir,{recursive:true});
  const safeStamp=version.replace(/^AUTO_SAP_/,"");
  const backup=path.join(backupDir,`index_programacao_operacional_${safeStamp}.html`);
  fs.copyFileSync(indexPath,backup);
  fs.writeFileSync(indexPath,"\uFEFF"+text,"utf8");

  console.log(`[INDEX-SAP] Relatório: ${rows.length} ordens únicas`);
  console.log(`[INDEX-SAP] Atualizadas: ${updated} | Novas: ${created}`);
  console.log(`[INDEX-SAP] CONF embutidas: ${beforeConf} -> ${afterConf} | Novas CONF: ${newConf}`);
  console.log(`[INDEX-SAP] Versão: ${version}`);
  console.log(`[INDEX-SAP] Backup: ${backup}`);
  console.log(`[INDEX-SAP] Index atualizado: ${indexPath}`);
}
try{main();}catch(e){fail(e && e.stack ? e.stack : e);}
