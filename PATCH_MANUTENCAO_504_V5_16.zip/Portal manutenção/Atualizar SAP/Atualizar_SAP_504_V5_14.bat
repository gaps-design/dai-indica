@echo off
setlocal EnableExtensions
title Atualizar SAP 504 V5.16 - Sem R
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo ERRO: Node.js nao foi encontrado neste VD.
  endlocal
  exit /b 2
)

if not exist "%~dp0executar_manutencao_sem_r.js" (
  echo ERRO: executar_manutencao_sem_r.js nao encontrado.
  endlocal
  exit /b 3
)

node "%~dp0executar_manutencao_sem_r.js"
set "RC=%ERRORLEVEL%"
endlocal & exit /b %RC%
