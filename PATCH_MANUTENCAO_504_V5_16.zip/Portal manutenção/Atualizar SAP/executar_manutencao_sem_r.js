"use strict";

const fs = require("fs");
const path = require("path");
const os = require("os");
const cp = require("child_process");

const SCRIPT_NAME = "Atualizar_SAP_504_V5_14.ps1";
const sourcePs1 = path.join(__dirname, SCRIPT_NAME);

function fail(msg) {
  console.error("[MANUTENCAO] ERRO:", msg);
  process.exit(1);
}

if (!fs.existsSync(sourcePs1)) {
  fail(`Script nao encontrado: ${sourcePs1}`);
}

let psCode;
try {
  psCode = fs.readFileSync(sourcePs1, "utf8").replace(/^\uFEFF/, "");
} catch (e) {
  fail(`Nao consegui ler o PS1: ${e.message}`);
}

// IMPORTANTE:
// Nao usamos -File apontando para a unidade N:, pois o PowerShell do VD
// pede confirmacao [N]/[R] para scripts de rede.
// Nao usamos -EncodedCommand, pois o script V5.14 e grande e ultrapassa
// o limite de tamanho da linha de comando do Windows (ENAMETOOLONG).
//
// Solucao: copiar o CONTEUDO do PS1 para um arquivo temporario LOCAL,
// com nome ASCII, e executar esse arquivo local com ExecutionPolicy Bypass.
let tempDir;
let localPs1;
try {
  tempDir = fs.mkdtempSync(path.join(os.tmpdir(), "portal504_manutencao_"));
  localPs1 = path.join(tempDir, "Atualizar_SAP_504_V5_14_LOCAL.ps1");
  // BOM UTF-8 para Windows PowerShell 5.1 preservar acentos do script.
  fs.writeFileSync(localPs1, "\uFEFF" + psCode, "utf8");
} catch (e) {
  fail(`Nao consegui criar a copia local temporaria do PS1: ${e.message}`);
}

function cleanup() {
  try {
    if (tempDir && fs.existsSync(tempDir)) {
      fs.rmSync(tempDir, { recursive: true, force: true });
    }
  } catch (_) {}
}

console.log("============================================================");
console.log(" MANUTENCAO 504 - EXECUCAO SEM R");
console.log(" Modo: copia local temporaria do PowerShell");
console.log(" Nao executa PS1 diretamente da unidade N:");
console.log(" Nao usa EncodedCommand (evita ENAMETOOLONG)");
console.log("============================================================");
console.log("Fonte:", sourcePs1);
console.log("Copia local:", localPs1);

const args = [
  "-NoLogo",
  "-NoProfile",
  "-NonInteractive",
  "-ExecutionPolicy", "Bypass",
  "-File", localPs1
];

const child = cp.spawn("powershell.exe", args, {
  cwd: __dirname,
  stdio: "inherit",
  windowsHide: false,
  shell: false,
  env: {
    ...process.env,
    PORTAL504_CENTRAL: "1",
    PORTAL504_MAINT_SEM_R: "1",
    PORTAL504_PS1_LOCAL_TEMP: "1"
  }
});

child.on("error", err => {
  cleanup();
  fail(`Nao consegui iniciar o PowerShell: ${err.message}`);
});

child.on("close", code => {
  cleanup();
  process.exit(Number.isInteger(code) ? code : 1);
});

process.on("SIGINT", () => {
  cleanup();
  process.exit(130);
});
process.on("SIGTERM", () => {
  cleanup();
  process.exit(143);
});
