@echo off
setlocal
chcp 65001 >nul
cls
title Teste Manutencao 504 - SEM Central
cd /d "N:\Packaging\Compartilhado\Retornável\Usuarios\Guilherme A\Lobby\Portal manutenção\Atualizar SAP"
if not exist "executar_manutencao_sem_r.js" (
  echo [ERRO] executar_manutencao_sem_r.js nao encontrado. Rode primeiro APLICAR_CORRECAO_MANUTENCAO.bat
  pause
  exit /b 1
)
node executar_manutencao_sem_r.js
set RC=%ERRORLEVEL%
echo.
echo Codigo de saida: %RC%
pause
exit /b %RC%
