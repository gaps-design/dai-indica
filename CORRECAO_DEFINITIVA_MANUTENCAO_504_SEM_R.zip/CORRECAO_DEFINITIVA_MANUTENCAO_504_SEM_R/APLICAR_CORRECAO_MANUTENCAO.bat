@echo off
setlocal EnableExtensions
chcp 65001 >nul
cls
title Correcao Manutencao 504 - SEM R

echo ============================================================
echo  CORRECAO DEFINITIVA - MANUTENCAO 504 SEM [N]/[R]
echo ============================================================
echo.

where node >nul 2>nul
if errorlevel 1 (
  echo [ERRO] Node.js nao foi encontrado neste VD.
  pause
  exit /b 1
)

REM Mata SOMENTE o processo que estiver escutando na porta local 5040.
REM Isso elimina o agente antigo que pode continuar carregado em memoria.
echo [1/4] Encerrando agente antigo da Central na porta 5040...
for /f "tokens=5" %%P in ('netstat -ano ^| findstr /R /C:":5040 .*LISTENING"') do (
  echo       Encerrando PID %%P...
  taskkill /PID %%P /F >nul 2>nul
)
timeout /t 2 /nobreak >nul

echo [2/4] Aplicando patch SEM sobrescrever TPO, UP, Seguranca ou Mal Cheia...
node "%~dp0arquivos\patch_central_manutencao.js"
if errorlevel 1 (
  echo.
  echo [ERRO] O patch nao foi aplicado.
  pause
  exit /b 1
)

echo.
echo [3/4] Verificando launcher da Manutencao...
if not exist "N:\Packaging\Compartilhado\Retornável\Usuarios\Guilherme A\Lobby\Portal manutenção\Atualizar SAP\executar_manutencao_sem_r.js" (
  echo [ERRO] Launcher nao foi instalado.
  pause
  exit /b 1
)

echo [4/4] Reiniciando o agente real da Central...
start "Central Atualizacoes 504" cmd /k "cd /d ""N:\Packaging\Compartilhado\Retornável\Usuarios\Guilherme A\Lobby\Portal Indicadores\_sistema\Central Atualizacoes"" && node central_504_agent.js"

timeout /t 3 /nobreak >nul

echo.
echo ============================================================
echo  CORRECAO APLICADA
echo ============================================================
echo Agora volte para a Central no Chrome e atualize a pagina com Ctrl+F5.
echo Depois clique em MANUTENCAO ^> ATUALIZAR.
echo.
echo Na janela da Central deve aparecer:
echo   [CENTRAL] Iniciando Manutencao
echo   MANUTENCAO 504 - EXECUCAO SEM R
echo   Modo: PowerShell em memoria / EncodedCommand
echo.
echo NAO deve aparecer Aviso de seguranca nem [N]/[R].
echo.
pause
endlocal
