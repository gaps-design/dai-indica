'use strict';

const fs = require('fs');
const path = require('path');

const BASE = String.raw`N:\Packaging\Compartilhado\Retornável\Usuarios\Guilherme A\Lobby`;
const CENTRAL_DIR = path.join(BASE, 'Portal Indicadores', '_sistema', 'Central Atualizacoes');
const CONFIG = path.join(CENTRAL_DIR, 'config_central_504.json');
const MAINT_DIR = path.join(BASE, 'Portal manutenção', 'Atualizar SAP');
const LAUNCHER_NAME = 'executar_manutencao_sem_r.js';
const SOURCE_LAUNCHER = path.join(__dirname, LAUNCHER_NAME);
const TARGET_LAUNCHER = path.join(MAINT_DIR, LAUNCHER_NAME);

function fail(msg) {
  console.error('[PATCH] ERRO:', msg);
  process.exit(1);
}

for (const p of [CENTRAL_DIR, CONFIG, MAINT_DIR, SOURCE_LAUNCHER]) {
  if (!fs.existsSync(p)) fail(`Não encontrado: ${p}`);
}

let cfg;
try {
  cfg = JSON.parse(fs.readFileSync(CONFIG, 'utf8').replace(/^\uFEFF/, ''));
} catch (e) {
  fail(`Config da Central inválido: ${e.message}`);
}

if (!cfg.automations || typeof cfg.automations !== 'object') {
  fail('config_central_504.json não possui automations.');
}

const old = cfg.automations.manutencao || {};
const stamp = new Date().toISOString().replace(/[-:.TZ]/g, '').slice(0, 14);
const backup = path.join(CENTRAL_DIR, `config_central_504.backup_${stamp}.json`);
fs.copyFileSync(CONFIG, backup);

// Copia o launcher para a pasta real da manutenção.
fs.copyFileSync(SOURCE_LAUNCHER, TARGET_LAUNCHER);

// Altera SOMENTE a automação de Manutenção. Mal Cheia, TPO, UP, Segurança e
// quaisquer automações adicionadas depois permanecem intactas.
cfg.automations.manutencao = {
  ...old,
  name: old.name || 'Manutenção',
  kind: 'node',
  cwd: MAINT_DIR,
  command: 'node',
  args: [LAUNCHER_NAME],
  watchFile: old.watchFile || path.join(BASE, 'Portal manutenção', 'Relatórios SAP', 'ordens_status.htm')
};
delete cfg.automations.manutencao.script;

fs.writeFileSync(CONFIG, JSON.stringify(cfg, null, 2), 'utf8');

const check = JSON.parse(fs.readFileSync(CONFIG, 'utf8'));
const m = check.automations && check.automations.manutencao;
if (!m || m.kind !== 'node' || m.command !== 'node' || !Array.isArray(m.args) || m.args[0] !== LAUNCHER_NAME) {
  fail('A validação após salvar falhou.');
}

const serialized = JSON.stringify(m);
if (/-File/i.test(serialized) || /powershell\.exe/i.test(serialized)) {
  fail('A configuração ainda contém execução direta do PowerShell.');
}

console.log('[PATCH] Backup criado:', backup);
console.log('[PATCH] Launcher instalado:', TARGET_LAUNCHER);
console.log('[PATCH] Manutenção configurada como NODE -> executar_manutencao_sem_r.js');
console.log('[PATCH] Nenhuma outra automação foi alterada.');
