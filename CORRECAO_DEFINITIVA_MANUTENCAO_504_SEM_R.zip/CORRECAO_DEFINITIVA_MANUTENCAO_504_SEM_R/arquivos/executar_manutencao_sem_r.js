'use strict';

const fs = require('fs');
const path = require('path');
const cp = require('child_process');

const SCRIPT_NAME = 'Atualizar_SAP_504_V5_14.ps1';
const scriptPath = path.join(__dirname, SCRIPT_NAME);

function fail(msg) {
  console.error('[MANUTENCAO] ERRO:', msg);
  process.exit(1);
}

if (!fs.existsSync(scriptPath)) {
  fail(`Script não encontrado: ${scriptPath}`);
}

let psCode;
try {
  psCode = fs.readFileSync(scriptPath, 'utf8').replace(/^\uFEFF/, '');
} catch (e) {
  fail(`Não consegui ler o PS1: ${e.message}`);
}

// Executa o CONTEÚDO do PS1 em memória. O arquivo da unidade N: é apenas lido
// pelo Node; ele NÃO é passado ao PowerShell via -File, evitando o aviso [N]/[R].
const safeDir = __dirname.replace(/'/g, "''");
const bootstrap = [
  "$ErrorActionPreference = 'Stop'",
  `Set-Location -LiteralPath '${safeDir}'`,
  psCode
].join('\r\n');

const encoded = Buffer.from(bootstrap, 'utf16le').toString('base64');
const args = [
  '-NoLogo',
  '-NoProfile',
  '-NonInteractive',
  '-ExecutionPolicy', 'Bypass',
  '-EncodedCommand', encoded
];

console.log('============================================================');
console.log(' MANUTENCAO 504 - EXECUCAO SEM R');
console.log(' Modo: PowerShell em memoria / EncodedCommand');
console.log(' Nao usa -File para o PS1 da unidade N:');
console.log('============================================================');

const result = cp.spawnSync('powershell.exe', args, {
  cwd: __dirname,
  stdio: 'inherit',
  windowsHide: false,
  env: { ...process.env, PORTAL504_CENTRAL: '1', PORTAL504_MAINT_SEM_R: '1' }
});

if (result.error) {
  fail(`Não consegui iniciar o PowerShell: ${result.error.message}`);
}

process.exit(Number.isInteger(result.status) ? result.status : 1);
