window.SITE_DATA={
  "current": [
    {
      "label": "Território",
      "value": "8,51 mi km²",
      "detail": "escala continental"
    },
    {
      "label": "População",
      "value": "~203 milhões",
      "detail": "grande mercado interno"
    },
    {
      "label": "PIB",
      "value": "economia de grande escala",
      "detail": "mas renda por habitante ainda intermediária"
    },
    {
      "label": "Desigualdade",
      "value": "ainda elevada",
      "detail": "renda e patrimônio concentrados"
    },
    {
      "label": "Matriz elétrica",
      "value": "majoritariamente renovável",
      "detail": "vantagem na transição energética"
    },
    {
      "label": "Amazônia",
      "value": "~59% do território",
      "detail": "ativo climático e geopolítico"
    },
    {
      "label": "Sistema político",
      "value": "República federativa",
      "detail": "presidencialismo + 3 Poderes"
    },
    {
      "label": "Constituição",
      "value": "1988",
      "detail": "base institucional atual"
    }
  ],
  "decades": [
    {
      "label": "1930s",
      "value": 4.6
    },
    {
      "label": "1940s",
      "value": 6.0
    },
    {
      "label": "1950s",
      "value": 7.4
    },
    {
      "label": "1960s",
      "value": 6.1
    },
    {
      "label": "1970s",
      "value": 8.6
    },
    {
      "label": "1980s",
      "value": 1.6
    },
    {
      "label": "1990s",
      "value": 2.4
    },
    {
      "label": "2000s",
      "value": 3.7
    },
    {
      "label": "2010s",
      "value": 1.4
    },
    {
      "label": "2020s*",
      "value": 2.6
    }
  ],
  "governments": [
    {
      "id": "vargas",
      "name": "Getúlio Vargas",
      "period": "1930–1945 / 1951–1954",
      "image": "assets/img/presidentes/vargas.jpg",
      "origin": "Revolução de 1930; trabalhismo e nacional-desenvolvimentismo",
      "regime": "Governo provisório, constitucional, Estado Novo e depois mandato eleito",
      "summary": "Um dos personagens decisivos da construção do Estado brasileiro moderno: indústria, legislação do trabalho, empresas estratégicas e forte centralização.",
      "born": "19/04/1882 · São Borja (RS)",
      "trajectory": "Político gaúcho que chegou ao poder após a Revolução de 1930. Governou de formas distintas, inclusive durante a ditadura do Estado Novo, e retornou pelo voto em 1951.",
      "context": "Crise de 1929, declínio da República Oligárquica, urbanização e necessidade de reorganização nacional.",
      "policies": [
        "Ministério do Trabalho e legislação social",
        "CLT em 1943",
        "CSN e industrialização de base",
        "Petrobras no segundo governo",
        "centralização administrativa"
      ],
      "growth": 6.2,
      "inflation": "Pressões variáveis; não comparável diretamente ao IPCA moderno",
      "inequality": "muito elevada",
      "positive": [
        "estruturação do Estado nacional",
        "industrialização de base",
        "direitos trabalhistas urbanos"
      ],
      "critical": [
        "ditadura do Estado Novo",
        "censura e perseguição política",
        "incorporação social desigual"
      ],
      "legacy": "Trabalhismo, intervenção estatal e visão desenvolvimentista continuaram influenciando governos posteriores.",
      "current": "Debates sobre papel do Estado, direitos do trabalho e política industrial ainda carregam marcas varguistas."
    },
    {
      "id": "jk",
      "name": "Juscelino Kubitschek",
      "period": "1956–1961",
      "image": "assets/img/presidentes/jk.jpg",
      "origin": "PSD; desenvolvimentismo democrático",
      "regime": "Democracia da Constituição de 1946",
      "summary": "O “50 anos em 5” acelerou indústria, energia, transportes e a construção de Brasília.",
      "born": "12/09/1902 · Diamantina (MG)",
      "trajectory": "Médico e político mineiro, foi prefeito de Belo Horizonte, governador de Minas e presidente.",
      "context": "Urbanização, industrialização por substituição de importações e otimismo do pós-guerra.",
      "policies": [
        "Plano de Metas",
        "Brasília",
        "indústria automobilística",
        "energia e rodovias",
        "abertura a capital estrangeiro"
      ],
      "growth": 7.4,
      "inflation": "alta",
      "inequality": "alta",
      "positive": [
        "aceleração industrial",
        "infraestrutura",
        "integração territorial"
      ],
      "critical": [
        "inflação crescente",
        "pressão externa",
        "crescimento muito dependente de investimento e financiamento"
      ],
      "legacy": "Símbolo do desenvolvimentismo e da capacidade de coordenar grandes projetos.",
      "current": "A discussão atual sobre infraestrutura e política industrial frequentemente revisita a experiência do Plano de Metas."
    },
    {
      "id": "janio",
      "name": "Jânio Quadros",
      "period": "1961",
      "image": "assets/img/presidentes/janio.jpg",
      "origin": "PTN; campanha personalista e moralizante",
      "regime": "Democracia de 1946",
      "summary": "Mandato curtíssimo, marcado por política externa independente e renúncia inesperada.",
      "born": "25/01/1917 · Campo Grande (MS)",
      "trajectory": "Professor e político de ascensão rápida em São Paulo. Eleito com forte discurso anticorrupção.",
      "context": "Tensões da Guerra Fria e cenário interno de forte polarização.",
      "policies": [
        "política externa independente",
        "medidas econômicas de ajuste",
        "agenda moralizante"
      ],
      "growth": 0.0,
      "inflation": "alta",
      "inequality": "alta",
      "positive": [
        "tentativa de autonomia externa"
      ],
      "critical": [
        "instabilidade",
        "renúncia após sete meses",
        "crise sucessória"
      ],
      "legacy": "A renúncia abriu a crise que levou ao parlamentarismo provisório e ao governo Goulart.",
      "current": "É exemplo de como personalismo e fragilidade de coalizão podem produzir instabilidade institucional."
    },
    {
      "id": "jango",
      "name": "João Goulart",
      "period": "1961–1964",
      "image": "assets/img/presidentes/jango.jpg",
      "origin": "PTB; trabalhismo e reformas de base",
      "regime": "Democracia sob crise; parlamentarismo e depois presidencialismo",
      "summary": "Defendeu reformas agrária, tributária, educacional e urbana em ambiente de polarização crescente.",
      "born": "01/03/1919 · São Borja (RS)",
      "trajectory": "Herdeiro político do trabalhismo varguista, foi ministro do Trabalho e vice-presidente antes de assumir após a renúncia de Jânio.",
      "context": "Guerra Fria, inflação, mobilização sindical e temor de radicalização de ambos os lados.",
      "policies": [
        "Reformas de Base",
        "política salarial",
        "nacionalismo econômico"
      ],
      "growth": 4.0,
      "inflation": "alta",
      "inequality": "alta",
      "positive": [
        "agenda de reformas estruturais",
        "mobilização social"
      ],
      "critical": [
        "crise fiscal e inflacionária",
        "coalizão fragmentada",
        "radicalização política"
      ],
      "legacy": "Seu governo terminou com o golpe de 1964.",
      "current": "Ajuda a entender por que reforma social, polarização e estabilidade institucional continuam temas centrais."
    },
    {
      "id": "geisel",
      "name": "Ernesto Geisel",
      "period": "1974–1979",
      "image": "assets/img/presidentes/geisel.jpg",
      "origin": "Alto comando militar; desenvolvimentismo autoritário",
      "regime": "Ditadura militar",
      "summary": "II PND, expansão energética e industrial com abertura política lenta e controlada.",
      "born": "03/08/1907 · Bento Gonçalves (RS)",
      "trajectory": "General do Exército e quarto presidente do ciclo militar.",
      "context": "Primeiro choque do petróleo, fim do milagre econômico e crescimento da dívida externa.",
      "policies": [
        "II PND",
        "programa nuclear",
        "indústria pesada",
        "expansão energética",
        "distensão política controlada"
      ],
      "growth": 6.7,
      "inflation": "alta e crescente",
      "inequality": "muito alta",
      "positive": [
        "diversificação industrial",
        "investimento energético"
      ],
      "critical": [
        "repressão e ausência de democracia",
        "endividamento externo",
        "concentração de renda"
      ],
      "legacy": "Infraestrutura e capacidade industrial cresceram, mas junto de dívida e trauma autoritário.",
      "current": "É essencial para separar crescimento econômico de qualidade institucional."
    },
    {
      "id": "sarney",
      "name": "José Sarney",
      "period": "1985–1990",
      "image": "assets/img/presidentes/sarney.jpg",
      "origin": "PMDB; transição negociada da ditadura",
      "regime": "Nova República",
      "summary": "Conduziu a transição democrática e a Constituição de 1988, mas não venceu a hiperinflação.",
      "born": "24/04/1930 · Pinheiro (MA)",
      "trajectory": "Político de longa carreira. Tornou-se presidente após a morte de Tancredo Neves.",
      "context": "Crise da dívida, inflação inercial, reconstrução institucional e forte demanda social.",
      "policies": [
        "Plano Cruzado",
        "Plano Bresser",
        "Plano Verão",
        "Constituição de 1988"
      ],
      "growth": 3.5,
      "inflation": "hiperinflação ao fim do mandato",
      "inequality": "alta",
      "positive": [
        "redemocratização",
        "Constituição de 1988"
      ],
      "critical": [
        "fracasso na estabilização",
        "desorganização fiscal e monetária"
      ],
      "legacy": "A nova ordem constitucional nasce neste período.",
      "current": "SUS, direitos sociais, pacto federativo e regras do orçamento atual têm raízes diretas em 1988."
    },
    {
      "id": "collor",
      "name": "Fernando Collor",
      "period": "1990–1992",
      "image": "assets/img/presidentes/collor.jpg",
      "origin": "PRN; liberalização e discurso antiestablishment",
      "regime": "Democracia",
      "summary": "Abertura comercial rápida, Plano Collor e impeachment.",
      "born": "12/08/1949 · Rio de Janeiro (RJ)",
      "trajectory": "Ex-governador de Alagoas, venceu a primeira eleição presidencial direta após a ditadura.",
      "context": "Hiperinflação, economia fechada e forte demanda por mudança.",
      "policies": [
        "Plano Collor e bloqueio de ativos",
        "abertura comercial",
        "privatizações iniciais"
      ],
      "growth": -1.3,
      "inflation": "muito alta",
      "inequality": "alta",
      "positive": [
        "abertura a competição internacional",
        "início de modernização em alguns setores"
      ],
      "critical": [
        "confisco de ativos",
        "recessão",
        "crise política e impeachment"
      ],
      "legacy": "A abertura econômica foi continuada, mas o trauma do confisco marcou uma geração.",
      "current": "Ajuda a entender por que estabilização e credibilidade institucional se tornaram tão importantes."
    },
    {
      "id": "itamar",
      "name": "Itamar Franco",
      "period": "1992–1994",
      "image": "assets/img/presidentes/itamar.jpg",
      "origin": "PMDB; governo de transição e coalizão",
      "regime": "Democracia",
      "summary": "Criou o ambiente político para o Plano Real, que encerrou a hiperinflação.",
      "born": "28/06/1930 · Salvador (BA)",
      "trajectory": "Vice de Collor; assumiu após impeachment e montou equipe econômica plural.",
      "context": "Crise de confiança e necessidade urgente de estabilização.",
      "policies": [
        "Plano Real",
        "URV",
        "reorganização da equipe econômica"
      ],
      "growth": 5.0,
      "inflation": "queda radical em 1994",
      "inequality": "alta",
      "positive": [
        "estabilização construída institucionalmente",
        "transição política pacífica"
      ],
      "critical": [
        "mandato curto e dependente de ampla coalizão"
      ],
      "legacy": "O Real reorganizou o sistema econômico e político.",
      "current": "A estabilidade monetária continua sendo uma das principais heranças do período."
    },
    {
      "id": "fhc",
      "name": "Fernando Henrique Cardoso",
      "period": "1995–2002",
      "image": "assets/img/presidentes/fhc.jpg",
      "origin": "PSDB; social-democracia com reformas pró-mercado",
      "regime": "Democracia",
      "summary": "Consolidou o Real, privatizações, regras fiscais e o tripé macroeconômico.",
      "born": "18/06/1931 · Rio de Janeiro (RJ)",
      "trajectory": "Sociólogo, senador e ministro da Fazenda durante a criação do Real.",
      "context": "Globalização, crises asiática/russa, câmbio valorizado e necessidade de consolidar estabilidade.",
      "policies": [
        "metas de inflação",
        "responsabilidade fiscal",
        "privatizações",
        "programas sociais precursores",
        "câmbio flutuante"
      ],
      "growth": 2.3,
      "inflation": "baixa em comparação à hiperinflação",
      "inequality": "começou a recuar",
      "positive": [
        "estabilidade monetária",
        "instituições fiscais/monetárias",
        "modernização regulatória"
      ],
      "critical": [
        "crescimento baixo",
        "juros elevados",
        "desemprego urbano em parte do período"
      ],
      "legacy": "Instituições macroeconômicas foram preservadas por governos posteriores.",
      "current": "Muitos debates fiscais e monetários de hoje partem desse arranjo institucional."
    },
    {
      "id": "lula",
      "name": "Luiz Inácio Lula da Silva",
      "period": "2003–2010 / 2023–",
      "image": "assets/img/presidentes/lula.jpg",
      "origin": "PT; esquerda democrática / centro-esquerda de coalizão",
      "regime": "Democracia",
      "summary": "Liderança sindical que chegou à Presidência; primeiros mandatos combinaram inclusão social, boom externo e expansão do mercado interno.",
      "born": "27/10/1945 · Garanhuns (PE)",
      "trajectory": "Migrou para São Paulo, foi metalúrgico e líder sindical no ABC, participou da fundação do PT e disputou várias eleições antes de vencer em 2002. Retornou ao Planalto em 2023.",
      "context": "2003–2010: boom de commodities e forte demanda chinesa. 2023–: pós-pandemia, juros altos, agenda climática, polarização e Congresso fragmentado.",
      "policies": [
        "Bolsa Família",
        "valorização do salário mínimo",
        "PAC",
        "expansão universitária e técnica",
        "Novo PAC",
        "Nova Indústria Brasil"
      ],
      "growth": 4.1,
      "inflation": "controlada nos dois primeiros mandatos; cenário distinto no terceiro",
      "inequality": "queda relevante nos anos 2000",
      "positive": [
        "redução de pobreza",
        "emprego formal",
        "expansão educacional",
        "diplomacia e mercado interno"
      ],
      "critical": [
        "dependência de ciclo externo",
        "baixa produtividade estrutural",
        "escândalos de corrupção envolvendo coalizão e partido",
        "desafio fiscal no terceiro mandato"
      ],
      "legacy": "Políticas de renda e inclusão ganharam centralidade na agenda brasileira.",
      "current": "O terceiro mandato disputa como conciliar inclusão, investimento, reindustrialização e sustentabilidade fiscal."
    },
    {
      "id": "dilma",
      "name": "Dilma Rousseff",
      "period": "2011–2016",
      "image": "assets/img/presidentes/dilma.jpg",
      "origin": "PT; centro-esquerda / desenvolvimentismo",
      "regime": "Democracia; segundo mandato interrompido por impeachment",
      "summary": "Começou com continuidade social, adotou a “nova matriz econômica”, enfrentou forte recessão e impeachment.",
      "born": "14/12/1947 · Belo Horizonte (MG)",
      "trajectory": "Economista, ex-ministra de Minas e Energia e chefe da Casa Civil; primeira mulher eleita presidente do Brasil.",
      "context": "Fim do boom de commodities, gargalos internos, protestos de 2013 e crise política crescente.",
      "policies": [
        "desonerações",
        "crédito subsidiado",
        "controle de preços administrados",
        "PAC 2",
        "programas sociais"
      ],
      "growth": 1.0,
      "inflation": "pressionada antes da recessão",
      "inequality": "piora na crise",
      "positive": [
        "continuidade de políticas sociais",
        "investimentos em energia e infraestrutura"
      ],
      "critical": [
        "deterioração fiscal",
        "recessão 2015–2016",
        "intervenções que reduziram previsibilidade"
      ],
      "legacy": "A recessão mudou profundamente o debate fiscal e político.",
      "current": "O período é um dos principais antecedentes da polarização e das regras fiscais posteriores."
    },
    {
      "id": "temer",
      "name": "Michel Temer",
      "period": "2016–2018",
      "image": "assets/img/presidentes/temer.jpg",
      "origin": "MDB; centro / agenda liberal-reformista",
      "regime": "Democracia após impeachment",
      "summary": "Agenda de ajuste: teto de gastos, reforma trabalhista e tentativa de normalização pós-recessão.",
      "born": "23/09/1940 · Tietê (SP)",
      "trajectory": "Constitucionalista, deputado e vice-presidente de Dilma. Assumiu após impeachment.",
      "context": "Saída de recessão profunda, desemprego elevado e crise de confiança.",
      "policies": [
        "teto de gastos",
        "reforma trabalhista",
        "concessões e agenda microeconômica"
      ],
      "growth": 1.2,
      "inflation": "em queda",
      "inequality": "alta",
      "positive": [
        "redução da inflação",
        "reformas institucionais"
      ],
      "critical": [
        "crescimento baixo",
        "baixa popularidade",
        "recuperação social lenta"
      ],
      "legacy": "Regras fiscais e trabalhistas passaram a organizar a agenda seguinte.",
      "current": "O debate sobre rigidez do gasto e sustentabilidade fiscal segue conectado a esse período."
    },
    {
      "id": "bolsonaro",
      "name": "Jair Bolsonaro",
      "period": "2019–2022",
      "image": "assets/img/presidentes/bolsonaro.jpg",
      "origin": "PSL/PL; direita conservadora com agenda econômica liberal",
      "regime": "Democracia sob forte tensão institucional",
      "summary": "Mandato marcado por reforma da Previdência, pandemia, auxílio emergencial e intensa polarização.",
      "born": "21/03/1955 · Glicério (SP)",
      "trajectory": "Capitão reformado e deputado federal por vários mandatos; venceu em 2018 com discurso antissistema e conservador.",
      "context": "Pandemia de COVID-19, choque de cadeias globais, inflação internacional e conflitos entre Poderes.",
      "policies": [
        "reforma da Previdência",
        "autonomia do Banco Central",
        "auxílio emergencial",
        "marco do saneamento",
        "agenda de privatizações/concessões"
      ],
      "growth": 1.5,
      "inflation": "baixa no início, alta no pós-pandemia",
      "inequality": "oscilou e piorou na pandemia",
      "positive": [
        "reforma previdenciária",
        "digitalização de serviços",
        "auxílio emergencial com forte alcance"
      ],
      "critical": [
        "gestão da pandemia muito contestada",
        "conflitos institucionais",
        "pressão ambiental",
        "alta polarização"
      ],
      "legacy": "Fortaleceu uma direita de massas e redefiniu o sistema partidário.",
      "current": "A polarização Lula–Bolsonaro continua estruturando parte central da política nacional."
    }
  ],
  "stories": [
    {
      "id": "lula",
      "kind": "person",
      "title": "Lula",
      "subtitle": "Do ABC ao terceiro mandato",
      "image": "assets/img/presidentes/lula.jpg",
      "target": "government",
      "targetId": "lula",
      "summary": "Nascimento, sindicalismo, PT, governos, políticas sociais, debates econômicos e legado."
    },
    {
      "id": "bolsonaro",
      "kind": "person",
      "title": "Jair Bolsonaro",
      "subtitle": "Ascensão da direita de massas",
      "image": "assets/img/presidentes/bolsonaro.jpg",
      "target": "government",
      "targetId": "bolsonaro",
      "summary": "Trajetória parlamentar, eleição de 2018, pandemia, reformas, conflitos e legado político."
    },
    {
      "id": "vargas",
      "kind": "person",
      "title": "Getúlio Vargas",
      "subtitle": "O Estado brasileiro muda de forma",
      "image": "assets/img/presidentes/vargas.jpg",
      "target": "government",
      "targetId": "vargas",
      "summary": "Revolução de 1930, Estado Novo, trabalhismo, indústria e contradições autoritárias."
    },
    {
      "id": "ditadura",
      "kind": "event",
      "title": "Ditadura Militar",
      "subtitle": "1964–1985",
      "image": "assets/img/eventos/ditadura-tanques-1968.jpg",
      "summary": "Golpe, repressão, AI-5, milagre econômico, endividamento e abertura política.",
      "born": "31/03–01/04/1964 · ruptura institucional",
      "trajectory": "O golpe derrubou João Goulart e inaugurou 21 anos de regime militar. Partidos foram restringidos, eleições presidenciais deixaram de ser diretas e a oposição sofreu censura, prisão, tortura e exílio.",
      "context": "Guerra Fria, polarização interna, conflito distributivo e temor de radicalização.",
      "policies": [
        "PAEG",
        "milagre econômico",
        "I e II PND",
        "expansão de infraestrutura",
        "abertura lenta no final"
      ],
      "positive": [
        "infraestrutura e industrialização em segmentos",
        "crescimento muito alto em parte do período"
      ],
      "critical": [
        "ditadura e violações de direitos humanos",
        "censura e tortura",
        "concentração de renda",
        "dívida e inflação no fim"
      ],
      "legacy": "Infraestrutura, indústria e dívida coexistem com trauma institucional e luta por redemocratização.",
      "current": "A defesa da democracia e a memória das violações continuam centrais no debate público."
    },
    {
      "id": "const88",
      "kind": "event",
      "title": "Constituição de 1988",
      "subtitle": "A “Constituição Cidadã”",
      "image": "assets/img/eventos/constituicao-1988.jpg",
      "summary": "A base da democracia atual, dos direitos sociais e do pacto federativo.",
      "born": "05/10/1988 · Brasília",
      "trajectory": "Resultado de uma Assembleia Nacional Constituinte após a ditadura. Ulysses Guimarães tornou-se símbolo da promulgação.",
      "context": "Redemocratização e pressão por ampliação de direitos.",
      "policies": [
        "SUS e seguridade",
        "direitos sociais",
        "fortalecimento do Ministério Público",
        "federalismo",
        "eleições e garantias civis"
      ],
      "positive": [
        "ampla proteção de direitos",
        "institucionalização democrática"
      ],
      "critical": [
        "complexidade fiscal e federativa",
        "muitas obrigações com baixa flexibilidade orçamentária"
      ],
      "legacy": "É a arquitetura jurídica do Brasil contemporâneo.",
      "current": "Saúde, assistência, orçamento, Justiça e relações entre União/estados/municípios passam por ela."
    },
    {
      "id": "diretas",
      "kind": "event",
      "title": "Diretas Já",
      "subtitle": "1983–1984",
      "image": "assets/img/eventos/diretas-ja-1984.jpg",
      "summary": "Mobilização popular por eleições diretas e símbolo da redemocratização.",
      "born": "1983–1984 · mobilização nacional",
      "trajectory": "Grandes comícios reuniram diferentes partidos, movimentos sociais, artistas e cidadãos. A emenda das diretas não passou, mas a campanha acelerou a transição política.",
      "context": "Esgotamento do regime militar, crise econômica e demanda por participação.",
      "policies": [
        "eleições diretas",
        "mobilização cívica",
        "coalizões democráticas"
      ],
      "positive": [
        "fortalecimento da sociedade civil",
        "ampliação da pressão pela democracia"
      ],
      "critical": [
        "a eleição de 1985 ainda foi indireta"
      ],
      "legacy": "Construiu uma cultura pública de mobilização democrática.",
      "current": "É referência frequente quando se discute participação e defesa das instituições."
    },
    {
      "id": "jk-brasilia",
      "kind": "event",
      "title": "Brasília e Plano de Metas",
      "subtitle": "1956–1961",
      "image": "assets/img/eventos/brasilia-jk-1960.jpg",
      "summary": "A construção da nova capital condensou a ideia de acelerar integração e modernização.",
      "born": "21/04/1960 · inauguração de Brasília",
      "trajectory": "Brasília fazia parte da estratégia de interiorização e integração. O governo JK impulsionou energia, transportes e indústria.",
      "context": "Desenvolvimentismo e urbanização rápida.",
      "policies": [
        "Plano de Metas",
        "Brasília",
        "rodovias",
        "energia",
        "indústria automotiva"
      ],
      "positive": [
        "integração territorial",
        "aceleração industrial"
      ],
      "critical": [
        "custos fiscais",
        "inflação",
        "dependência de capital externo"
      ],
      "legacy": "Brasília mudou a geografia do poder e simbolizou o desenvolvimentismo.",
      "current": "A infraestrutura continua sendo uma das maiores agendas de desenvolvimento do país."
    },
    {
      "id": "plano-real",
      "kind": "event",
      "title": "Plano Real",
      "subtitle": "1994",
      "image": "assets/img/presidentes/itamar.jpg",
      "summary": "A estabilização que encerrou a hiperinflação e reorganizou o debate econômico.",
      "born": "1994 · URV e Real",
      "trajectory": "Construído no governo Itamar com Fernando Henrique na Fazenda, combinou unidade de conta, ajuste e uma nova moeda.",
      "context": "Décadas de inflação alta e fracasso de congelamentos anteriores.",
      "policies": [
        "URV",
        "Real",
        "reformas fiscais",
        "mudança do regime monetário"
      ],
      "positive": [
        "fim da hiperinflação",
        "previsibilidade para salários e preços"
      ],
      "critical": [
        "juros elevados e câmbio valorizado em parte do ciclo"
      ],
      "legacy": "Moeda estável tornou-se um ativo político e social.",
      "current": "Toda discussão sobre inflação e juros parte da experiência traumática anterior ao Real."
    }
  ],
  "timeline": [
    {
      "year": "1500–1822",
      "era": "Formação",
      "title": "Colonização e economia escravista",
      "summary": "Exportação, grande propriedade e escravidão formaram a base econômica colonial.",
      "legacy": "Concentração patrimonial, desigualdade racial e integração territorial limitada.",
      "detail": "Durante mais de três séculos, a economia colonial se organizou em ciclos exportadores — açúcar, mineração e outras atividades — apoiados em trabalho escravizado e propriedade concentrada. A administração portuguesa priorizava controle e extração. Essa estrutura ajuda a explicar a longa persistência de desigualdades regionais e raciais.",
      "image": "assets/img/eventos/mapa-colonia.jpg",
      "story": "amazonia"
    },
    {
      "year": "1822–1889",
      "era": "Império",
      "title": "Independência, café e construção do Estado nacional",
      "summary": "O país se torna independente, preserva unidade territorial e mantém a escravidão por quase todo o Império.",
      "legacy": "Estado centralizado, economia cafeeira e exclusão social profunda.",
      "detail": "A Independência não desfez a estrutura agrária. O café ganha força, o Estado se organiza e a unidade territorial se consolida. A abolição vem apenas em 1888, sem grande política de integração econômica para a população liberta.",
      "image": "assets/img/eventos/constituicao-1988.jpg"
    },
    {
      "year": "1889–1930",
      "era": "Primeira República",
      "title": "República oligárquica e economia do café",
      "summary": "Federalismo forte, poder regional e participação eleitoral muito restrita.",
      "legacy": "Estado social frágil e grande dependência de produtos primários.",
      "detail": "A chamada República Velha foi marcada por domínio de oligarquias, voto limitado e enorme peso do café. A industrialização existia, mas ainda não era o centro do modelo nacional. A crise de 1929 abalou essa ordem.",
      "image": "assets/img/eventos/proclamacao-republica.jpg"
    },
    {
      "year": "1930–1945",
      "era": "Era Vargas",
      "title": "Vargas, industrialização e Estado Novo",
      "summary": "O governo federal ganha capacidade, a indústria avança e o trabalho passa a ser regulado nacionalmente.",
      "legacy": "CLT, burocracia nacional, empresas estratégicas e cultura desenvolvimentista.",
      "detail": "A Revolução de 1930 rompeu o arranjo oligárquico. Vargas centralizou o poder e construiu instituições modernas, mas de 1937 a 1945 governou como ditador no Estado Novo. O período mistura modernização econômica e autoritarismo.",
      "image": "assets/img/presidentes/vargas.jpg",
      "government": "vargas"
    },
    {
      "year": "1946–1964",
      "era": "Democracia 1946",
      "title": "Democracia, JK, Brasília e crise política",
      "summary": "Um ciclo democrático de forte urbanização e industrialização termina em grande polarização.",
      "legacy": "Indústria mais complexa, Brasília e debates sobre reformas estruturais.",
      "detail": "Dutra, Vargas eleito, Café Filho, JK, Jânio e Jango compõem um período plural. JK acelera infraestrutura e indústria; Jânio renuncia; Jango defende Reformas de Base. A crise termina no golpe de 1964.",
      "image": "assets/img/eventos/brasilia-jk-1960.jpg",
      "government": "jk"
    },
    {
      "year": "1964–1985",
      "era": "Ditadura",
      "title": "Regime militar: repressão, milagre e crise",
      "summary": "Crescimento forte em parte do período sob ausência de democracia, seguido de dívida, inflação e abertura.",
      "legacy": "Infraestrutura, indústria, dívida e trauma autoritário.",
      "detail": "O regime restringiu direitos, censurou e perseguiu opositores. Ao mesmo tempo, conduziu programas de industrialização e infraestrutura. O “milagre” não durou: os choques do petróleo e a dívida externa ajudaram a produzir a crise dos anos 1980.",
      "image": "assets/img/eventos/ditadura-tanques-1968.jpg",
      "story": "ditadura"
    },
    {
      "year": "1983–1988",
      "era": "Redemocratização",
      "title": "Diretas Já e Constituição Cidadã",
      "summary": "A mobilização popular e a Constituinte redesenham a ordem institucional.",
      "legacy": "Democracia, direitos sociais, SUS e novo pacto federativo.",
      "detail": "A campanha Diretas Já não conseguiu eleição direta imediata, mas acelerou a transição. A Constituição de 1988 consolidou a democracia e ampliou direitos, criando parte relevante do Estado social contemporâneo.",
      "image": "assets/img/eventos/diretas-ja-1984.jpg",
      "story": "diretas"
    },
    {
      "year": "1985–1994",
      "era": "Nova República",
      "title": "Democracia com hiperinflação",
      "summary": "Sarney, Collor e Itamar governam em ambiente de inflação extrema e tentativas frustradas de estabilização.",
      "legacy": "A estabilização se torna prioridade absoluta.",
      "detail": "Planos Cruzado, Bresser, Verão e Collor fracassaram em estabilizar preços de forma duradoura. O governo Itamar cria a equipe que formula o Plano Real.",
      "image": "assets/img/presidentes/sarney.jpg",
      "government": "sarney"
    },
    {
      "year": "1994–2002",
      "era": "Real e reformas",
      "title": "Plano Real e consolidação da estabilidade",
      "summary": "A hiperinflação termina, instituições fiscais e monetárias ganham novo desenho e a economia se abre mais.",
      "legacy": "Moeda estável, metas de inflação, responsabilidade fiscal e regulação.",
      "detail": "O Plano Real foi iniciado em Itamar e consolidado nos governos FHC. A estabilidade veio com custos, como juros altos e crises externas, mas mudou profundamente a relação do brasileiro com preços e salários.",
      "image": "assets/img/presidentes/fhc.jpg",
      "government": "fhc"
    },
    {
      "year": "2003–2010",
      "era": "Anos Lula",
      "title": "Inclusão social, commodities e mercado interno",
      "summary": "Pobreza e desigualdade caem, emprego e renda crescem e o país aproveita um ciclo externo favorável.",
      "legacy": "Políticas de renda mais centrais, expansão universitária e novo protagonismo internacional.",
      "detail": "Os dois primeiros governos Lula mantiveram parte importante do regime macroeconômico anterior e combinaram isso com políticas sociais, salário mínimo e expansão do crédito. O boom de commodities ajudou muito.",
      "image": "assets/img/presidentes/lula.jpg",
      "government": "lula"
    },
    {
      "year": "2011–2016",
      "era": "Dilma e recessão",
      "title": "Desaceleração, nova matriz e crise profunda",
      "summary": "A tentativa de reestimular a economia perde eficácia e o país entra em forte recessão e crise política.",
      "legacy": "Restrição fiscal, desemprego e nova polarização.",
      "detail": "O primeiro mandato desacelera e o segundo começa com ajuste. A recessão de 2015–2016 e o impeachment mudam a agenda política e econômica.",
      "image": "assets/img/presidentes/dilma.jpg",
      "government": "dilma"
    },
    {
      "year": "2016–2018",
      "era": "Temer",
      "title": "Agenda de reformas após a recessão",
      "summary": "Teto de gastos, reforma trabalhista e tentativa de reequilíbrio.",
      "legacy": "Novo eixo fiscal e trabalhista.",
      "detail": "O governo buscou recuperar confiança e conter a expansão do gasto, mas a retomada econômica permaneceu lenta.",
      "image": "assets/img/presidentes/temer.jpg",
      "government": "temer"
    },
    {
      "year": "2019–2022",
      "era": "Bolsonaro",
      "title": "Direita no poder, pandemia e polarização",
      "summary": "Reformas convivem com o choque da pandemia e forte conflito institucional.",
      "legacy": "Direita de massas, autonomia do BC e polarização persistente.",
      "detail": "O mandato aprovou a reforma previdenciária e a autonomia do Banco Central, mas foi dominado pela pandemia e por tensão constante com outras instituições.",
      "image": "assets/img/presidentes/bolsonaro.jpg",
      "government": "bolsonaro"
    },
    {
      "year": "2023–2026",
      "era": "Brasil atual",
      "title": "Lula III, reconstrução e nova agenda industrial",
      "summary": "O governo combina política social, investimento, agenda ambiental e tentativa de nova política industrial com desafio fiscal.",
      "legacy": "Ainda em formação.",
      "detail": "O terceiro mandato ocorre sob juros altos, Congresso fragmentado e pressão por crescimento. Novo PAC, Nova Indústria Brasil e reforma tributária são parte da agenda.",
      "image": "assets/img/presidentes/lula.jpg",
      "government": "lula"
    }
  ],
  "plans": [
    {
      "name": "Plano SALTE",
      "years": "1949–1954",
      "type": "Infraestrutura",
      "summary": "Saúde, alimentação, transporte e energia como primeiros eixos de planejamento nacional.",
      "result": "Execução parcial; antecedente do planejamento desenvolvimentista.",
      "detail": "Importante por introduzir a ideia de planejamento federal coordenado.",
      "image": "assets/img/presidentes/vargas.jpg"
    },
    {
      "name": "Plano de Metas",
      "years": "1956–1961",
      "type": "Desenvolvimento",
      "summary": "“50 anos em 5”: energia, transportes, indústria de base, alimentação e educação, com Brasília como meta-síntese.",
      "result": "Forte crescimento e industrialização, com pressão inflacionária e externa.",
      "detail": "É um dos melhores estudos de caso sobre ganhos e custos de acelerar o investimento.",
      "image": "assets/img/eventos/brasilia-jk-1960.jpg"
    },
    {
      "name": "PAEG",
      "years": "1964–1967",
      "type": "Estabilização e reformas",
      "summary": "Reformas financeiras e fiscais no início do regime militar.",
      "result": "Criou bases para retomada do crescimento, dentro de um regime autoritário.",
      "detail": "Mostra como reforma econômica e qualidade democrática são dimensões diferentes.",
      "image": "assets/img/presidentes/geisel.jpg"
    },
    {
      "name": "II PND",
      "years": "1975–1979",
      "type": "Indústria e energia",
      "summary": "Indústria pesada, energia, petroquímica e bens de capital.",
      "result": "Diversificou a indústria, mas aumentou a exposição à dívida externa.",
      "detail": "Resposta ao choque do petróleo e tentativa de reduzir dependências estratégicas.",
      "image": "assets/img/presidentes/geisel.jpg"
    },
    {
      "name": "Plano Cruzado",
      "years": "1986",
      "type": "Estabilização",
      "summary": "Congelamento de preços e nova moeda para combater inflação inercial.",
      "result": "Sucesso inicial e posterior fracasso.",
      "detail": "Ajuda a entender a dificuldade de derrotar a inflação sem corrigir fundamentos.",
      "image": "assets/img/presidentes/sarney.jpg"
    },
    {
      "name": "Plano Collor",
      "years": "1990",
      "type": "Estabilização e abertura",
      "summary": "Bloqueio de ativos financeiros e liberalização comercial.",
      "result": "Trauma social e recessão; inflação retornou.",
      "detail": "Um dos episódios econômicos mais controversos da Nova República.",
      "image": "assets/img/presidentes/collor.jpg"
    },
    {
      "name": "Plano Real",
      "years": "1994",
      "type": "Estabilização",
      "summary": "URV, nova moeda e reorganização macroeconômica.",
      "result": "Encerrou a hiperinflação e mudou o sistema político-econômico.",
      "detail": "Um processo institucional, não apenas a troca de uma moeda.",
      "image": "assets/img/presidentes/itamar.jpg"
    },
    {
      "name": "PAC",
      "years": "2007–2014",
      "type": "Infraestrutura",
      "summary": "Carteira ampla de energia, logística, habitação e saneamento.",
      "result": "Entregas heterogêneas; avanços e atrasos.",
      "detail": "Bom exemplo de que investimento anunciado, contratado e entregue são coisas diferentes.",
      "image": "assets/img/presidentes/lula.jpg"
    },
    {
      "name": "Nova Matriz Econômica",
      "years": "2011–2014",
      "type": "Macroeconomia",
      "summary": "Crédito subsidiado, desonerações e intervenção em preços para tentar elevar investimento.",
      "result": "Perdeu eficácia e contribuiu para desequilíbrios.",
      "detail": "Tema central no debate sobre a recessão posterior.",
      "image": "assets/img/presidentes/dilma.jpg"
    },
    {
      "name": "Teto de Gastos",
      "years": "2016–2022",
      "type": "Regra fiscal",
      "summary": "Limitou crescimento real das despesas federais por regra constitucional.",
      "result": "Mudou o debate fiscal, mas sofreu exceções e críticas por rigidez.",
      "detail": "Foi substituído pelo novo arcabouço fiscal.",
      "image": "assets/img/presidentes/temer.jpg"
    },
    {
      "name": "Novo PAC",
      "years": "2023–",
      "type": "Infraestrutura",
      "summary": "Nova carteira de investimentos públicos, privados e concessões.",
      "result": "Em execução.",
      "detail": "Resultados dependem de projeto, execução, financiamento, licenciamento e capacidade de gestão.",
      "image": "assets/img/presidentes/lula.jpg"
    },
    {
      "name": "Nova Indústria Brasil",
      "years": "2024–",
      "type": "Política industrial",
      "summary": "Missões industriais ligadas a saúde, defesa, agro, digitalização e transição verde.",
      "result": "Em implementação.",
      "detail": "Deve ser avaliada por produtividade, inovação, competitividade e retorno, não só volume de crédito.",
      "image": "assets/img/presidentes/lula.jpg"
    }
  ],
  "glossary": [
    {
      "term": "IBGE",
      "definition": "Instituto Brasileiro de Geografia e Estatística. É a principal instituição pública de estatísticas do país.",
      "use": "Censo, PNAD, PIB, inflação, população, emprego e mapas."
    },
    {
      "term": "PIB",
      "definition": "Produto Interno Bruto: valor dos bens e serviços finais produzidos no país em um período.",
      "use": "Mede tamanho e ritmo da economia. Não mede sozinho distribuição, saúde, segurança ou felicidade."
    },
    {
      "term": "PIB per capita",
      "definition": "PIB dividido pela população.",
      "use": "Aproxima a renda média produzida por pessoa e ajuda a comparar países, mas esconde desigualdade."
    },
    {
      "term": "PIB real",
      "definition": "PIB descontado do efeito da inflação.",
      "use": "É o que você usa para dizer se a economia realmente cresceu em volume."
    },
    {
      "term": "IPCA",
      "definition": "Índice Nacional de Preços ao Consumidor Amplo.",
      "use": "É a referência oficial para inflação ao consumidor no Brasil."
    },
    {
      "term": "Gini",
      "definition": "Índice de concentração de renda. Quanto mais próximo de 1, maior a desigualdade; quanto mais perto de 0, mais igualitária a distribuição.",
      "use": "Permite acompanhar desigualdade ao longo do tempo."
    },
    {
      "term": "WID",
      "definition": "World Inequality Database. Base internacional de distribuição de renda e patrimônio.",
      "use": "É especialmente útil para observar o 1%, 0,1% e outros grupos do topo."
    },
    {
      "term": "Ipea",
      "definition": "Instituto de Pesquisa Econômica Aplicada.",
      "use": "Produz estudos de políticas públicas, desenvolvimento e séries históricas."
    },
    {
      "term": "BCB",
      "definition": "Banco Central do Brasil.",
      "use": "Opera política monetária, supervisiona sistema financeiro e publica dados de juros, crédito e moeda."
    },
    {
      "term": "Selic",
      "definition": "Taxa básica de juros da economia brasileira.",
      "use": "Influência crédito, inflação, câmbio, dívida pública e investimento."
    },
    {
      "term": "PPC",
      "definition": "Paridade de Poder de Compra.",
      "use": "Ajusta diferenças de custo de vida para comparar o poder de compra entre países."
    },
    {
      "term": "Carga tributária",
      "definition": "Soma de tributos arrecadados em relação ao PIB.",
      "use": "Mede quanto o Estado arrecada, não se o dinheiro foi bem gasto."
    },
    {
      "term": "Déficit primário",
      "definition": "Quando receitas não financeiras ficam abaixo das despesas não financeiras.",
      "use": "Ajuda a avaliar a dinâmica fiscal sem misturar juros da dívida."
    },
    {
      "term": "Dívida/PIB",
      "definition": "Dívida pública comparada ao tamanho da economia.",
      "use": "É um indicador de sustentabilidade fiscal, mas precisa ser lido junto de juros, moeda, prazo e crescimento."
    },
    {
      "term": "Produtividade",
      "definition": "Quanto se produz por trabalhador, hora ou unidade de capital.",
      "use": "No longo prazo, é um dos motores mais importantes do aumento sustentado de renda."
    },
    {
      "term": "Commodities",
      "definition": "Produtos básicos negociados globalmente, como minério, petróleo, soja e café.",
      "use": "O Brasil exporta muitas commodities; preços internacionais podem influenciar crescimento, câmbio e arrecadação."
    },
    {
      "term": "Esquerda",
      "definition": "Família política que tende a enfatizar igualdade social, proteção do trabalho e maior ação pública na redução de desigualdades.",
      "use": "É um espectro amplo; não existe uma única esquerda."
    },
    {
      "term": "Direita",
      "definition": "Família política que tende a enfatizar propriedade, ordem, mercado e/ou valores conservadores, variando muito entre correntes.",
      "use": "Também é um espectro amplo; liberalismo econômico e conservadorismo social podem se combinar de modos diferentes."
    },
    {
      "term": "Fascismo",
      "definition": "Ideologia ultranacionalista e autoritária, historicamente associada à mobilização de massas, culto ao líder, repressão da oposição e rejeição do pluralismo democrático.",
      "use": "O termo deve ser usado com critérios históricos, e não apenas como xingamento político."
    },
    {
      "term": "Autoritarismo",
      "definition": "Forma de poder que restringe competição política, liberdades civis ou mecanismos de responsabilização.",
      "use": "Ajuda a diferenciar democracia, regimes híbridos e ditaduras."
    }
  ],
  "countries": [
    {
      "name": "Brasil",
      "area": 8.51,
      "pop": 203,
      "density": 24,
      "gdpPc": 11300,
      "system": "República federativa presidencialista",
      "age": "Independência 1822 · República 1889",
      "note": "Potência territorial e ambiental, renda média e alta desigualdade."
    },
    {
      "name": "Estados Unidos",
      "area": 9.83,
      "pop": 341,
      "density": 35,
      "gdpPc": 81600,
      "system": "República federal presidencialista",
      "age": "Independência 1776 · Constituição 1787",
      "note": "Mercado continental, liderança tecnológica e sistema financeiro profundo."
    },
    {
      "name": "China",
      "area": 9.6,
      "pop": 1410,
      "density": 147,
      "gdpPc": 12600,
      "system": "Estado socialista de partido único",
      "age": "República Popular desde 1949",
      "note": "Escala populacional e industrial extraordinária."
    },
    {
      "name": "Rússia",
      "area": 17.1,
      "pop": 144,
      "density": 8,
      "gdpPc": 15100,
      "system": "Federação semipresidencialista com forte concentração de poder",
      "age": "Federação Russa desde 1991",
      "note": "Maior território do mundo, energia e forte peso geopolítico."
    },
    {
      "name": "Canadá",
      "area": 9.98,
      "pop": 41,
      "density": 4,
      "gdpPc": 54000,
      "system": "Monarquia parlamentar federal",
      "age": "Confederação desde 1867",
      "note": "Território enorme e baixa densidade convivem com renda alta."
    },
    {
      "name": "Alemanha",
      "area": 0.36,
      "pop": 84,
      "density": 233,
      "gdpPc": 54000,
      "system": "República federal parlamentar",
      "age": "Unificação 1871 · República atual desde 1949",
      "note": "Indústria sofisticada, formação técnica e alta produtividade."
    },
    {
      "name": "França",
      "area": 0.55,
      "pop": 68,
      "density": 123,
      "gdpPc": 47000,
      "system": "República semipresidencialista",
      "age": "República contemporânea desde 1958",
      "note": "Estado social forte, alta produtividade e integração europeia."
    },
    {
      "name": "Japão",
      "area": 0.38,
      "pop": 124,
      "density": 328,
      "gdpPc": 34000,
      "system": "Monarquia parlamentar",
      "age": "Estado moderno consolidado no século XIX",
      "note": "Poucos recursos naturais, alta densidade, tecnologia e infraestrutura."
    },
    {
      "name": "Índia",
      "area": 3.29,
      "pop": 1430,
      "density": 435,
      "gdpPc": 2700,
      "system": "República federal parlamentar",
      "age": "Independência 1947 · República 1950",
      "note": "Grande escala humana, crescimento rápido e renda per capita ainda baixa."
    }
  ],
  "countryHotspots": {
    "Brasil": [
      35,
      60
    ],
    "Estados Unidos": [
      21,
      33
    ],
    "China": [
      72,
      42
    ],
    "Rússia": [
      66,
      24
    ],
    "Canadá": [
      22,
      22
    ],
    "Alemanha": [
      51,
      34
    ],
    "França": [
      49,
      37
    ],
    "Japão": [
      83,
      43
    ],
    "Índia": [
      67,
      54
    ]
  },
  "resources": [
    {
      "title": "Agricultura tropical e alimentos",
      "image": "assets/img/hero-brasil-perspectiva.png",
      "summary": "Tecnologia agrícola tropical, escala territorial e água colocam o Brasil entre os grandes produtores globais.",
      "detail": "O potencial não precisa significar apenas exportação de produto bruto: biotecnologia, máquinas, alimentos processados e agricultura de baixo carbono podem aumentar valor agregado.",
      "points": [
        "Embrapa e tecnologia tropical",
        "grande área agricultável",
        "cadeias de proteína e grãos",
        "potencial de bioinsumos"
      ]
    },
    {
      "title": "Energia renovável",
      "image": "assets/img/eventos/brasilia-jk-1960.jpg",
      "summary": "Hidrelétrica, eólica, solar, biomassa e biocombustíveis formam uma base rara entre economias grandes.",
      "detail": "Energia limpa pode atrair indústria intensiva em eletricidade, hidrogênio de baixo carbono e cadeias verdes.",
      "points": [
        "hidrelétrica",
        "eólica e solar",
        "etanol e biomassa",
        "hidrogênio e combustíveis sustentáveis"
      ]
    },
    {
      "title": "Minérios e terras raras",
      "image": "assets/img/hero-brasil-perspectiva.png",
      "summary": "Ferro, nióbio, grafita, cobre, lítio e ocorrências de terras raras são ativos estratégicos para novas tecnologias.",
      "detail": "O desafio é sair da mera extração e construir processamento, materiais avançados, componentes e pesquisa.",
      "points": [
        "minerais críticos",
        "baterias",
        "ímãs e eletrônica",
        "beneficiamento nacional"
      ]
    },
    {
      "title": "Amazônia e biodiversidade",
      "image": "assets/img/hero-brasil-perspectiva.png",
      "summary": "A biodiversidade oferece potencial científico, farmacêutico, alimentar e diplomático sem exigir destruição da floresta.",
      "detail": "Bioeconomia, serviços ambientais, pesquisa e cadeias sustentáveis podem gerar valor maior que modelos predatórios de curto prazo.",
      "points": [
        "bioeconomia",
        "medicamentos e cosméticos",
        "clima e água",
        "diplomacia ambiental"
      ]
    },
    {
      "title": "Água doce",
      "image": "assets/img/hero-brasil-perspectiva.png",
      "summary": "O país reúne algumas das maiores reservas hídricas superficiais do mundo, distribuídas de forma desigual.",
      "detail": "Água é vantagem para energia, alimentos e cidades, mas exige saneamento, gestão de bacias e adaptação climática.",
      "points": [
        "rios e aquíferos",
        "energia",
        "agro",
        "segurança hídrica"
      ]
    },
    {
      "title": "Mercado interno",
      "image": "assets/img/eventos/constituicao-1988.jpg",
      "summary": "Mais de 200 milhões de habitantes permitem escala para indústria, bancos, serviços digitais e cultura.",
      "detail": "Mercado grande ajuda inovação e produção local, desde que renda e produtividade permitam demanda sustentável.",
      "points": [
        "escala de consumo",
        "serviços financeiros",
        "economia digital",
        "diversidade regional"
      ]
    },
    {
      "title": "Posição geopolítica",
      "image": "assets/img/hero-brasil-perspectiva.png",
      "summary": "Atlântico Sul, América do Sul, alimentos, energia e clima dão ao Brasil espaço diplomático singular.",
      "detail": "O país pode negociar com diferentes blocos e funcionar como ponte, mas precisa de estratégia de longo prazo.",
      "points": [
        "Atlântico Sul",
        "BRICS e G20",
        "Mercosul",
        "agenda climática"
      ]
    },
    {
      "title": "Diversidade cultural e economia criativa",
      "image": "assets/img/eventos/diretas-ja-1984.jpg",
      "summary": "Música, audiovisual, design, esporte e cultura têm valor econômico e de influência internacional.",
      "detail": "Soft power também é ativo de desenvolvimento quando conectado a formação, direitos autorais, tecnologia e exportação de serviços.",
      "points": [
        "música e audiovisual",
        "turismo",
        "games e design",
        "soft power"
      ]
    }
  ],
  "expectations": [
    {
      "area": "Educação",
      "icon": "🎓",
      "expect": "Alfabetizar na idade certa, reduzir evasão, valorizar professor e ligar ensino médio/técnico à vida produtiva.",
      "watch": [
        "metas de aprendizagem por etapa",
        "formação e carreira docente",
        "creche e primeira infância",
        "ensino técnico conectado à economia local",
        "avaliação pública de resultados"
      ],
      "red": [
        "prometer só novas escolas sem falar em aprendizagem",
        "gastar mais sem medir resultado",
        "trocar currículo toda hora sem execução"
      ]
    },
    {
      "area": "Saúde",
      "icon": "🩺",
      "expect": "Atenção básica forte, prevenção, vacinação, acesso rápido a diagnóstico e melhor gestão das filas especializadas.",
      "watch": [
        "financiamento previsível",
        "prontuário e regulação digital",
        "saúde da família",
        "compras e logística eficientes",
        "indicadores de tempo de espera"
      ],
      "red": [
        "focar apenas em inaugurar hospital",
        "prometer zerar fila sem capacidade instalada",
        "não explicar custeio depois da obra"
      ]
    },
    {
      "area": "Economia",
      "icon": "📈",
      "expect": "Inflação controlada, contas públicas sustentáveis, investimento, emprego produtivo e ambiente de negócios previsível.",
      "watch": [
        "regra fiscal crível",
        "tributação simples",
        "crédito saudável",
        "competição",
        "crescimento da produtividade"
      ],
      "red": [
        "prometer crescimento sem investimento/produtividade",
        "ignorar custo fiscal",
        "usar um único indicador como propaganda"
      ]
    },
    {
      "area": "Segurança",
      "icon": "🛡️",
      "expect": "Reduzir homicídios e crime organizado com inteligência, investigação, prevenção e coordenação federativa.",
      "watch": [
        "dados de criminalidade auditáveis",
        "integração entre polícias",
        "investigação e perícia",
        "gestão prisional",
        "prevenção para jovens"
      ],
      "red": [
        "apenas slogan punitivo",
        "medir sucesso só por prisões",
        "ignorar organizações financeiras do crime"
      ]
    },
    {
      "area": "Tecnologia",
      "icon": "🧠",
      "expect": "Formar gente, financiar pesquisa, digitalizar o Estado e conectar ciência a empresas.",
      "watch": [
        "P&D",
        "banda larga e data centers",
        "IA responsável",
        "semicondutores e cadeias críticas",
        "compras públicas inovadoras"
      ],
      "red": [
        "chamar qualquer aplicativo de inovação",
        "crédito sem meta tecnológica",
        "projeto sem segurança cibernética"
      ]
    },
    {
      "area": "Desenvolvimento",
      "icon": "🏗️",
      "expect": "Planejamento de longo prazo com infraestrutura, produtividade, integração regional e transição ambiental.",
      "watch": [
        "carteira de projetos madura",
        "ferrovias, portos e saneamento",
        "avaliação de custo-benefício",
        "licenciamento eficiente e responsável",
        "continuidade entre governos"
      ],
      "red": [
        "anunciar valor como se fosse obra entregue",
        "megaprojeto sem demanda",
        "mudar prioridade a cada eleição"
      ]
    },
    {
      "area": "Programas sociais",
      "icon": "🤝",
      "expect": "Proteger a infância e a pobreza extrema sem abandonar portas de entrada para trabalho, renda e autonomia.",
      "watch": [
        "cadastro confiável",
        "foco na primeira infância",
        "integração com escola/saúde",
        "avaliação de impacto",
        "regras claras de transição"
      ],
      "red": [
        "benefício sem cadastro confiável",
        "usar programa como propaganda pessoal",
        "não medir saída da vulnerabilidade"
      ]
    }
  ],
  "inheritances": [
    {
      "from": "Colonização",
      "title": "Escravidão e concentração fundiária",
      "effect": "Criaram desigualdades raciais, patrimoniais e regionais de longa duração."
    },
    {
      "from": "Era Vargas",
      "title": "Estado trabalhista e industrial",
      "effect": "CLT, empresas estatais e planejamento tornaram o governo federal ator econômico central."
    },
    {
      "from": "JK e desenvolvimentismo",
      "title": "Indústria + rodovias + Brasília",
      "effect": "Aprofundaram urbanização, integração territorial e dependência do transporte rodoviário."
    },
    {
      "from": "Ditadura",
      "title": "Infraestrutura, dívida e trauma autoritário",
      "effect": "Grandes projetos conviveram com repressão e ajudaram a formar a crise dos anos 1980."
    },
    {
      "from": "Constituição de 1988",
      "title": "Estado social democrático",
      "effect": "SUS, seguridade, direitos e federalismo definem parte relevante do gasto e das políticas atuais."
    },
    {
      "from": "Plano Real",
      "title": "Estabilidade monetária",
      "effect": "Inflação baixa virou expectativa social e política; juros e regras fiscais ganharam centralidade."
    },
    {
      "from": "Anos 2000",
      "title": "Inclusão e mercado interno",
      "effect": "Transferência de renda, salário mínimo e acesso educacional alteraram a estrutura social."
    },
    {
      "from": "Recessão 2015–16",
      "title": "Trauma fiscal e desemprego",
      "effect": "Abriu espaço para nova agenda de reformas e reorganizou o sistema partidário."
    },
    {
      "from": "2019–2022",
      "title": "Polarização e direita de massas",
      "effect": "Mudou coalizões eleitorais, comunicação política e relação entre instituições e redes sociais."
    }
  ],
  "sources": [
    {
      "name": "IBGE",
      "role": "PIB, população, Censo, PNAD, IPCA, emprego, território e indicadores sociais.",
      "where": "ibge.gov.br"
    },
    {
      "name": "Ipea / IpeaData",
      "role": "Séries históricas, políticas públicas, desigualdade e desenvolvimento.",
      "where": "ipea.gov.br / ipeadata.gov.br"
    },
    {
      "name": "Banco Central do Brasil",
      "role": "Juros, crédito, inflação, moeda e história da estabilização.",
      "where": "bcb.gov.br"
    },
    {
      "name": "Tesouro Nacional e Receita Federal",
      "role": "Dívida, orçamento, arrecadação e carga tributária.",
      "where": "tesouro.gov.br / gov.br/receitafederal"
    },
    {
      "name": "Banco Mundial",
      "role": "Comparações internacionais de PIB, população e desenvolvimento.",
      "where": "worldbank.org"
    },
    {
      "name": "WID",
      "role": "Distribuição de renda e patrimônio, especialmente no topo.",
      "where": "wid.world"
    },
    {
      "name": "Arquivo Nacional / Agência Brasil / Presidência / Wikimedia Commons",
      "role": "Fotografias históricas e retratos oficiais utilizados como material visual do portal.",
      "where": "commons.wikimedia.org e acervos públicos"
    }
  ],
  "imageCredits": [
    {
      "asset": "Lula",
      "credit": "Ricardo Stuckert / Presidência da República · CC BY 2.0"
    },
    {
      "asset": "Bolsonaro",
      "credit": "U.S. Department of State / retrato oficial disponibilizado em domínio público"
    },
    {
      "asset": "FHC",
      "credit": "Agência Brasil · CC BY 3.0 BR"
    },
    {
      "asset": "Vargas, JK, Jango, Jânio, Geisel e outros arquivos históricos",
      "credit": "Arquivo Nacional / acervos públicos via Wikimedia Commons, conforme página de cada arquivo"
    },
    {
      "asset": "Constituição de 1988",
      "credit": "Agência Brasil · CC BY 3.0 BR"
    },
    {
      "asset": "Tanques em 1968",
      "credit": "Correio da Manhã / Arquivo Nacional"
    },
    {
      "asset": "Diretas Já 1984",
      "credit": "Jorge Henrique Singh · domínio público"
    },
    {
      "asset": "Mapa do Brasil colonial",
      "credit": "Acervo/exposição da Assembleia Legislativa do Estado de São Paulo."
    },
    {
      "asset": "Proclamação da República",
      "credit": "Benedito Calixto, 1893 · obra em domínio público."
    }
  ],
  "videos": [
    {
      "id": "plano-real",
      "youtube": "fsE1PJZq7Rs",
      "title": "Plano Real: história da estabilização",
      "channel": "Banco Central do Brasil",
      "image": "assets/img/presidentes/itamar.jpg",
      "topic": "Economia"
    },
    {
      "id": "const88",
      "youtube": "3Ij6iiUhhQI",
      "title": "Constituição de 1988 e redemocratização",
      "channel": "TV Senado",
      "image": "assets/img/eventos/constituicao-1988.jpg",
      "topic": "Democracia"
    },
    {
      "id": "lula",
      "youtube": "wak44JPdhH8",
      "title": "Trajetória política de Lula",
      "channel": "TV Senado",
      "image": "assets/img/presidentes/lula.jpg",
      "topic": "Presidentes"
    },
    {
      "id": "jk",
      "youtube": "lNO4pHmDCGY",
      "title": "Juscelino Kubitschek e seu tempo",
      "channel": "TV Senado",
      "image": "assets/img/presidentes/jk.jpg",
      "topic": "Presidentes"
    },
    {
      "id": "bolsonaro",
      "youtube": "RLAwkHbFE-o",
      "title": "Trajetória e transformação política de Bolsonaro",
      "channel": "BBC News Brasil",
      "image": "assets/img/presidentes/bolsonaro.jpg",
      "topic": "Política recente"
    },
    {
      "id": "vargas",
      "youtube": "Ekj-zmB7sY8",
      "title": "Getúlio Vargas: vida e obra política",
      "channel": "Documentário / acervo de TV",
      "image": "assets/img/presidentes/vargas.jpg",
      "topic": "História"
    }
  ]
};