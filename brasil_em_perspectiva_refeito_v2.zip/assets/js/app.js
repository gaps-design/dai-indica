(() => {
  const D = window.SITE_DATA || {};
  const $ = (s,root=document)=>root.querySelector(s);
  const $$ = (s,root=document)=>[...root.querySelectorAll(s)];
  const esc = (v='')=>String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const norm=s=>(s||'').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'');

  function nav(){
    const page=document.body.dataset.page;
    $$('[data-nav]').forEach(a=>a.classList.toggle('active',a.dataset.nav===page));
    const b=$('#mobileMenu'), n=$('.navlinks'); if(b&&n)b.onclick=()=>n.classList.toggle('open');
    document.body.classList.add('page-transition');
  }
  function renderCurrent(){
    $$('#currentCards').forEach(el=>{
      el.className='current-grid';
      el.innerHTML=(D.current||[]).map(x=>`<article class="stat reveal"><small>${esc(x.label)}</small><b>${esc(x.value)}</b><span>${esc(x.detail)}</span></article>`).join('');
    });
  }
  function bars(id,rows,key='value',unit=''){
    const el=$('#'+id); if(!el)return;
    const max=Math.max(...rows.map(x=>Number(x[key])||0),1);
    el.className='bar-list'; el.innerHTML=rows.map(x=>`<div class="bar-row"><b>${esc(x.label||x.name)}</b><div class="bar-track"><div class="bar-fill" style="width:${((Number(x[key])||0)/max)*100}%"></div></div><div class="bar-val">${esc(String(x[key]).replace('.',','))}${unit}</div></div>`).join('');
  }
  function setupDossier(){
    if($('#dossierModal'))return;
    document.body.insertAdjacentHTML('beforeend',`<div class="modal" id="dossierModal"><article class="dossier"><div class="dossier-hero"><div class="dossier-image"><img id="dosImg" alt=""></div><div class="dossier-intro"><button class="close-modal" id="dosClose">✕</button><div class="kicker" id="dosKick"></div><h2 id="dosTitle"></h2><p class="summary" id="dosSummary"></p><div class="dossier-tabs"><button data-tab="resumo" class="active">Resumo</button><button data-tab="trajetoria">Trajetória</button><button data-tab="governo">Governo / fatos</button><button data-tab="dados">Dados</button><button data-tab="debates">Debates</button><button data-tab="legado">Legado hoje</button></div></div></div><div class="dossier-content" id="dosContent"></div></article></div>`);
    $('#dosClose').onclick=()=>$('#dossierModal').classList.remove('open');
    $('#dossierModal').addEventListener('click',e=>{if(e.target.id==='dossierModal')e.currentTarget.classList.remove('open')});
  }
  function normalizeDossier(item){
    const gov = item.id && (D.governments||[]).find(g=>g.id===item.id) ? item : null;
    return {
      title:item.name||item.title||item.term||item.area||'',
      kick:item.period||item.subtitle||item.years||item.origin||'', image:item.image||'assets/img/hero-brasil-perspectiva.png',
      summary:item.summary||item.definition||item.expect||item.detail||item.note||'', born:item.born||item.years||item.age||'',
      trajectory:item.trajectory||item.detail||item.definition||item.note||'', context:item.context||item.use||item.system||'',
      policies:item.policies||item.points||item.watch||[], growth:item.growth, inflation:item.inflation, inequality:item.inequality,
      positive:item.positive||[], critical:item.critical||item.red||[], legacy:item.legacy||item.result||item.effect||'', current:item.current||item.detail||item.use||''
    }
  }
  function openDossier(raw){
    if(!raw)return; setupDossier(); const x=normalizeDossier(raw);
    $('#dosImg').src=x.image; $('#dosImg').alt=x.title; $('#dosKick').textContent=x.kick; $('#dosTitle').textContent=x.title; $('#dosSummary').textContent=x.summary;
    const panels={
      resumo:`<section class="tab-panel active" data-panel="resumo"><h3>Em poucas palavras</h3><p>${esc(x.summary)}</p>${x.born?`<div class="facts"><div class="fact"><b>Referência biográfica / temporal</b>${esc(x.born)}</div><div class="fact"><b>Contexto</b>${esc(x.context||'Veja as outras abas para aprofundar.')}</div><div class="fact"><b>Por que estudar</b>${esc(x.current||x.legacy||'Ajuda a entender a sequência histórica.')}</div></div>`:''}</section>`,
      trajetoria:`<section class="tab-panel" data-panel="trajetoria"><h3>Trajetória e contexto</h3><p>${esc(x.trajectory||'Conteúdo em consolidação.')}</p><h3>Contexto histórico</h3><p>${esc(x.context||'')}</p></section>`,
      governo:`<section class="tab-panel" data-panel="governo"><h3>Principais políticas e fatos</h3><div class="facts">${(x.policies.length?x.policies:['Veja o resumo histórico acima.']).map(p=>`<div class="fact">${esc(p)}</div>`).join('')}</div></section>`,
      dados:`<section class="tab-panel" data-panel="dados"><h3>Indicadores para interpretar</h3><div class="facts"><div class="fact"><b>Crescimento médio aproximado</b>${x.growth!==undefined?esc(x.growth)+'% a.a.':'Não há uma série única comparável.'}</div><div class="fact"><b>Inflação</b>${esc(x.inflation||'Depende do período e da metodologia.')}</div><div class="fact"><b>Desigualdade</b>${esc(x.inequality||'Use Gini e participação no topo para avaliar.')}</div></div><p>Esses números não funcionam como placar de presidente: cenário externo, ponto de partida, políticas herdadas e regime institucional precisam ser considerados.</p></section>`,
      debates:`<section class="tab-panel" data-panel="debates"><h3>O que costuma ser reconhecido</h3><div class="debate"><div><h4>Avanços / argumentos favoráveis</h4><ul>${(x.positive.length?x.positive:['Consulte o contexto e os resultados mensuráveis.']).map(v=>`<li>${esc(v)}</li>`).join('')}</ul></div><div><h4>Críticas / limites</h4><ul>${(x.critical.length?x.critical:['Todo período deve ser avaliado também por custos, instituições e distribuição.']).map(v=>`<li>${esc(v)}</li>`).join('')}</ul></div></div></section>`,
      legado:`<section class="tab-panel" data-panel="legado"><h3>Legado</h3><p>${esc(x.legacy||'')}</p><h3>Conexão com o Brasil atual</h3><p>${esc(x.current||'')}</p></section>`
    };
    $('#dosContent').innerHTML=Object.values(panels).join('');
    $$('.dossier-tabs button').forEach(btn=>btn.onclick=()=>{
      $$('.dossier-tabs button').forEach(b=>b.classList.remove('active'));btn.classList.add('active');
      $$('.tab-panel').forEach(p=>p.classList.toggle('active',p.dataset.panel===btn.dataset.tab));
    });
    $('#dossierModal').classList.add('open');
  }
  window.openPortalDossier=openDossier;

  function renderStories(){
    $$('[data-story-grid]').forEach(el=>{
      el.className='story-grid'; el.innerHTML=(D.stories||[]).map(s=>`<article class="story-card reveal" data-story="${esc(s.id)}"><img src="${esc(s.image)}" alt="${esc(s.title)}"><div class="story-copy"><div class="kicker">${esc(s.subtitle)}</div><h3>${esc(s.title)}</h3><p>${esc(s.summary)}</p><span class="story-cta">Abrir dossiê completo →</span></div></article>`).join('');
      $$('[data-story]',el).forEach(card=>card.onclick=()=>{
        const s=D.stories.find(x=>x.id===card.dataset.story); const target=s?.target==='government'?D.governments.find(g=>g.id===s.targetId):s; openDossier(target||s);
      });
    });
  }
  function renderTimeline(){
    const el=$('#timelineList');if(!el)return; const search=$('#timelineSearch'),sel=$('#timelineEra'); const eras=['Todos',...new Set((D.timeline||[]).map(x=>x.era))]; if(sel)sel.innerHTML=eras.map(e=>`<option>${esc(e)}</option>`).join('');
    const draw=()=>{const q=norm(search?.value),era=sel?.value||'Todos'; const rows=(D.timeline||[]).filter(x=>(era==='Todos'||x.era===era)&&norm(JSON.stringify(x)).includes(q)); el.innerHTML=rows.map((x,i)=>`<article class="timeline-card reveal"><div class="timeline-img"><img src="${esc(x.image)}" alt="${esc(x.title)}"></div><div class="timeline-main"><div class="timeline-year">${esc(x.year)}</div><div class="kicker">${esc(x.era)}</div><h3>${esc(x.title)}</h3><p>${esc(x.summary)}</p><div class="pill-row"><span class="pill dark">herança</span><span class="pill">${esc(x.legacy)}</span></div></div><div class="timeline-action"><button class="btn primary" data-time-index="${i}">Ver história completa</button></div></article>`).join('');
      $$('[data-time-index]',el).forEach(btn=>btn.onclick=()=>{const x=rows[+btn.dataset.timeIndex]; const g=x.government&&D.governments.find(v=>v.id===x.government); const s=x.story&&D.stories.find(v=>v.id===x.story); openDossier(g||s||x);}); observe();};
    search?.addEventListener('input',draw);sel?.addEventListener('change',draw);draw();
  }
  function renderGovernments(){
    const wrap=$('#govProfiles');if(!wrap)return; const sels=[$('#gov1'),$('#gov2'),$('#gov3')]; const opts=(D.governments||[]).map(g=>`<option value="${g.id}">${esc(g.name)} · ${esc(g.period)}</option>`).join(''); const defaults=['lula','bolsonaro','fhc']; sels.forEach((s,i)=>{s.innerHTML=opts;s.value=defaults[i]||D.governments[i].id});
    const draw=()=>{const rows=sels.map(s=>D.governments.find(g=>g.id===s.value)); wrap.className='gov-compare';wrap.innerHTML=rows.map(g=>`<article class="gov-card reveal"><div class="gov-photo"><img src="${esc(g.image)}" alt="${esc(g.name)}"><div class="gov-title"><small>${esc(g.period)}</small><h3>${esc(g.name)}</h3><span>${esc(g.origin)}</span></div></div><div class="gov-body"><p>${esc(g.summary)}</p><div class="metrics"><div class="metric"><b>Crescimento</b>${esc(g.growth)}% a.a.</div><div class="metric"><b>Inflação</b>${esc(g.inflation)}</div><div class="metric"><b>Regime</b>${esc(g.regime)}</div><div class="metric"><b>Desigualdade</b>${esc(g.inequality)}</div></div><div class="pill-row">${g.policies.slice(0,4).map(p=>`<span class="pill">${esc(p)}</span>`).join('')}</div><button class="btn primary" style="margin-top:14px" data-gov-open="${g.id}">Abrir dossiê</button></div></article>`).join('');
      $$('[data-gov-open]',wrap).forEach(b=>b.onclick=()=>openDossier(D.governments.find(g=>g.id===b.dataset.govOpen))); bars('govGrowth',rows.map(r=>({label:r.name,value:r.growth})),'value','%'); observe();};
    sels.forEach(s=>s.addEventListener('change',draw));draw();
  }
  function renderPresidentWall(){
    const el=$('#presidentWall');if(!el)return; el.className='president-wall'; el.innerHTML=(D.governments||[]).map(g=>`<article class="president-mini reveal" data-pres="${g.id}"><img src="${esc(g.image)}" alt="${esc(g.name)}"><span>${esc(g.name)}</span></article>`).join(''); $$('[data-pres]',el).forEach(x=>x.onclick=()=>openDossier(D.governments.find(g=>g.id===x.dataset.pres))); observe();
  }
  function renderPlans(){
    const grid=$('#planGrid');if(!grid)return;const search=$('#planSearch'),sel=$('#planType');const types=['Todos',...new Set(D.plans.map(x=>x.type))];if(sel)sel.innerHTML=types.map(x=>`<option>${esc(x)}</option>`).join('');
    const draw=()=>{const q=norm(search?.value),t=sel?.value||'Todos';const rows=D.plans.filter(x=>(t==='Todos'||x.type===t)&&norm(JSON.stringify(x)).includes(q));grid.className='plan-grid';grid.innerHTML=rows.map((p,i)=>`<article class="info-card plan-photo-card reveal" data-plan="${i}"><img class="plan-thumb" src="${esc(p.image||'assets/img/hero-brasil-perspectiva.png')}" alt="${esc(p.name)}"><div class="plan-copy"><div class="kicker">${esc(p.years)} · ${esc(p.type)}</div><h3>${esc(p.name)}</h3><p>${esc(p.summary)}</p><p class="citation"><b>Resultado:</b> ${esc(p.result)}</p><button class="btn soft">Ver detalhes</button></div></article>`).join('');$$('[data-plan]',grid).forEach(x=>x.onclick=()=>openDossier(rows[+x.dataset.plan]));observe();}; search?.addEventListener('input',draw);sel?.addEventListener('change',draw);draw();
  }
  function renderGlossary(){
    const grid=$('#conceptGrid');if(!grid)return;const search=$('#conceptSearch');const draw=()=>{const q=norm(search?.value);const rows=D.glossary.filter(x=>norm(JSON.stringify(x)).includes(q));grid.className='gloss-grid';grid.innerHTML=rows.map((x,i)=>`<article class="info-card reveal" data-concept="${i}"><div class="kicker">conceito / sigla</div><h3>${esc(x.term)}</h3><p>${esc(x.definition)}</p><p class="citation"><b>Para que serve:</b> ${esc(x.use)}</p></article>`).join('');$$('[data-concept]',grid).forEach(c=>c.onclick=()=>openDossier(rows[+c.dataset.concept]));observe();};search?.addEventListener('input',draw);draw();
    $$('#siglaGrid').forEach(el=>{el.className='sigla-grid';el.innerHTML=D.glossary.slice(0,10).map(x=>`<div class="sigla"><b>${esc(x.term)}</b>${esc(x.definition)}</div>`).join('')});
  }
  function renderInheritance(){const el=$('#inheritanceTree');if(!el)return;el.className='inheritance-grid';el.innerHTML=D.inheritances.map(x=>`<article class="info-card reveal"><div class="kicker">${esc(x.from)}</div><h3>${esc(x.title)}</h3><p>${esc(x.effect)}</p></article>`).join('');observe();}
  function renderTaxTable(){const el=$('#taxVsGrowth');if(!el)return;el.className='table-wrap';el.innerHTML=`<table><thead><tr><th>Pergunta correta</th><th>Indicadores</th><th>O que significa</th></tr></thead><tbody><tr><td>Quanto o Estado arrecada?</td><td>Carga tributária, receita por esfera e composição dos impostos.</td><td>Mostra capacidade de arrecadação. Não mede resultado.</td></tr><tr><td>Onde gasta?</td><td>Saúde, educação, previdência, investimento, pessoal, juros, transferências.</td><td>Mostra prioridade e rigidez do orçamento.</td></tr><tr><td>O gasto funciona?</td><td>Aprendizagem, espera no SUS, produtividade, pobreza, infraestrutura.</td><td>É aqui que política pública vira — ou não — desenvolvimento.</td></tr></tbody></table>`;}
  function renderIneq(){bars('giniChart',[{label:'2001',value:.594},{label:'2012',value:.527},{label:'2019',value:.543},{label:'2021',value:.544},{label:'2024',value:.518}],'value','');bars('shareBars',[{label:'Top 1%',value:24},{label:'Top 10%',value:56},{label:'50% mais pobres',value:11}],'value','%');}
  function renderGeo(){bars('areaBars',D.countries.map(x=>({label:x.name,value:x.area})),'value',' mi km²');}
  function renderWorld(){
    const globe=$('#worldGlobe');if(globe){globe.innerHTML='';Object.entries(D.countryHotspots).forEach(([name,p])=>{const b=document.createElement('button');b.className='hotspot';b.style.left=p[0]+'%';b.style.top=p[1]+'%';b.innerHTML=`<span>${esc(name)}</span>`;b.onclick=()=>openDossier(D.countries.find(c=>c.name===name));globe.appendChild(b);});}
    const grid=$('#countryGrid');if(grid){grid.className='country-grid';grid.innerHTML=D.countries.map((c,i)=>`<article class="country-card reveal" data-country="${i}"><h3>${esc(c.name)}</h3><p>${esc(c.note)}</p><div class="metrics"><div class="metric"><b>Área</b>${c.area} mi km²</div><div class="metric"><b>Pop.</b>${c.pop} mi</div><div class="metric"><b>PIB/hab.</b>US$ ${c.gdpPc.toLocaleString('pt-BR')}</div><div class="metric"><b>Sistema</b>${esc(c.system)}</div></div></article>`).join('');$$('[data-country]',grid).forEach(x=>x.onclick=()=>openDossier(D.countries[+x.dataset.country]));observe();}
    const tabs=$$('[data-country-key]'); const draw=(key='gdpPc',unit=' US$')=>bars('countryBars',D.countries.map(c=>({label:c.name,value:c[key]})),'value',unit); draw();tabs.forEach(t=>t.onclick=()=>{tabs.forEach(x=>x.classList.remove('active'));t.classList.add('active');const key=t.dataset.countryKey;const unit=key==='gdpPc'?' US$':key==='area'?' mi km²':key==='pop'?' mi':' hab/km²';draw(key,unit)});
  }
  function renderResources(){const grid=$('#resourceGrid');if(!grid)return;grid.className='resource-grid';grid.innerHTML=D.resources.map((r,i)=>`<article class="resource-card reveal" data-resource="${i}"><img src="${esc(r.image)}" alt="${esc(r.title)}"><div class="resource-body"><div class="kicker">vantagem brasileira</div><h3>${esc(r.title)}</h3><p>${esc(r.summary)}</p><div class="pill-row" style="margin-top:10px">${r.points.slice(0,3).map(x=>`<span class="pill">${esc(x)}</span>`).join('')}</div></div></article>`).join('');$$('[data-resource]',grid).forEach(x=>x.onclick=()=>openDossier(D.resources[+x.dataset.resource]));observe();}
  function renderExpectations(){const grid=$('#expectGrid');if(!grid)return;grid.className='expect-grid';grid.innerHTML=D.expectations.map((x,i)=>`<article class="info-card reveal" data-exp="${i}"><div style="font-size:30px">${x.icon}</div><div class="kicker">o que cobrar</div><h3>${esc(x.area)}</h3><p>${esc(x.expect)}</p><div class="pill-row">${x.watch.slice(0,3).map(v=>`<span class="pill">${esc(v)}</span>`).join('')}</div></article>`).join('');$$('[data-exp]',grid).forEach(x=>x.onclick=()=>openDossier(D.expectations[+x.dataset.exp]));observe();}
  function renderSources(){const el=$('#sourceList');if(!el)return;el.className='gloss-grid';el.innerHTML=D.sources.map(x=>`<article class="info-card reveal"><div class="kicker">fonte</div><h3>${esc(x.name)}</h3><p>${esc(x.role)}</p><p class="citation">${esc(x.where)}</p></article>`).join('');const cr=$('#imageCredits');if(cr){cr.className='gloss-grid';cr.innerHTML=D.imageCredits.map(x=>`<article class="info-card"><h3>${esc(x.asset)}</h3><p>${esc(x.credit)}</p></article>`).join('')}observe();}
  function setupVideoModal(){if($('#videoModal'))return;document.body.insertAdjacentHTML('beforeend',`<div class="modal video-modal" id="videoModal"><article class="dossier"><div class="video-frame" id="videoFrame"></div><div class="video-info"><button class="close-modal" id="videoClose" style="float:right;position:static">✕</button><div class="kicker" id="videoChannel"></div><h3 id="videoTitle"></h3><p class="citation">O vídeo é reproduzido pelo YouTube e precisa de conexão com a internet.</p></div></article></div>`);const close=()=>{$('#videoFrame').innerHTML='';$('#videoModal').classList.remove('open')};$('#videoClose').onclick=close;$('#videoModal').onclick=e=>{if(e.target.id==='videoModal')close()};}
  function openVideo(v){setupVideoModal();$('#videoChannel').textContent=v.channel;$('#videoTitle').textContent=v.title;$('#videoFrame').innerHTML=`<iframe src="https://www.youtube.com/embed/${esc(v.youtube)}?autoplay=1&rel=0" allow="autoplay; encrypted-media; picture-in-picture" allowfullscreen title="${esc(v.title)}"></iframe>`;$('#videoModal').classList.add('open');}
  function renderVideos(){
    $$('[data-video-carousel]').forEach((zone,zi)=>{zone.innerHTML=`<div class="video-head"><div><div class="kicker">vídeos para continuar o estudo</div><h3 style="font-family:Georgia,serif;font-size:29px;margin:5px 0 0">Assista aos temas do portal</h3></div><div class="carousel-controls"><button class="carousel-arrow" data-prev>←</button><button class="carousel-arrow" data-next>→</button></div></div><div class="video-track">${D.videos.map((v,i)=>`<article class="video-card" data-video="${i}"><img src="${esc(v.image)}" alt="${esc(v.title)}"><span class="play">▶</span><div class="copy"><small>${esc(v.channel)} · ${esc(v.topic)}</small><h4>${esc(v.title)}</h4></div></article>`).join('')}</div>`;const track=$('.video-track',zone);$('[data-prev]',zone).onclick=()=>track.scrollBy({left:-360,behavior:'smooth'});$('[data-next]',zone).onclick=()=>track.scrollBy({left:360,behavior:'smooth'});$$('[data-video]',zone).forEach(c=>c.onclick=()=>openVideo(D.videos[+c.dataset.video]));});
  }
  let observer;
  function observe(){if(!observer)observer=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting){e.target.classList.add('visible');observer.unobserve(e.target)}}),{threshold:.08});$$('.reveal:not(.visible)').forEach(x=>observer.observe(x));}
  function bootstrap(){nav();setupDossier();renderCurrent();renderStories();renderTimeline();renderGovernments();renderPresidentWall();renderPlans();renderGlossary();renderInheritance();renderTaxTable();renderIneq();renderGeo();renderWorld();renderResources();renderExpectations();renderSources();renderVideos();bars('decadeChart',D.decades,'value','% a.a.');observe();}
  document.addEventListener('DOMContentLoaded',bootstrap);
})();
