(()=>{
  const pageQuestions={
    inicio:['Por que o Brasil não se desenvolveu mais?','Quem governava em 1990?','O que o Brasil tem de mais valioso?'],
    linha:['Conte a Era Vargas','Explique a ditadura militar','Como o Plano Real mudou o Brasil?'],
    governos:['Compare Lula e Bolsonaro','Quem foi JK?','Qual foi o legado de FHC?'],
    planos:['O Plano Real deu certo por quê?','O que foi o II PND?','Como avaliar o Novo PAC?'],
    hoje:['O que o Brasil atual herdou?','Quanto da arrecadação vira desenvolvimento?','O que é responsabilidade do presidente?'],
    geo:['O território atrapalha o Brasil?','Compare Brasil e Canadá','Qual é o papel da Amazônia?'],
    desigualdade:['Os super-ricos causam pobreza?','O que é Gini?','Renda e patrimônio são iguais?'],
    mundo:['Compare Brasil e Alemanha','Brasil e China têm o mesmo potencial?','Por que Japão é rico sendo pequeno?'],
    riquezas:['O que são terras raras?','Como transformar recursos em riqueza?','A Amazônia pode gerar desenvolvimento?'],
    expectativas:['Como avaliar uma promessa?','O que cobrar na educação?','O que esperar da segurança pública?'],
    conceitos:['O que é fascismo?','Explique esquerda e direita','O que significa WID?'],
    fontes:['O que o IBGE mede?','Como verificar um dado político?','Qual a diferença entre dado e opinião?']
  };
  const routes={'governos':'governos.html','linha do tempo':'linha-do-tempo.html','planos':'planos.html','brasil hoje':'brasil-hoje.html','geografia':'geografia.html','desigualdade':'desigualdade.html','mundo':'mundo.html','riquezas':'riquezas.html','o que esperar':'o-que-esperar.html','conceitos':'conceitos.html','fontes':'fontes.html'};
  const norm=s=>(s||'').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'');
  function init(){
    const wrap=document.createElement('div');wrap.className='ze-wrap';wrap.innerHTML=`<section class="ze-panel" id="zePanel"><header class="ze-top"><img src="assets/img/ze-mascote.png" alt="Zé"><div><h3>Zé</h3><p>Seu guia de história política e dados</p></div><button class="ze-close" id="zeClose">✕</button></header><div class="ze-suggest" id="zeSuggest"></div><div class="ze-log" id="zeLog"></div><div class="ze-compose"><input id="zeInput" class="ze-input" placeholder="Pergunte qualquer tema do portal..."><button class="ze-btn" id="zeSend">Enviar</button><button class="ze-btn voice" id="zeVoice" title="Perguntar por voz">🎙</button></div></section><button class="ze-launch" id="zeLaunch"><img src="assets/img/ze-mascote.png" alt="Zé"><span><strong>Fale com o Zé</strong><small>texto ou voz</small></span></button>`;document.body.appendChild(wrap);
    const panel=wrap.querySelector('#zePanel'),log=wrap.querySelector('#zeLog'),input=wrap.querySelector('#zeInput'),suggest=wrap.querySelector('#zeSuggest');let lastAnswer='';
    function message(kind,text,actions=false){const div=document.createElement('div');div.className='msg '+kind;div.innerHTML=`<div>${text}</div>${actions&&kind==='ze'?'<div class="ze-answer-actions"><button data-hear>🔊 Ouvir</button><button data-copy>Copiar</button></div>':''}`;log.appendChild(div);log.scrollTop=log.scrollHeight;if(actions){div.querySelector('[data-hear]').onclick=()=>speak(text);div.querySelector('[data-copy]').onclick=()=>navigator.clipboard?.writeText(text);}}
    function greet(){if(log.children.length)return;message('ze','Oi! Eu sou o Zé. Posso explicar o conteúdo do portal em linguagem simples, comparar governos e te ajudar a interpretar siglas e indicadores. Por onde você quer começar?',false);}
    function renderSuggest(){const list=pageQuestions[document.body.dataset.page]||pageQuestions.inicio;suggest.innerHTML='';list.forEach(q=>{const b=document.createElement('button');b.textContent=q;b.onclick=()=>{input.value=q;ask()};suggest.appendChild(b)});}
    function speak(text){if(!window.speechSynthesis)return;window.speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(text.replace(/<[^>]+>/g,''));u.lang='pt-BR';window.speechSynthesis.speak(u)}
    function command(q){const t=norm(q);if(t.includes('parar de falar')){speechSynthesis?.cancel();message('ze','Parei a leitura. O que você quer analisar agora?',false);return true}if(t.includes('limpar conversa')){log.innerHTML='';greet();return true}for(const [k,v] of Object.entries(routes)){if(t.includes('abrir '+k)||t.includes('ir para '+k)||t.includes('mostrar '+k)){location.href=v;return true}}return false}
    function ask(){const q=input.value.trim();if(!q)return;message('user',q);input.value='';if(command(q))return;const ans=window.ZE_KNOWLEDGE?.answer(q,document.body.dataset.page)||'Não consegui montar essa resposta agora. Qual parte do tema você quer esclarecer?';lastAnswer=ans;setTimeout(()=>message('ze',ans,true),180)}
    wrap.querySelector('#zeLaunch').onclick=()=>{panel.classList.toggle('open');greet();renderSuggest();input.focus()};wrap.querySelector('#zeClose').onclick=()=>panel.classList.remove('open');wrap.querySelector('#zeSend').onclick=ask;input.onkeydown=e=>{if(e.key==='Enter')ask()};
    wrap.querySelector('#zeVoice').onclick=()=>{const SR=window.SpeechRecognition||window.webkitSpeechRecognition;if(!SR){message('ze','Seu navegador não disponibilizou reconhecimento de voz nesta página. Você pode escrever a pergunta. O que quer saber?',false);return}const rec=new SR();rec.lang='pt-BR';rec.interimResults=false;message('ze','Estou ouvindo. Pode falar sua pergunta — o que você quer saber?',false);rec.onresult=e=>{input.value=e.results[0][0].transcript;ask()};rec.onerror=()=>message('ze','Não consegui entender o áudio dessa vez. Quer tentar novamente ou escrever a pergunta?',false);rec.start()};
    document.addEventListener('keydown',e=>{if(e.altKey&&e.key.toLowerCase()==='z'){panel.classList.toggle('open');greet();renderSuggest()}});
  }
  document.addEventListener('DOMContentLoaded',init);
})();
