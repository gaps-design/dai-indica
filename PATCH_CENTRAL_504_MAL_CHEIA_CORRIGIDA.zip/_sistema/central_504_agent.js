"use strict";
// Compatibilidade: existe apenas uma Central 504 oficial.
// Qualquer chamada antiga para _sistema\central_504_agent.js é redirecionada
// para _sistema\Central Atualizacoes\central_504_agent.js.
require("./Central Atualizacoes/central_504_agent.js");
